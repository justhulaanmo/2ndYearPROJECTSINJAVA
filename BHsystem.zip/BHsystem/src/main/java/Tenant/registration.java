package Tenant;
import Config.DBconnection;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class registration extends javax.swing.JFrame {

    
    public registration() {
        initComponents();
        setLocationRelativeTo(null);
        reservation_information.setVisible(false);
        
        contactnumber.setText("09");
        contactnumber.setForeground(Color.GRAY);
        emergencycontactnumber.setText("09");
        emergencycontactnumber.setForeground(Color.GRAY);
        contactnumber.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (contactnumber.getText().equals("09")) {
                    contactnumber.setText("09");
                    contactnumber.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (contactnumber.getText().isEmpty()) {
                    contactnumber.setText("09");
                    contactnumber.setForeground(Color.GRAY);
                }
            }
        });

        contactnumber.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                // Limit the input to 11 characters
                if (contactnumber.getText().length() >= 11) {
                    evt.consume();
                }
            }
        });
        
         fullname.addKeyListener(new java.awt.event.KeyAdapter() {
        @Override
        public void keyReleased(java.awt.event.KeyEvent evt) {
            String original = fullname.getText();
            int caretPos = fullname.getCaretPosition();

            String updated = capitalizeEachWord(original);
            if (!original.equals(updated)) {
                fullname.setText(updated);
                // Set caret back to original position if possible
                if (caretPos <= updated.length()) {
                    fullname.setCaretPosition(caretPos);
                }
            }
        }
    });

    fbaccount.addKeyListener(new java.awt.event.KeyAdapter() {
        @Override
        public void keyReleased(java.awt.event.KeyEvent evt) {
            String original = fbaccount.getText();
            int caretPos = fbaccount.getCaretPosition();

            String updated = capitalizeEachWord(original);
            if (!original.equals(updated)) {
                fbaccount.setText(updated);
                if (caretPos <= updated.length()) {
                    fbaccount.setCaretPosition(caretPos);
                }
            }
        }
    });
    }
    
    private String capitalizeEachWord(String input) {
        if (input == null || input.isEmpty()) return input;

        String[] words = input.toLowerCase().split(" ");
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            String word = words[i];
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1));
            }
            if (i < words.length - 1 || input.endsWith(" ")) {
                result.append(" ");
            }
        }

        return result.toString();
    }

    
    
    // Method to verify tenant code and populate fields
public void verifyTenantCode(String tenantCode) {
    System.out.println("Tenant Code (before query): '" + tenantCode + "'");
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
        // Get tenantCode from field or passed variable and trim
        tenantCode = tenantCode.trim(); 

        // Debug: Print the trimmed code and its length
        System.out.println("Tenant Code (trimmed): '" + tenantCode + "'");
        System.out.println("Length: " + tenantCode.length());

        // Debug: Print each character
        for (int i = 0; i < tenantCode.length(); i++) {
            System.out.println("Char " + i + ": '" + tenantCode.charAt(i) + "'");
            System.out.println("Running query with tenant code: " + tenantCode);

        }

        // Check for proper length
        if (tenantCode.length() != 9) {
            JOptionPane.showMessageDialog(null, "Invalid code length. Tenant Code must be 9 characters.");
            return;
        }

        // DB connection (using your DBconnection.getConnection())
        conn = DBconnection.getConnection();

        // SQL Query to check if tenant exists
        String query = "SELECT * FROM tenants WHERE tenant_code = ?";

        // Prepare the statement
        ps = conn.prepareStatement(query);
        ps.setString(1, tenantCode); // Use the trimmed tenant code
        rs = ps.executeQuery();

        // Check if tenant exists in the database
        if (rs.next()) {
            // Tenant found, retrieve tenant info
            String fullName = rs.getString("full_name");
            String contactNumber = rs.getString("contact_number");
            String Email = rs.getString("email");
            String Gender = rs.getString("gender");
            String bedID = rs.getString("bed_number");
            String roomID = rs.getString("room_id");

            // Populate your fields with the tenant's information
            fullname.setText(fullName);
            contactnumber.setText(contactNumber);
            email.setText(Email);

            // For combo box (e.g., gender dropdown)
            gender.setText(Gender);  // <- make sure it's a JComboBox

            bedid.setText(bedID);
            roomid.setText(roomID);

            reservation_information.setVisible(true);  // Show the info panel
        } else {
            JOptionPane.showMessageDialog(null, "Invalid tenant code. Please try again.");
        }

    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try { if (rs != null) rs.close(); } catch (SQLException e) {}
        try { if (ps != null) ps.close(); } catch (SQLException e) {}
        try { if (conn != null) conn.close(); } catch (SQLException e) {}
    }
}

    
            public void registerTenant(String tenantCode, String facebookAccount,
                                   String emergencyName, String emergencyRelationship, String emergencyNumber) {
            Connection conn = null;    
            PreparedStatement updateTenantStmt = null;
            PreparedStatement updateUserStmt = null;

            try {
                conn = DBconnection.getConnection(); 

                // Update tenant details excluding email
                String updateTenantSQL = "UPDATE tenants " +
                                         "SET facebook_account = ?, emergency_contact_name = ?, " +
                                         "emergency_contact_relationship = ?, emergency_contact_number = ?, " +
                                         "status = 'Registered' " +
                                         "WHERE tenant_code = ?";

                updateTenantStmt = conn.prepareStatement(updateTenantSQL);
                updateTenantStmt.setString(1, facebookAccount);
                updateTenantStmt.setString(2, emergencyName);
                updateTenantStmt.setString(3, emergencyRelationship);
                updateTenantStmt.setString(4, emergencyNumber);
                updateTenantStmt.setString(5, tenantCode);

                int rowsUpdated = updateTenantStmt.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("Tenant table updated successfully.");

                    // Update the users table status to 'Registered'
                    String updateUserSQL = "UPDATE users u " +
                                           "JOIN tenants t ON u.user_id = t.user_id " +
                                           "SET u.status = 'Registered' " +
                                           "WHERE t.tenant_code = ?";

                    updateUserStmt = conn.prepareStatement(updateUserSQL);
                    updateUserStmt.setString(1, tenantCode);

                    int userUpdated = updateUserStmt.executeUpdate();

                    if (userUpdated > 0) {
                        System.out.println("User table status updated to 'Registered'.");
                        this.dispose();  // Close the current frame
                        Login loginForm = new Login(); 
                        loginForm.setVisible(true);
                    } else {
                        System.out.println("No matching user found to update status.");
                    }

                } else {
                    System.out.println("No tenant found with that tenant code.");
                }

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (updateTenantStmt != null) updateTenantStmt.close();
                    if (updateUserStmt != null) updateUserStmt.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tenantcode = new javax.swing.JTextField();
        verify = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        reservation_information = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        fullname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        contactnumber = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        fbaccount = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        gender = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        roomid = new javax.swing.JTextField();
        bedid = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        emergencycontactnumber = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        emergencycontactname = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        relationship = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        register = new javax.swing.JButton();
        cancel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(759, 517));
        setMinimumSize(new java.awt.Dimension(759, 517));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(759, 517));
        jPanel1.setMinimumSize(new java.awt.Dimension(759, 517));
        jPanel1.setSize(new java.awt.Dimension(759, 517));

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Tenant Code:");

        tenantcode.setBackground(new java.awt.Color(255, 255, 255));
        tenantcode.setForeground(new java.awt.Color(0, 0, 0));
        tenantcode.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        tenantcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tenantcodeActionPerformed(evt);
            }
        });

        verify.setBackground(new java.awt.Color(255, 255, 255));
        verify.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        verify.setForeground(new java.awt.Color(0, 0, 0));
        verify.setText("Verify");
        verify.setBorderPainted(false);
        verify.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        verify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verifyActionPerformed(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(204, 51, 0));
        jLabel2.setText("*Input the tenant code where admin given to you and click verify.");

        reservation_information.setBackground(new java.awt.Color(255, 255, 255));
        reservation_information.setForeground(new java.awt.Color(0, 0, 0));

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Full Name:");

        fullname.setEditable(false);
        fullname.setBackground(new java.awt.Color(255, 255, 255));
        fullname.setForeground(new java.awt.Color(0, 0, 0));
        fullname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Contact Number:");

        contactnumber.setBackground(new java.awt.Color(255, 255, 255));
        contactnumber.setForeground(new java.awt.Color(0, 0, 0));
        contactnumber.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Facebook Account:");

        fbaccount.setBackground(new java.awt.Color(255, 255, 255));
        fbaccount.setForeground(new java.awt.Color(0, 0, 0));
        fbaccount.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Gender:");

        gender.setEditable(false);
        gender.setBackground(new java.awt.Color(255, 255, 255));
        gender.setForeground(new java.awt.Color(0, 0, 0));
        gender.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        gender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderActionPerformed(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Email:");

        email.setEditable(false);
        email.setBackground(new java.awt.Color(255, 255, 255));
        email.setForeground(new java.awt.Color(0, 0, 0));
        email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });

        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Room Number:");

        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Bed Number:");

        roomid.setEditable(false);
        roomid.setBackground(new java.awt.Color(255, 255, 255));
        roomid.setForeground(new java.awt.Color(0, 0, 0));
        roomid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        bedid.setEditable(false);
        bedid.setBackground(new java.awt.Color(255, 255, 255));
        bedid.setForeground(new java.awt.Color(0, 0, 0));
        bedid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Emergency Contact Number:");

        emergencycontactnumber.setBackground(new java.awt.Color(255, 255, 255));
        emergencycontactnumber.setForeground(new java.awt.Color(0, 0, 0));
        emergencycontactnumber.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Emergency Contact Name:");

        emergencycontactname.setBackground(new java.awt.Color(255, 255, 255));
        emergencycontactname.setForeground(new java.awt.Color(0, 0, 0));
        emergencycontactname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Relationship:");

        relationship.setBackground(new java.awt.Color(255, 255, 255));
        relationship.setForeground(new java.awt.Color(0, 0, 0));
        relationship.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout reservation_informationLayout = new javax.swing.GroupLayout(reservation_information);
        reservation_information.setLayout(reservation_informationLayout);
        reservation_informationLayout.setHorizontalGroup(
            reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservation_informationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(reservation_informationLayout.createSequentialGroup()
                        .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(83, 83, 83)
                        .addComponent(email))
                    .addGroup(reservation_informationLayout.createSequentialGroup()
                        .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fullname)
                            .addComponent(contactnumber)
                            .addComponent(gender)
                            .addComponent(fbaccount)))
                    .addGroup(reservation_informationLayout.createSequentialGroup()
                        .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18)
                        .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bedid)
                            .addComponent(roomid))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reservation_informationLayout.createSequentialGroup()
                        .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(reservation_informationLayout.createSequentialGroup()
                                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(relationship, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(emergencycontactnumber)
                                .addComponent(emergencycontactname, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)))))
                .addGap(15, 15, 15))
        );
        reservation_informationLayout.setVerticalGroup(
            reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservation_informationLayout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(roomid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(bedid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(contactnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(fbaccount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(emergencycontactnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(emergencycontactname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reservation_informationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(relationship, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 317, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        register.setBackground(new java.awt.Color(255, 255, 255));
        register.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        register.setForeground(new java.awt.Color(0, 0, 0));
        register.setText("Register");
        register.setBorderPainted(false);
        register.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerActionPerformed(evt);
            }
        });

        cancel.setForeground(new java.awt.Color(0, 0, 0));
        cancel.setText("cancel");
        cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cancel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(register)
                        .addGap(32, 32, 32))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(reservation_information, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tenantcode)
                                .addGap(18, 18, 18)
                                .addComponent(verify))
                            .addComponent(jLabel2))
                        .addContainerGap(20, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(tenantcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(verify))
                .addGap(6, 6, 6)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reservation_information, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(register)
                    .addComponent(cancel))
                .addContainerGap(18, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void verifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verifyActionPerformed
       

        String tenantCode = tenantcode.getText();  // Assuming tenant code is entered in a text field
    if (tenantCode.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a tenant code.");
    } else {
        System.out.println("Tenant Code (before query): '" + tenantCode + "'");
        verifyTenantCode(tenantCode);  // Call the method to verify tenant code and populate fields
    }
    }//GEN-LAST:event_verifyActionPerformed

    private void tenantcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tenantcodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tenantcodeActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void genderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genderActionPerformed

    private void registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerActionPerformed
        String facebookAccount = fbaccount.getText();  // Assuming text field for Facebook account
        String emergencyName = emergencycontactname.getText();  // Assuming emergency contact name field
        String emergencyRelationship = relationship.getText();  // Assuming emergency relationship field
        String emergencyNumber = emergencycontactnumber.getText();  // Assuming emergency contact number field
        String tenantCode = tenantcode.getText();  // Assuming tenant code field

        // Validate required fields
        if (facebookAccount.isEmpty() || emergencyName.isEmpty() || emergencyRelationship.isEmpty() || emergencyNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
        } else {
            // Call the method to update tenant info with the appropriate parameters
            registerTenant(tenantCode, facebookAccount, emergencyName, emergencyRelationship, emergencyNumber);
        }
    }//GEN-LAST:event_registerActionPerformed

    private void cancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelMouseClicked
        Login log = new Login();
        log.setVisible(true);
        log.pack();
        log.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_cancelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bedid;
    private javax.swing.JLabel cancel;
    private javax.swing.JTextField contactnumber;
    private javax.swing.JTextField email;
    private javax.swing.JTextField emergencycontactname;
    private javax.swing.JTextField emergencycontactnumber;
    private javax.swing.JTextField fbaccount;
    private javax.swing.JTextField fullname;
    private javax.swing.JTextField gender;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton register;
    private javax.swing.JTextField relationship;
    private javax.swing.JPanel reservation_information;
    private javax.swing.JTextField roomid;
    private javax.swing.JTextField tenantcode;
    private javax.swing.JButton verify;
    // End of variables declaration//GEN-END:variables
}
