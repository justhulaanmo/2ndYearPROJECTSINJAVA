
package Tenant;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import org.mindrot.jbcrypt.BCrypt;
import Config.DBconnection;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.*;



public class ChangePassword extends javax.swing.JFrame {

    private int userId;
    private boolean isPasswordVisible = false;
    private boolean isForgotPassword = false;

    public ChangePassword(){
        
    }
    
    public ChangePassword(int userId) {
        this.userId = userId;
        this.isForgotPassword = false;
        initComponents();
        setupUI();
    }

    public ChangePassword(int userId, boolean isForgotPassword) {
        this.userId = userId;
        this.isForgotPassword = isForgotPassword;
        initComponents();
        setupUI();

        // Hide current password panel if forgot password
        if (isForgotPassword) {
            currentpasspanel.setVisible(false);
        }
    }

    private void setupUI() {
        setLocationRelativeTo(null);
        passwordcriteriapanel.setVisible(true);

        newPasswordField.setEchoChar('.');
        jButton2.setText("Show");

        lblUppercaseCheck.setText("✘ One uppercase letter");
        lblUppercaseCheck.setForeground(Color.RED);

        lblNumberCheck.setText("✘ One number");
        lblNumberCheck.setForeground(Color.RED);

        lblSpecialCharCheck.setText("✘ One special character");
        lblSpecialCharCheck.setForeground(Color.RED);

        lblLengthCheck.setText("✘ At least 8 characters");
        lblLengthCheck.setForeground(Color.RED);

        newPasswordField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String password = new String(newPasswordField.getPassword());
                updatePasswordStrength(password);
            }
        });

        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isPasswordVisible = !isPasswordVisible;
                if (isPasswordVisible) {
                    newPasswordField.setEchoChar((char) 0);
                    jButton2.setText("Hide");
                } else {
                    newPasswordField.setEchoChar('•');
                    jButton2.setText("Show");
                }
            }
        });
    }

    private void changePassword(int userId, String currentPassword, String newPassword) {
        Connection conn = DBconnection.getConnection();

        try {
            String query = "SELECT password_hash FROM users WHERE user_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password_hash");

                if (!isForgotPassword && !BCrypt.checkpw(currentPassword, storedHash)) {
                    JOptionPane.showMessageDialog(null, "Current password is incorrect.");
                    return;
                }

                String newHash = BCrypt.hashpw(newPassword, BCrypt.gensalt(10));
                String update = "UPDATE users SET password_hash = ?, status = 'Registered' WHERE user_id = ?";
                ps = conn.prepareStatement(update);
                ps.setString(1, newHash);
                ps.setInt(2, userId);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Password changed successfully.");
                this.dispose();

                if (!isForgotPassword) {
                    new tenant_dashboard().setVisible(true);
                } else {
                    new Login().setVisible(true);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updatePasswordStrength(String password) {
        boolean hasUpper = password.matches(".*[A-Z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSymbol = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
        boolean isLongEnough = password.length() >= 8;
        boolean noForbiddenWords = !password.toLowerCase().contains("password") &&
                                   !password.toLowerCase().contains("redhat");

        int score = 0;
        if (hasUpper) score++;
        if (hasDigit) score++;
        if (hasSymbol) score++;
        if (isLongEnough) score++;

        lblUppercaseCheck.setText(hasUpper ? "✔ One uppercase letter" : "✘ One uppercase letter");
        lblUppercaseCheck.setForeground(hasUpper ? Color.GREEN.darker() : Color.RED);

        lblNumberCheck.setText(hasDigit ? "✔ One number" : "✘ One number");
        lblNumberCheck.setForeground(hasDigit ? Color.GREEN.darker() : Color.RED);

        lblSpecialCharCheck.setText(hasSymbol ? "✔ One special character" : "✘ One special character");
        lblSpecialCharCheck.setForeground(hasSymbol ? Color.GREEN.darker() : Color.RED);

        lblLengthCheck.setText(isLongEnough ? "✔ At least 8 characters" : "✘ At least 8 characters");
        lblLengthCheck.setForeground(isLongEnough ? Color.GREEN.darker() : Color.RED);

        if (!isLongEnough || score < 2) {
            lblStrength.setText("Weak");
            lblStrength.setForeground(Color.RED);
        } else if (score == 3) {
            lblStrength.setText("Medium");
            lblStrength.setForeground(Color.ORANGE);
        } else if (score == 4 && noForbiddenWords) {
            lblStrength.setText("Strong");
            lblStrength.setForeground(Color.GREEN.darker());
        }
    }

    private boolean isStrongPassword(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        return password.matches(pattern);
    }

    // Make sure your submit button will call changePassword like this:
    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {
        String currentPass = new String(currentPasswordField.getPassword());
        String newPass = new String(newPasswordField.getPassword());
        String confirmPass = new String(confirmPasswordField.getPassword());

        if (!newPass.equals(confirmPass)) {
            JOptionPane.showMessageDialog(null, "New passwords do not match.");
            return;
        }

        if (!isStrongPassword(newPass)) {
            JOptionPane.showMessageDialog(null, "Password does not meet security criteria.");
            return;
        }

        changePassword(userId, currentPass, newPass);
    }



   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        newPasswordField = new javax.swing.JPasswordField();
        confirmPasswordField = new javax.swing.JPasswordField();
        confirmbutton = new javax.swing.JButton();
        passwordcriteriapanel = new javax.swing.JPanel();
        lblUppercaseCheck = new javax.swing.JLabel();
        lblNumberCheck = new javax.swing.JLabel();
        lblSpecialCharCheck = new javax.swing.JLabel();
        lblLengthCheck = new javax.swing.JLabel();
        lblStrength = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        currentpasspanel = new javax.swing.JPanel();
        currentPasswordField = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Change Password");

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("New Password:");

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Confirm Password:");

        newPasswordField.setBackground(new java.awt.Color(255, 255, 255));
        newPasswordField.setForeground(new java.awt.Color(0, 0, 0));

        confirmPasswordField.setBackground(new java.awt.Color(255, 255, 255));
        confirmPasswordField.setForeground(new java.awt.Color(0, 0, 0));
        confirmPasswordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmPasswordFieldActionPerformed(evt);
            }
        });

        confirmbutton.setBackground(new java.awt.Color(255, 255, 255));
        confirmbutton.setForeground(new java.awt.Color(0, 0, 0));
        confirmbutton.setText("Confirm");
        confirmbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmbuttonActionPerformed(evt);
            }
        });

        passwordcriteriapanel.setBackground(new java.awt.Color(255, 255, 255));
        passwordcriteriapanel.setForeground(new java.awt.Color(0, 0, 0));
        passwordcriteriapanel.setLayout(new java.awt.GridLayout(4, 0));

        lblUppercaseCheck.setForeground(new java.awt.Color(0, 0, 0));
        passwordcriteriapanel.add(lblUppercaseCheck);

        lblNumberCheck.setForeground(new java.awt.Color(0, 0, 0));
        passwordcriteriapanel.add(lblNumberCheck);

        lblSpecialCharCheck.setForeground(new java.awt.Color(0, 0, 0));
        passwordcriteriapanel.add(lblSpecialCharCheck);
        passwordcriteriapanel.add(lblLengthCheck);

        lblStrength.setBackground(new java.awt.Color(204, 204, 204));
        lblStrength.setForeground(new java.awt.Color(204, 255, 255));

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Helvetica Neue", 0, 11)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 0));
        jButton2.setText("show");

        currentpasspanel.setBackground(new java.awt.Color(255, 255, 255));

        currentPasswordField.setBackground(new java.awt.Color(255, 255, 255));
        currentPasswordField.setForeground(new java.awt.Color(0, 0, 0));

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Current Password:");

        javax.swing.GroupLayout currentpasspanelLayout = new javax.swing.GroupLayout(currentpasspanel);
        currentpasspanel.setLayout(currentpasspanelLayout);
        currentpasspanelLayout.setHorizontalGroup(
            currentpasspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, currentpasspanelLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(currentPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65))
        );
        currentpasspanelLayout.setVerticalGroup(
            currentpasspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, currentpasspanelLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(currentpasspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(currentPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(168, 168, 168)
                .addComponent(confirmbutton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(currentpasspanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblStrength, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel3))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(newPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(passwordcriteriapanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(confirmPasswordField, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE))))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(29, 29, 29))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(currentpasspanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(lblStrength, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(passwordcriteriapanel, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(confirmPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(40, 40, 40)
                .addComponent(confirmbutton)
                .addGap(34, 34, 34))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void confirmbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmbuttonActionPerformed
    String currentPass = currentPasswordField.getText();
    String newPass = newPasswordField.getText();
    String confirmPass = confirmPasswordField.getText();

    if (!newPass.equals(confirmPass)) {
        JOptionPane.showMessageDialog(this, "New passwords do not match.");
        return;
    }

    if (!isStrongPassword(newPass)) {
        JOptionPane.showMessageDialog(this,
            "Password must be at least 8 characters long,\ninclude an uppercase letter, number, and special character (!@#$...).",
            "Weak Password", JOptionPane.WARNING_MESSAGE);
        return;
    }

    changePassword(userId, currentPass, newPass);
    }//GEN-LAST:event_confirmbuttonActionPerformed

    private void confirmPasswordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmPasswordFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_confirmPasswordFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ChangePassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ChangePassword().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField confirmPasswordField;
    private javax.swing.JButton confirmbutton;
    private javax.swing.JPasswordField currentPasswordField;
    private javax.swing.JPanel currentpasspanel;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblLengthCheck;
    private javax.swing.JLabel lblNumberCheck;
    private javax.swing.JLabel lblSpecialCharCheck;
    private javax.swing.JLabel lblStrength;
    private javax.swing.JLabel lblUppercaseCheck;
    private javax.swing.JPasswordField newPasswordField;
    private javax.swing.JPanel passwordcriteriapanel;
    // End of variables declaration//GEN-END:variables
}
