package Tenant;

import Config.DBconnection;
import Admin.admin_dashboard;
import Tenant.ChangePassword;
import Tenant.tenant_dashboard;
import Tenant.reservation;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import javax.mail.MessagingException;
import javax.swing.JOptionPane;
import org.mindrot.jbcrypt.BCrypt;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class Login extends javax.swing.JFrame {
    
    public static int userId;
    public static int tenantId;
    public static int roomId;
    public static String currentUser;


 
    public Login() {
        initComponents();
        setLocationRelativeTo(null);
        
       System.out.println("Panel width: " + rightpanel.getWidth());
        System.out.println("Panel height: " + rightpanel.getHeight());


        
        showHideLabel.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
        togglePasswordVisibility();
    }
});

        
    }
    
    
        private boolean login(String username, String password) {
    Connection conn = DBconnection.getConnection();

    if (conn != null) {
        try {
            String query = "SELECT * FROM users WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String storedPasswordHash = rs.getString("password_hash");
                String role = rs.getString("role");
                String status = rs.getString("status");
                int userIdFromDB = rs.getInt("user_id");

                if (!status.equals("Registered")) {
                    JOptionPane.showMessageDialog(null, "Your account is not yet registered.");
                    return false;
                }

                if (BCrypt.checkpw(password, storedPasswordHash)) {
                    Login.userId = userIdFromDB;

                    if (role.equals("Owner")) {
                        Login.currentUser = "admin";
                        new admin_dashboard().setVisible(true); // or your actual admin dashboard class
                    } else if (role.equals("Tenant")) {
                        // Get tenant info
                        String tenantQuery = "SELECT tenant_id, room_id, full_name FROM tenants WHERE user_id = ?";
                        PreparedStatement tenantStmt = conn.prepareStatement(tenantQuery);
                        tenantStmt.setInt(1, userIdFromDB);
                        ResultSet tenantRs = tenantStmt.executeQuery();

                        if (tenantRs.next()) {
                            Login.tenantId = tenantRs.getInt("tenant_id");
                            Login.roomId = tenantRs.getInt("room_id");
                            Login.currentUser = tenantRs.getString("full_name");

                            // Default password warning logic (optional)
                            String defaultPassword = Login.currentUser.replaceAll("\\s+", "") +
                                                      getTenantCode(Login.tenantId);
                            if (BCrypt.checkpw(defaultPassword, storedPasswordHash)) {
                                JOptionPane.showMessageDialog(null,
                                    "You are still using the default password.\nPlease change it.",
                                    "Change Password", JOptionPane.INFORMATION_MESSAGE);
                                new ChangePassword(Login.userId).setVisible(true);
                            } else {
                                new tenant_dashboard().setVisible(true);
                            }
                        }
                    }
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    return false;
}

        
        

        private String getTenantCode(int tenantId) {
        String code = "";
        try (Connection conn = DBconnection.getConnection()) {
            String query = "SELECT tenant_code FROM tenants WHERE tenant_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, tenantId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                code = rs.getString("tenant_code");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return code;
    }

        private String getUserRole(String username) {
            String role = "";
            Connection conn = DBconnection.getConnection(); // Assuming db_connect provides the connection

            if (conn != null) {
                try {
                    // SQL query to fetch the user role based on the username
                    String query = "SELECT role FROM users WHERE username = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, username);
                    ResultSet rs = stmt.executeQuery();

                    // Get the role from the result set
                    if (rs.next()) {
                        role = rs.getString("role");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
            return role;
        }

        private void togglePasswordVisibility() {
        if (password.getEchoChar() == (char) 0) {
            // Password is visible, hide it
            password.setEchoChar('*');
            showHideLabel.setText("Show");
        } else {
            // Password is hidden, show it
            password.setEchoChar((char) 0);
            showHideLabel.setText("Hide");
        }
    }
        
        public String generateOTP() {
    Random rand = new Random();
    int otp = 100000 + rand.nextInt(900000); // 6-digit OTP
    return String.valueOf(otp);
}

 
        public boolean sendOTPEmail(String toEmail, String otp) {
    final String fromEmail = "itsbeasarong@gmail.com"; // change
    final String password = "sdfu itqy dddw felt";     // use app password, NOT Gmail password

    Properties props = new Properties();
    props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(fromEmail, password);
        }
    });

    try {
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromEmail));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        message.setSubject("Your OTP Code");
        message.setText("Your OTP is: " + otp);

        Transport.send(message);
        return true;
    } catch (MessagingException e) {
        e.printStackTrace();
        return false;
    }
}




    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        leftpanel = new javax.swing.JPanel();
        login_lbl = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        email_lbl = new javax.swing.JLabel();
        password_lbl = new javax.swing.JLabel();
        login = new javax.swing.JButton();
        forgotpassword = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        reserve = new javax.swing.JButton();
        register = new javax.swing.JButton();
        showHideLabel = new javax.swing.JLabel();
        rightpanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setResizable(false);

        leftpanel.setBackground(new java.awt.Color(0, 153, 153));
        leftpanel.setForeground(new java.awt.Color(255, 255, 255));
        leftpanel.setToolTipText("");

        login_lbl.setBackground(new java.awt.Color(0, 0, 0));
        login_lbl.setFont(new java.awt.Font("Avenir", 1, 36)); // NOI18N
        login_lbl.setForeground(new java.awt.Color(255, 255, 255));
        login_lbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        login_lbl.setText("LOGIN");

        email.setBackground(new java.awt.Color(0, 153, 153));
        email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });

        password.setBackground(new java.awt.Color(0, 153, 153));
        password.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        email_lbl.setForeground(new java.awt.Color(255, 255, 255));
        email_lbl.setText("Email");

        password_lbl.setForeground(new java.awt.Color(255, 255, 255));
        password_lbl.setText("Password");

        login.setBackground(new java.awt.Color(204, 204, 204));
        login.setForeground(new java.awt.Color(0, 0, 0));
        login.setText("LOGIN");
        login.setBorderPainted(false);
        login.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        forgotpassword.setForeground(new java.awt.Color(255, 255, 255));
        forgotpassword.setText("Forgot Password?");
        forgotpassword.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        forgotpassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                forgotpasswordMouseClicked(evt);
            }
        });

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("want to reserve bed space?");

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("register your account");

        reserve.setBackground(new java.awt.Color(204, 204, 204));
        reserve.setForeground(new java.awt.Color(0, 0, 0));
        reserve.setText("Reserve");
        reserve.setBorderPainted(false);
        reserve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reserveActionPerformed(evt);
            }
        });

        register.setBackground(new java.awt.Color(204, 204, 204));
        register.setForeground(new java.awt.Color(0, 0, 0));
        register.setText("Register");
        register.setBorderPainted(false);
        register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerActionPerformed(evt);
            }
        });

        showHideLabel.setForeground(new java.awt.Color(255, 255, 255));
        showHideLabel.setText("show");
        showHideLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showHideLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout leftpanelLayout = new javax.swing.GroupLayout(leftpanel);
        leftpanel.setLayout(leftpanelLayout);
        leftpanelLayout.setHorizontalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(reserve)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(register)
                .addGap(53, 53, 53))
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(leftpanelLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(24, 24, 24)
                        .addComponent(jLabel3))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 33, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanelLayout.createSequentialGroup()
                        .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanelLayout.createSequentialGroup()
                                .addComponent(login_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(email_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(forgotpassword))
                                .addComponent(password_lbl)))
                        .addComponent(showHideLabel)
                        .addGap(37, 37, 37))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanelLayout.createSequentialGroup()
                        .addComponent(login)
                        .addGap(141, 141, 141))))
        );
        leftpanelLayout.setVerticalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(login_lbl)
                .addGap(37, 37, 37)
                .addComponent(email_lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(password_lbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(showHideLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(forgotpassword)
                .addGap(42, 42, 42)
                .addComponent(login)
                .addGap(29, 29, 29)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reserve)
                    .addComponent(register))
                .addContainerGap(92, Short.MAX_VALUE))
        );

        rightpanel.setBackground(new java.awt.Color(255, 255, 255));
        rightpanel.setMaximumSize(new java.awt.Dimension(200, 200));

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("HOUSE");

        jLabel5.setFont(new java.awt.Font("Helvetica Neue", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("MANAGEMENT SYSTEM");

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("BOARDING");

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Group 1");

        javax.swing.GroupLayout rightpanelLayout = new javax.swing.GroupLayout(rightpanel);
        rightpanel.setLayout(rightpanelLayout);
        rightpanelLayout.setHorizontalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightpanelLayout.createSequentialGroup()
                            .addGap(54, 54, 54)
                            .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightpanelLayout.createSequentialGroup()
                            .addGap(52, 52, 52)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(rightpanelLayout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addComponent(jLabel1)))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        rightpanelLayout.setVerticalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addComponent(jLabel6)
                .addGap(0, 0, 0)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(rightpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(leftpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(leftpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(rightpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
         String emaill = email.getText();
        String passwordd = new String(password.getPassword());

        // Call the login method from LoginVerification to check credentials
        if (login(emaill, passwordd)) {
            String role = getUserRole(emaill);

            if (role.equals("Owner")) {
                new admin_dashboard().setVisible(true); 
            }
            
            this.dispose();
            
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
  
    }//GEN-LAST:event_loginActionPerformed

    private void reserveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reserveActionPerformed
        reservation reserve = new reservation();
        reserve.setVisible(true);
        reserve.pack();
        reserve.setLocationRelativeTo(null);
       
    }//GEN-LAST:event_reserveActionPerformed

    private void registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerActionPerformed
        registration register = new registration();
        register.setVisible(true);
        register.pack();
        register.setLocationRelativeTo(null);
    }//GEN-LAST:event_registerActionPerformed

    private void showHideLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showHideLabelMouseClicked
    
    }//GEN-LAST:event_showHideLabelMouseClicked

    private void forgotpasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_forgotpasswordMouseClicked
    
      String email = JOptionPane.showInputDialog(null, "Enter your registered email:");

    if (email == null || email.trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please enter your email.");
        return;
    }

    Connection conn = DBconnection.getConnection();
    try {
        String query = "SELECT u.user_id, t.full_name, t.tenant_id " +
                       "FROM users u JOIN tenants t ON u.user_id = t.user_id " +
                       "WHERE u.username = ? AND t.status = 'Registered'";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int userId = rs.getInt("user_id");

            // Prompt user that OTP will be sent
            JOptionPane.showMessageDialog(null, "A 6-digit OTP will be sent to your email.");

            String otp = generateOTP();
            boolean sent = sendOTPEmail(email, otp);

            if (!sent) {
                JOptionPane.showMessageDialog(null, "Failed to send OTP email.");
                return;
            }

            while (true) {
                String userInput = JOptionPane.showInputDialog(null, "Enter the 6-digit OTP sent to your email:");

                if (userInput == null) {
                    // User clicked Cancel
                    JOptionPane.showMessageDialog(null, "OTP entry cancelled.");
                    break;
                }

                if (userInput.equals(otp)) {
                    ChangePassword changePasswordForm = new ChangePassword(userId, true); // forgot password mode
                    changePasswordForm.setVisible(true);
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid OTP. Please try again.");
                }
            }

        } else {
            JOptionPane.showMessageDialog(null, "Email not found or tenant not registered.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Database error occurred.");
    }

    }//GEN-LAST:event_forgotpasswordMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField email;
    private javax.swing.JLabel email_lbl;
    private javax.swing.JLabel forgotpassword;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JPanel leftpanel;
    private javax.swing.JButton login;
    private javax.swing.JLabel login_lbl;
    private javax.swing.JPasswordField password;
    private javax.swing.JLabel password_lbl;
    private javax.swing.JButton register;
    private javax.swing.JButton reserve;
    private javax.swing.JPanel rightpanel;
    private javax.swing.JLabel showHideLabel;
    // End of variables declaration//GEN-END:variables
}
