package Tenant;
import Config.DBconnection;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import java.io.File;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.*;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import javax.swing.table.DefaultTableModel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.text.SimpleDateFormat;
import java.sql.Timestamp;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import com.toedter.calendar.JDayChooser;



public class tenant_dashboard extends javax.swing.JFrame {
    
    private int tenantId;
    private int userId;
    private int roomId;
    private Connection conn;
    private int currentBillingId;
    private String currentBillingPeriod;
    private JButton selectedNotificationButton = null;


    public tenant_dashboard() {
        initComponents();
        setLocationRelativeTo(null);
        
        loadTenantProfile();
  
        this.tenantId = Login.tenantId;
        this.roomId = Login.roomId;
        this.conn = DBconnection.getConnection(); // or reuse a static connection
        
        System.out.println("Logged-in tenant ID: " + tenantId); // Debug
        System.out.println("Room ID: " + roomId);   
        
        reportedby.setText(Login.currentUser);
        loadPendingBilling(); 
        loadPaymentHistory(tenantId);
       
        
        jCalendar1.addPropertyChangeListener("calendar", evt -> {
        java.util.Date utilDate = jCalendar1.getDate();
        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
        onMonthSelected(sqlDate);
    });     
        
        monthlybill.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        String selectedPeriod = (String) monthlybill.getSelectedItem();
        if (selectedPeriod != null) {
            loadRentInfoForPeriod(tenantId, selectedPeriod);
        }
    }
});
        
        try {
        String query = "SELECT user_id FROM tenants WHERE tenant_id = ?";
        PreparedStatement pst = conn.prepareStatement(query);
        pst.setInt(1, tenantId);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            this.userId = rs.getInt("user_id");
            System.out.println("User ID: " + userId); // Debug
        }

        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error retrieving user ID: " + e.getMessage());
    }

       
    }

//=====================================PARA SA TENANT PROFILE=====================================================//
    
        public void loadTenantProfile() {
    Connection conn = DBconnection.getConnection();
    try {
        String query = "SELECT * FROM tenants WHERE tenant_id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, Login.tenantId); // Assuming you saved tenantId globally in Login class
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            tenantcode.setText(rs.getString("tenant_code"));
            roomnumber.setText(rs.getString("room_id"));
            bednumber.setText(rs.getString("bed_number"));
            fullname.setText(rs.getString("full_name"));
            fbaccount.setText(rs.getString("facebook_account"));
            contactnum.setText(rs.getString("contact_number"));
            email.setText(rs.getString("email"));
            gender.setSelectedItem(rs.getString("gender"));
            emergencycontactnum.setText(rs.getString("emergency_contact_number"));
            emergencycontactname.setText(rs.getString("emergency_contact_name"));
            emergencycontactrel.setText(rs.getString("emergency_contact_relationship"));

            // Disable fields that shouldn't be edited
            disableEditing();
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading profile: " + e.getMessage());
    }
}
        
        public void enableEditing() {
        fbaccount.setEditable(true);
        contactnum.setEditable(true);
        emergencycontactnum.setEditable(true);
        emergencycontactname.setEditable(true);
        emergencycontactrel.setEditable(true);

        btnEdit.setEnabled(false);
        btnSave.setEnabled(true);
    }

    public void disableEditing() {
        fbaccount.setEditable(false);
        contactnum.setEditable(false);
        emergencycontactnum.setEditable(false);
        emergencycontactname.setEditable(false);
        emergencycontactrel.setEditable(false);

        btnEdit.setEnabled(true);
        btnSave.setEnabled(false);
    }
    
        public void saveTenantProfile() {
        Connection conn = DBconnection.getConnection();
        try {
            String updateQuery = "UPDATE tenants SET facebook_account = ?, contact_number = ?, emergency_contact_name = ?, emergency_contact_relationship = ?, emergency_contact_number = ? WHERE tenant_id = ?";
            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            stmt.setString(1, fbaccount.getText());
            stmt.setString(2, contactnum.getText());
            stmt.setString(3, emergencycontactname.getText());
            stmt.setString(4, emergencycontactrel.getText());
            stmt.setString(5, emergencycontactnum.getText());
            stmt.setInt(6, Login.tenantId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Profile updated successfully.");
                disableEditing();
            } else {
                JOptionPane.showMessageDialog(null, "No changes were made.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error updating profile: " + e.getMessage());
        }
    }

//=====================================PARA SA RENT INFORMATION=====================================================//


     private void loadRentInfoForPeriod(int tenantId, String billingPeriod) {
    String billingQuery = "SELECT * FROM billing_payments WHERE tenant_id = ? AND billing_period = ? ORDER BY billing_id DESC LIMIT 1";
    String applianceQuery = "SELECT appliance_name, quantity, total_fee FROM appliances WHERE user_id = ? AND billing_period = ?";
    String getUserIdQuery = "SELECT user_id FROM tenants WHERE tenant_id = ?";

    try (Connection conn = DBconnection.getConnection();
         PreparedStatement pstBill = conn.prepareStatement(billingQuery);
         PreparedStatement pstAppliance = conn.prepareStatement(applianceQuery);
         PreparedStatement pstUser = conn.prepareStatement(getUserIdQuery)) {

        int userId = 0;
        pstUser.setInt(1, tenantId);
        ResultSet rsUser = pstUser.executeQuery();
        if (rsUser.next()) {
            userId = rsUser.getInt("user_id");
        }
        rsUser.close();

        pstBill.setInt(1, tenantId);
        pstBill.setString(2, billingPeriod);
        ResultSet rsBill = pstBill.executeQuery();

        long lateFee = 0;
        double applianceTotal = 0;
        double rentAmount = 1180 + 80;
        StringBuilder breakdown = new StringBuilder();

        if (rsBill.next()) {
            rentAmount = rsBill.getDouble("amount_due");
            double rentOnly = rentAmount - 80;

            rent.setText(String.valueOf(rentOnly));
            gasoline.setText("80.0");
            subtotal.setText(String.valueOf(rentAmount));

            // New Late Fee Calculation
            Date dueDate = rsBill.getDate("due_date");
            Date paymentDate = rsBill.getDate("payment_date");
            Date referenceDate = (paymentDate != null) ? paymentDate : new java.sql.Date(System.currentTimeMillis());
            
            if (dueDate != null && referenceDate.after(dueDate)) {
                long diffInMillies = referenceDate.getTime() - dueDate.getTime();
                long daysLate = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                lateFee = daysLate * 5;

                breakdown.append("Late Fee: ₱").append(lateFee)
                         .append(" (").append(daysLate).append(" days late)\n")
                         .append("Due: ").append(dueDate)
                         .append("\nReference: ").append(referenceDate)
                         .append("\n\n=====================\n\n");
            } else {
                breakdown.append("Late Fee: ₱0.00\n")
                         .append("Due: ").append(dueDate)
                         .append("\nReference: ").append(referenceDate)
                         .append("\n\n");
            }
        }

        pstAppliance.setInt(1, userId);
        pstAppliance.setString(2, billingPeriod);
        ResultSet rsAppliance = pstAppliance.executeQuery();

        breakdown.append("---- Appliance Summary ----\n\n");
        boolean hasAppliances = false;

        while (rsAppliance.next()) {
            hasAppliances = true;
            String name = rsAppliance.getString("appliance_name");
            int qty = rsAppliance.getInt("quantity");
            double fee = rsAppliance.getDouble("total_fee");

            applianceTotal += fee;

            breakdown.append(name)
                     .append(" x").append(qty)
                     .append(" - ₱").append(String.format("%.2f", fee))
                     .append("\n");
        }

        if (!hasAppliances) {
            breakdown.append("No appliances listed for this period.\n");
        }

        breakdown.append("\nTotal Appliance Fee: ₱").append(String.format("%.2f", applianceTotal)).append("\n");
        additionfee.setText(breakdown.toString());

        double totalAmount = rentAmount + applianceTotal + lateFee;
        total.setText(String.format("%.2f", totalAmount));

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading rent info: " + e.getMessage());
    }
}



        private void loadBillingPeriods(int tenantId) {
            try (Connection conn = DBconnection.getConnection()) {
                String query = "SELECT DISTINCT billing_period FROM billing_payments WHERE tenant_id = ? ORDER BY billing_id DESC";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setInt(1, tenantId);

                ResultSet rs = pst.executeQuery();
                monthlybill.removeAllItems(); // Clear previous items

                while (rs.next()) {
                    String period = rs.getString("billing_period");
                    monthlybill.addItem(period);
                }

                rs.close();
                pst.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error loading billing periods: " + e.getMessage());
            }
        }


    
//=====================================PARA SA BILLINGS MONTHLY=====================================================//
    
  private void loadPendingBilling() {
    try {
        // Generate any missing bills before loading the current one
        generateMissingBills(tenantId);

        // Get move_in_date from tenants table for display or logic (optional UI)
        String moveInSql = "SELECT move_in_date FROM tenants WHERE tenant_id = ?";
        PreparedStatement moveInStmt = conn.prepareStatement(moveInSql);
        moveInStmt.setInt(1, tenantId);
        ResultSet moveInRs = moveInStmt.executeQuery();
        Date moveInDate = null;

        if (moveInRs.next()) {
            moveInDate = moveInRs.getDate("move_in_date");
            if (moveInDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
                billingperiod.setToolTipText("Move-in date: " + sdf.format(moveInDate)); // Optional tooltip
            }
        }

        // Load the earliest unpaid bill for tenant
        String retrieveSql = "SELECT billing_id, billing_period, amount_due, due_date FROM billing_payments " +
                             "WHERE tenant_id = ? AND payment_status = 'Unpaid' ORDER BY due_date ASC LIMIT 1";
        PreparedStatement retrieveStmt = conn.prepareStatement(retrieveSql);
        retrieveStmt.setInt(1, tenantId);
        ResultSet billingRs = retrieveStmt.executeQuery();

        if (billingRs.next()) {
            String billingPeriodStr = billingRs.getString("billing_period");
            currentBillingPeriod = billingPeriodStr;
            double amountDue = billingRs.getDouble("amount_due");
            Date dueDate = billingRs.getDate("due_date");
            int billingId = billingRs.getInt("billing_id");

            // 1. Calculate overdue fee based on due_date
            double overdueFee = computeOverdueFee(dueDate);

            // 2. Compute appliance fee
            double applianceFee = calculateApplianceFeeFromApplianceTable(userId, billingPeriodStr);

            // 3. Display in UI
            billingperiod.setText(billingPeriodStr);
            duepay.setText(String.format("%.2f", amountDue));
            additionalfee.setText(String.format("%.2f", applianceFee));
            overduepay.setText(String.format("%.2f", overdueFee));
            totaltopay.setText(String.format("%.2f", amountDue + applianceFee + overdueFee));

            currentBillingId = billingId;


            // 5. Default payment method dropdown (optional: preload existing if any)
            modeofpayment.setSelectedItem(0); // or load from DB if set

            // Highlight overdue dates
            if (overdueFee > 0) {
                highlightOverdueDates(dueDate);
            }

        } else {
            // No unpaid bills
            billingperiod.setText("No Unpaid Bills");
            duepay.setText("0.00");
            additionalfee.setText("0.00");
            overduepay.setText("0.00");
            totaltopay.setText("0.00");
            modeofpayment.setSelectedIndex(0);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
}

  
   private double calculateApplianceFeeFromApplianceTable(int userId, String billingPeriod) {
    double total = 0;
    try (Connection conn = DBconnection.getConnection()) {
        String sql = "SELECT total_fee FROM appliances WHERE user_id = ? AND billing_period = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, userId);
        pst.setString(2, billingPeriod);
        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            total += rs.getDouble("total_fee");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return total;
}


   private void generateMissingBills(int tenantId) {
    try {
        // Get the latest billing period
        String lastBillSql = "SELECT billing_period FROM billing_payments WHERE tenant_id = ? ORDER BY due_date DESC LIMIT 1";
        PreparedStatement lastBillStmt = conn.prepareStatement(lastBillSql);
        lastBillStmt.setInt(1, tenantId);
        ResultSet rs = lastBillStmt.executeQuery();

        Calendar cal = Calendar.getInstance();

        // Determine the start month
        if (rs.next()) {
            String lastPeriod = rs.getString("billing_period"); // e.g., "February 2025"
            java.util.Date utilDate = new SimpleDateFormat("MMMM yyyy").parse(lastPeriod);
            java.sql.Date lastDate = new java.sql.Date(utilDate.getTime());
            cal.setTime(lastDate);
            cal.add(Calendar.MONTH, 1); // Start from next month
        } else {
            // No bill exists yet — start from current month
            cal = Calendar.getInstance();
        }

        Calendar now = Calendar.getInstance();
        now.set(Calendar.DAY_OF_MONTH, 1); // Ensure comparison is correct

        while (!cal.after(now)) {
            String billingPeriod = new SimpleDateFormat("MMMM yyyy").format(cal.getTime());
            generateAndInsertBilling(tenantId, billingPeriod); // Modify generateAndInsertBilling to accept period
            cal.add(Calendar.MONTH, 1);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

       public void generateAndInsertBilling(int tenantId, String billingPeriod) {
    try {
        String tenantSQL = "SELECT full_name, room_id, bed_number, move_in_date FROM tenants WHERE tenant_id = ?";
        PreparedStatement tenantStmt = conn.prepareStatement(tenantSQL);
        tenantStmt.setInt(1, tenantId);
        ResultSet tenantRs = tenantStmt.executeQuery();

        if (!tenantRs.next()) return;

        String fullName = tenantRs.getString("full_name");
        int roomId = tenantRs.getInt("room_id");
        int bedNumber = tenantRs.getInt("bed_number");
        Date moveInDate = tenantRs.getDate("move_in_date");

        // Prevent duplicate billing
        String checkSQL = "SELECT COUNT(*) FROM billing_payments WHERE tenant_id = ? AND billing_period = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkSQL);
        checkStmt.setInt(1, tenantId);
        checkStmt.setString(2, billingPeriod);
        ResultSet checkRs = checkStmt.executeQuery();
        checkRs.next();
        if (checkRs.getInt(1) > 0) return;

        double baseRent = 1260.00;
        double applianceFee = calculateApplianceFee(tenantId, billingPeriod);
        double totalPayable = baseRent + applianceFee;

        // Use move-in day of month as due day
        int dueDay = 1;
        if (moveInDate != null) {
            Calendar moveInCal = Calendar.getInstance();
            moveInCal.setTime(moveInDate);
            dueDay = moveInCal.get(Calendar.DAY_OF_MONTH);
        }

        // Set due date based on billing period month and move-in day
        Calendar dueCal = Calendar.getInstance();
        dueCal.setTime(new SimpleDateFormat("MMMM yyyy").parse(billingPeriod));
        dueCal.set(Calendar.DAY_OF_MONTH, Math.min(dueDay, dueCal.getActualMaximum(Calendar.DAY_OF_MONTH))); // avoid invalid days
        java.sql.Date dueDate = new java.sql.Date(dueCal.getTimeInMillis());

        String insertSQL = "INSERT INTO billing_payments (tenant_id, billing_period, due_date, amount_due, payment_status) " +
                           "VALUES (?, ?, ?, ?, 'Unpaid')";
        PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
        insertStmt.setInt(1, tenantId);
        insertStmt.setString(2, billingPeriod);
        insertStmt.setDate(3, dueDate);
        //insertStmt.setDouble(4, applianceFee);
        insertStmt.setDouble(4, baseRent);

        insertStmt.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}


        private double computeOverdueFee(Date dueDate) {
            long currentTime = System.currentTimeMillis();
            long dueTime = dueDate.getTime();

            if (currentTime > dueTime) {
                long diffDays = (currentTime - dueTime) / (1000 * 60 * 60 * 24);
                return diffDays * 5.0;
            } else {
                return 0.0;
            }
        }
        

       private void onMonthSelected(Date selectedDate) {
    SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy");
    String billingPeriod = sdf.format(selectedDate);

    try {
        String sql = "SELECT * FROM billing_payments WHERE tenant_id = ? AND billing_period = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, tenantId);
        stmt.setString(2, billingPeriod);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            // Fill fields
            billingperiod.setText(billingPeriod);

            double amountDue = rs.getDouble("amount_due");
            Date dueDate = rs.getDate("due_date");
            double lateFee = computeOverdueFee(dueDate);
            double applianceFee = calculateApplianceFee(tenantId, billingPeriod);
            double totalToPay = amountDue + lateFee + applianceFee;

            duepay.setText(String.format("%.2f", amountDue));
            overduepay.setText(String.format("%.2f", lateFee));
            additionalfee.setText(String.format("%.2f", applianceFee));
            totaltopay.setText(String.format("%.2f", totalToPay));

            currentBillingId = rs.getInt("billing_id");

            // Disable PayNow button if already paid
            String status = rs.getString("payment_status");
            paynow.setEnabled(!"Paid".equalsIgnoreCase(status));
        } else {
            // No billing found for that month
            JOptionPane.showMessageDialog(this, "No billing record found for selected month.");
            clearBillingFields();
            paynow.setEnabled(false);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
        
    private double calculateApplianceFee(int tenantId, String billingPeriod) {
    double totalFee = 0.0;
    try {
        String sql = "SELECT a.total_fee " +
                     "FROM appliances a JOIN users u ON a.user_id = u.user_id " +
                     "JOIN tenants t ON u.username = t.email " +
                     "WHERE t.tenant_id = ? AND a.billing_period = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, tenantId);
        stmt.setString(2, billingPeriod);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
        totalFee += rs.getDouble("total_fee");
    }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return totalFee;
}
    
    private void clearBillingFields() {
    billingperiod.setText("");
    duepay.setText("");
    additionalfee.setText("");
    overduepay.setText("");
    totaltopay.setText("");
}

    
  private void highlightOverdueDates(Date dueDate) {
    // Assuming jCalendar1 is your JCalendar instance
    JDayChooser dayChooser = jCalendar1.getDayChooser();

    Calendar todayCal = Calendar.getInstance();
    Calendar overdueStart = Calendar.getInstance();
    overdueStart.setTime(dueDate);

    // Iterate over all buttons (days of current month)
    Component[] days = dayChooser.getDayPanel().getComponents();
    for (Component comp : days) {
        if (comp instanceof JButton) {
            JButton btn = (JButton) comp;
            try {
                int day = Integer.parseInt(btn.getText());

                Calendar btnCal = Calendar.getInstance();
                btnCal.setTime(jCalendar1.getDate());
                btnCal.set(Calendar.DAY_OF_MONTH, day);

                // If the button date is after due date and before today
                if (btnCal.after(overdueStart) && !btnCal.after(todayCal)) {
                    btn.setBackground(Color.PINK); // Highlight overdue
                } else {
                    btn.setBackground(Color.WHITE); // Normal
                }
            } catch (NumberFormatException e) {
                // Not a valid day button, skip
            }
        }
    }
}


    


 //================================FOR PAYMENT HISTORY==========================================================//
    
    private void loadPaymentHistory(int tenantId) {
    String sql = "SELECT billing_id, billing_period, amount_paid, payment_status, due_date, payment_date, " +
                 "DATEDIFF(payment_date, due_date) AS days_overdue " +
                 "FROM billing_payments WHERE tenant_id = ?";

    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, tenantId);
        ResultSet rs = stmt.executeQuery();

        DefaultTableModel model = (DefaultTableModel) paymenthistorytable.getModel();
        model.setRowCount(0); // Clear previous data

        while (rs.next()) {
            int billingId = rs.getInt("billing_id");
            String billingPeriod = rs.getString("billing_period");
            BigDecimal amountPaidBigDecimal = rs.getBigDecimal("amount_paid");
            double amountPaid = amountPaidBigDecimal != null ? amountPaidBigDecimal.doubleValue() : 0.00;
            String status = rs.getString("payment_status");
            Date dueDate = rs.getDate("due_date");
            Date paymentDate = rs.getDate("payment_date");
            int daysOverdue = rs.getInt("days_overdue");

            double lateFee = 0.00;
            if (paymentDate != null && daysOverdue > 0) {
                lateFee = daysOverdue * 5.00; 
               // updateLateFee(billingId, lateFee); // Auto-update in DB
            }

            String overdueStr = (paymentDate != null && daysOverdue > 0) ? daysOverdue + " day(s)" : "-";

            model.addRow(new Object[]{
                billingPeriod,
                amountPaid,
                status,
                dueDate != null ? dueDate.toString() : "-",
                paymentDate != null ? paymentDate.toString() : "-",
                overdueStr
            });
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error loading payment history.");
    }
}

//    private void updateLateFee(int billingId, double lateFee) {
//    String updateSQL = "UPDATE billing_payments SET late_fee = ? WHERE billing_id = ?";
//
//    try (PreparedStatement updateStmt = conn.prepareStatement(updateSQL)) {
//        updateStmt.setDouble(1, lateFee);
//        updateStmt.setInt(2, billingId);
//        updateStmt.executeUpdate();
//    } catch (SQLException e) {
//        e.printStackTrace();
//        JOptionPane.showMessageDialog(this, "Failed to update late fee.");
//    }
//}


//================================FOR MAINTENANCE REPORT==========================================================// 
    
    private String uploadImage(String originalPath) {
    try {
        // Destination folder inside your project
        String uploadDir = "images/maintenance/";
        Path uploadPath = Paths.get(uploadDir);
        
        // Create the directory if it does not exist
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        
        // Get the file name only (ex: pic.jpg)
        Path sourcePath = Paths.get(originalPath);
        String filename = sourcePath.getFileName().toString();
        
        // Create a unique filename para iwas overwrite (pwede mong dagdagan ng timestamp)
        String uniqueFilename = System.currentTimeMillis() + "_" + filename;
        
        // Destination path
        Path destinationPath = uploadPath.resolve(uniqueFilename);
        
        // Copy file
        Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
        
        // Return path to save to DB (relative path)
        return uploadDir + uniqueFilename;
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
    
    public void loadTenantMaintenanceReports(int tenantId) {
    jPanel6.removeAll(); // Clear previous buttons
    jPanel6.setLayout(new BoxLayout(jPanel6, BoxLayout.Y_AXIS));

    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT mr.report_id, mr.issue_type " +
                       "FROM maintenance_reports mr " +
                       "WHERE mr.tenant_id = ?";

        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, tenantId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int reportId = rs.getInt("report_id");
            String issueType = rs.getString("issue_type");

            JButton issueButton = new JButton(issueType);

          
            issueButton.setPreferredSize(new Dimension(220, 50));
            issueButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
            issueButton.setFocusPainted(false);
            issueButton.setContentAreaFilled(false);
            issueButton.setOpaque(true);
            issueButton.setBackground(new Color(240, 240, 240));
            issueButton.setForeground(new Color(50, 50, 50));
            issueButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
            ));
            issueButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));

            issueButton.addActionListener(e -> {
    try (Connection innerConn = DBconnection.getConnection()) {
        String updatesQuery = "SELECT update_message, updated_at FROM maintenance_updates WHERE report_id = ?";
        PreparedStatement updatesStmt = innerConn.prepareStatement(updatesQuery);
        updatesStmt.setInt(1, reportId);
        ResultSet updatesRs = updatesStmt.executeQuery();

        StringBuilder updates = new StringBuilder();
        while (updatesRs.next()) {
            String updateMessage = updatesRs.getString("update_message");
            Timestamp updatedAt = updatesRs.getTimestamp("updated_at");

            // Format date and time
            String formattedDate = new SimpleDateFormat("MMMM dd, yyyy - hh:mm a").format(updatedAt);

            updates.append("----------------------------------------------\n");
            updates.append(formattedDate).append("\n");
            updates.append(updateMessage).append("\n\n");
        }

        if (updates.length() == 0) {
            commentsection.setText("No updates available.");
        } else {
            commentsection.setText(updates.toString());
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error loading updates: " + ex.getMessage());
    }
});


            jPanel6.add(issueButton);
        }

        jPanel6.revalidate();
        jPanel6.repaint();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading tenant maintenance reports: " + e.getMessage());
    }
}

public void loadNotifications(int userId) {
    notiflistpanel.removeAll(); // Clear previous notifications
    notiflistpanel.setLayout(new BoxLayout(notiflistpanel, BoxLayout.Y_AXIS));

    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT notification_id, message, type, created_at, status FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, userId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int notifId = rs.getInt("notification_id");
            String message = rs.getString("message");
            String type = rs.getString("type");
            Timestamp createdAt = rs.getTimestamp("created_at");
            String status = rs.getString("status");

            // Shortened preview to avoid overflow
            String preview = message.length() > 40 ? message.substring(0, 40) + "..." : message;

            JPanel notifContainer = new JPanel(new BorderLayout());
            notifContainer.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
            notifContainer.setAlignmentX(Component.LEFT_ALIGNMENT);
            notifContainer.setPreferredSize(new Dimension(236, 50));
            notifContainer.setBackground(new Color(245, 245, 245));
            notifContainer.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200)));

            // Preview button
            JButton notifButton = new JButton("<html><body style='width:160px;'>" + preview + "</body></html>");
            notifButton.setFocusPainted(false);
            notifButton.setContentAreaFilled(false);
            notifButton.setOpaque(true);
            notifButton.setBackground(new Color(245, 245, 245));
            notifButton.setForeground(Color.DARK_GRAY);
            notifButton.setFont(status.equals("Unread") ? new Font("SansSerif", Font.BOLD, 12) : new Font("SansSerif", Font.PLAIN, 12));
            notifButton.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 5));
            notifButton.setHorizontalAlignment(SwingConstants.LEFT);

            // Status label
            JLabel statusLabel = new JLabel(status);
            statusLabel.setPreferredSize(new Dimension(50, 20));
            statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
            statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
            statusLabel.setForeground(status.equals("Unread") ? new Color(220, 53, 69) : new Color(108, 117, 125));
            statusLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 5));

            notifButton.addActionListener(e -> {
                // Reset previous highlight
                if (selectedNotificationButton != null) {
                    selectedNotificationButton.setBackground(new Color(245, 245, 245));
                    selectedNotificationButton.setForeground(Color.DARK_GRAY);
                }

                // Update status to 'Read' in database
                try (Connection updateConn = DBconnection.getConnection()) {
                    String updateQuery = "UPDATE notifications SET status = 'Read' WHERE notification_id = ?";
                    PreparedStatement updateStmt = updateConn.prepareStatement(updateQuery);
                    updateStmt.setInt(1, notifId);
                    updateStmt.executeUpdate();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error updating notification status: " + ex.getMessage());
                }

                // Update UI immediately
                statusLabel.setText("Read");
                statusLabel.setForeground(new Color(108, 117, 125));  // Change text color
                notifButton.setFont(new Font("SansSerif", Font.PLAIN, 12));

                // Highlight the clicked button
                notifButton.setBackground(new Color(0, 153, 153)); // Highlight
                notifButton.setForeground(Color.WHITE);
                selectedNotificationButton = notifButton;

                // Show the notification details
                showNotificationDetails(notifId);
            });

            notifContainer.add(notifButton, BorderLayout.CENTER);
            notifContainer.add(statusLabel, BorderLayout.EAST);
            notiflistpanel.add(notifContainer);
        }

        notiflistpanel.revalidate();
        notiflistpanel.repaint();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading notifications: " + e.getMessage());
    }
}



   public void showNotificationDetails(int notifId) {
    try (Connection conn = DBconnection.getConnection()) {

        // First, update the status to 'Read'
        String updateQuery = "UPDATE notifications SET status = 'Read' WHERE notification_id = ?";
        PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
        updateStmt.setInt(1, notifId);
        updateStmt.executeUpdate();

        // Then, fetch full details
        String selectQuery = "SELECT message, type, created_at FROM notifications WHERE notification_id = ?";
        PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
        selectStmt.setInt(1, notifId);
        ResultSet rs = selectStmt.executeQuery();

        if (rs.next()) {
            String message = rs.getString("message");
            String type = rs.getString("type");
            Timestamp createdAt = rs.getTimestamp("created_at");

            messageTextArea.setText(message);  // JTextArea
            typeLabel.setText("Type: " + type);
            dateLabel.setText("Date: " + createdAt.toString());
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading message: " + e.getMessage());
    }
}







    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        rentinformation = new javax.swing.JButton();
        paymenthistory = new javax.swing.JButton();
        logout = new javax.swing.JLabel();
        Notifications = new javax.swing.JButton();
        reportmaintenance = new javax.swing.JButton();
        profile = new javax.swing.JButton();
        Parent = new javax.swing.JPanel();
        tenantprofile = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        fullname = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        tenantcode = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        fbaccount = new javax.swing.JTextField();
        contactnum = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        gender = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        emergencycontactnum = new javax.swing.JTextField();
        roomnumber = new javax.swing.JTextField();
        bednumber = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        emergencycontactname = new javax.swing.JTextField();
        emergencycontactrel = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        btnEdit = new javax.swing.JLabel();
        btnSave = new javax.swing.JLabel();
        rentinfo = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        rent = new javax.swing.JTextField();
        gasoline = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        subtotal = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        additionfee = new javax.swing.JTextArea();
        jLabel18 = new javax.swing.JLabel();
        total = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        monthlybill = new javax.swing.JComboBox<>();
        billings = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        duedatetab = new javax.swing.JPanel();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        jLabel24 = new javax.swing.JLabel();
        modeofpayment = new javax.swing.JComboBox<>();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        billingperiod = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        duepay = new javax.swing.JTextField();
        overduepay = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        totaltopay = new javax.swing.JLabel();
        paynow = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        additionalfee = new javax.swing.JTextField();
        paymenthistorytab = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        paymenthistorytable = new javax.swing.JTable();
        notif = new javax.swing.JPanel();
        jSplitPane3 = new javax.swing.JSplitPane();
        containertonotifpanel = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        notiflistpanel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        typeLabel = new javax.swing.JLabel();
        dateLabel = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        messageTextArea = new javax.swing.JTextArea();
        reported = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        rightjScrollPane4 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        commentsection = new javax.swing.JTextArea();
        leftjScrollPane6 = new javax.swing.JScrollPane();
        jPanel6 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        report = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        description = new javax.swing.JTextArea();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        reportedby = new javax.swing.JTextField();
        submit = new javax.swing.JButton();
        firstpath = new javax.swing.JTextField();
        secondpath = new javax.swing.JTextField();
        firstphotoLabel = new javax.swing.JLabel();
        secondphotoLabel = new javax.swing.JLabel();
        issuetype = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(759, 517));
        setMinimumSize(new java.awt.Dimension(759, 517));
        setPreferredSize(new java.awt.Dimension(759, 517));
        setResizable(false);
        setSize(new java.awt.Dimension(759, 517));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        rentinformation.setBackground(new java.awt.Color(0, 153, 153));
        rentinformation.setForeground(new java.awt.Color(255, 255, 255));
        rentinformation.setText("    Rent Information");
        rentinformation.setBorder(null);
        rentinformation.setBorderPainted(false);
        rentinformation.setContentAreaFilled(false);
        rentinformation.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        rentinformation.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        rentinformation.setOpaque(true);
        rentinformation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rentinformationActionPerformed(evt);
            }
        });

        paymenthistory.setBackground(new java.awt.Color(0, 153, 153));
        paymenthistory.setForeground(new java.awt.Color(255, 255, 255));
        paymenthistory.setText("    Billings");
        paymenthistory.setBorder(null);
        paymenthistory.setBorderPainted(false);
        paymenthistory.setContentAreaFilled(false);
        paymenthistory.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        paymenthistory.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        paymenthistory.setOpaque(true);
        paymenthistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymenthistoryActionPerformed(evt);
            }
        });

        logout.setFont(new java.awt.Font("Helvetica Neue", 0, 12)); // NOI18N
        logout.setForeground(new java.awt.Color(255, 255, 255));
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.setText("      Logout");
        logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
        });

        Notifications.setBackground(new java.awt.Color(0, 153, 153));
        Notifications.setForeground(new java.awt.Color(255, 255, 255));
        Notifications.setText("    Notifications");
        Notifications.setBorder(null);
        Notifications.setBorderPainted(false);
        Notifications.setContentAreaFilled(false);
        Notifications.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Notifications.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Notifications.setOpaque(true);
        Notifications.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NotificationsActionPerformed(evt);
            }
        });

        reportmaintenance.setBackground(new java.awt.Color(0, 153, 153));
        reportmaintenance.setForeground(new java.awt.Color(255, 255, 255));
        reportmaintenance.setText("    Report Maintenance");
        reportmaintenance.setBorder(null);
        reportmaintenance.setBorderPainted(false);
        reportmaintenance.setContentAreaFilled(false);
        reportmaintenance.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reportmaintenance.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        reportmaintenance.setOpaque(true);
        reportmaintenance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportmaintenanceActionPerformed(evt);
            }
        });

        profile.setBackground(new java.awt.Color(0, 153, 153));
        profile.setForeground(new java.awt.Color(255, 255, 255));
        profile.setText("    Profile");
        profile.setBorder(null);
        profile.setBorderPainted(false);
        profile.setContentAreaFilled(false);
        profile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        profile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        profile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(rentinformation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(paymenthistory, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
            .addComponent(Notifications, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(logout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(reportmaintenance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(profile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(profile, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(rentinformation, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(paymenthistory, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(Notifications, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(reportmaintenance, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 178, Short.MAX_VALUE)
                .addComponent(logout)
                .addGap(23, 23, 23))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 140, -1));

        Parent.setLayout(new java.awt.CardLayout());

        tenantprofile.setBackground(new java.awt.Color(255, 255, 255));
        tenantprofile.setMaximumSize(new java.awt.Dimension(759, 517));
        tenantprofile.setMinimumSize(new java.awt.Dimension(759, 517));
        tenantprofile.setPreferredSize(new java.awt.Dimension(1104, 498));

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 0, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Full Name:");

        fullname.setEditable(false);
        fullname.setBackground(new java.awt.Color(255, 255, 255));
        fullname.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        fullname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        fullname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fullnameActionPerformed(evt);
            }
        });

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Tenant Code:");

        tenantcode.setEditable(false);
        tenantcode.setBackground(new java.awt.Color(255, 255, 255));
        tenantcode.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        tenantcode.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Room Number:");

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Bed Number:");

        jLabel5.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Facebook Account:");

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Contact Number:");

        jLabel7.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Email:");

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Gender:");

        fbaccount.setEditable(false);
        fbaccount.setBackground(new java.awt.Color(255, 255, 255));
        fbaccount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        fbaccount.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        fbaccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fbaccountActionPerformed(evt);
            }
        });

        contactnum.setEditable(false);
        contactnum.setBackground(new java.awt.Color(255, 255, 255));
        contactnum.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        contactnum.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        email.setEditable(false);
        email.setBackground(new java.awt.Color(255, 255, 255));
        email.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        gender.setBackground(new java.awt.Color(255, 255, 255));
        gender.setForeground(new java.awt.Color(0, 0, 0));
        gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Gender", "Female", "Male" }));

        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Emergency Contact Number:");

        emergencycontactnum.setEditable(false);
        emergencycontactnum.setBackground(new java.awt.Color(255, 255, 255));
        emergencycontactnum.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        emergencycontactnum.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        roomnumber.setEditable(false);
        roomnumber.setBackground(new java.awt.Color(255, 255, 255));
        roomnumber.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        bednumber.setEditable(false);
        bednumber.setBackground(new java.awt.Color(255, 255, 255));
        bednumber.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("Emergency Contact Name:");

        emergencycontactname.setEditable(false);
        emergencycontactname.setBackground(new java.awt.Color(255, 255, 255));
        emergencycontactname.setForeground(new java.awt.Color(0, 0, 0));
        emergencycontactname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        emergencycontactrel.setEditable(false);
        emergencycontactrel.setBackground(new java.awt.Color(255, 255, 255));
        emergencycontactrel.setForeground(new java.awt.Color(0, 0, 0));
        emergencycontactrel.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Emergency Contact Relationship:");

        btnEdit.setBackground(new java.awt.Color(255, 255, 255));
        btnEdit.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        btnEdit.setForeground(new java.awt.Color(0, 0, 0));
        btnEdit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnEdit.setText("edit");
        btnEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEditMouseClicked(evt);
            }
        });

        btnSave.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        btnSave.setForeground(new java.awt.Color(0, 0, 0));
        btnSave.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnSave.setText("save");
        btnSave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSaveMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout tenantprofileLayout = new javax.swing.GroupLayout(tenantprofile);
        tenantprofile.setLayout(tenantprofileLayout);
        tenantprofileLayout.setHorizontalGroup(
            tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tenantprofileLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tenantprofileLayout.createSequentialGroup()
                        .addGap(0, 191, Short.MAX_VALUE)
                        .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(contactnum, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fbaccount, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(707, 707, 707))
                    .addGroup(tenantprofileLayout.createSequentialGroup()
                        .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(tenantprofileLayout.createSequentialGroup()
                                    .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel17)
                                        .addGroup(tenantprofileLayout.createSequentialGroup()
                                            .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel10)
                                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                                            .addGap(26, 26, 26)
                                            .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(emergencycontactname, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                                .addComponent(emergencycontactnum, javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(emergencycontactrel))))
                                    .addGap(88, 88, 88))
                                .addGroup(tenantprofileLayout.createSequentialGroup()
                                    .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(tenantprofileLayout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(tenantprofileLayout.createSequentialGroup()
                                            .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel3)
                                                .addComponent(jLabel4))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(roomnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(bednumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGap(232, 232, 232))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, tenantprofileLayout.createSequentialGroup()
                                    .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel8))
                                    .addGap(53, 53, 53)
                                    .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(tenantprofileLayout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tenantcode, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(tenantprofileLayout.createSequentialGroup()
                .addGap(472, 472, 472)
                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSave, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        tenantprofileLayout.setVerticalGroup(
            tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tenantprofileLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tenantcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(roomnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(bednumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tenantprofileLayout.createSequentialGroup()
                        .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(fbaccount, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(contactnum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(28, 28, 28)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(emergencycontactnum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(emergencycontactname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emergencycontactrel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(37, 37, 37)
                .addGroup(tenantprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEdit)
                    .addComponent(btnSave))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        Parent.add(tenantprofile, "card2");

        rentinfo.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setBackground(java.awt.Color.black);
        jLabel11.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Monthly Bill Breakdown");

        jLabel12.setBackground(java.awt.Color.black);
        jLabel12.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Rent:");

        jLabel13.setBackground(java.awt.Color.black);
        jLabel13.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("Gasoline:");

        jLabel14.setBackground(java.awt.Color.black);
        jLabel14.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("Additional Fees:");

        rent.setBackground(new java.awt.Color(255, 255, 255));
        rent.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        gasoline.setBackground(new java.awt.Color(255, 255, 255));
        gasoline.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel15.setBackground(java.awt.Color.black);
        jLabel15.setFont(new java.awt.Font("Helvetica Neue", 1, 15)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("Sub Total:");

        subtotal.setBackground(new java.awt.Color(255, 255, 255));
        subtotal.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel16.setBackground(java.awt.Color.black);
        jLabel16.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("Monthly Bill:");

        additionfee.setEditable(false);
        additionfee.setBackground(new java.awt.Color(255, 255, 255));
        additionfee.setColumns(20);
        additionfee.setLineWrap(true);
        additionfee.setRows(5);
        additionfee.setWrapStyleWord(true);
        jScrollPane1.setViewportView(additionfee);

        jLabel18.setBackground(java.awt.Color.black);
        jLabel18.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("Total:");

        total.setBackground(new java.awt.Color(255, 255, 255));
        total.setFont(new java.awt.Font("Helvetica Neue", 1, 16)); // NOI18N
        total.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        jLabel29.setForeground(new java.awt.Color(0, 153, 153));
        jLabel29.setText("These are the breakdown what's included in 1,260.00");

        jLabel31.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(0, 0, 0));
        jLabel31.setText("Water and Electric:");

        jTextField1.setBackground(new java.awt.Color(255, 255, 255));
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setText("FREE");
        jTextField1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        monthlybill.setBackground(new java.awt.Color(255, 255, 255));
        monthlybill.setForeground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout rentinfoLayout = new javax.swing.GroupLayout(rentinfo);
        rentinfo.setLayout(rentinfoLayout);
        rentinfoLayout.setHorizontalGroup(
            rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rentinfoLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rentinfoLayout.createSequentialGroup()
                        .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13))
                        .addGap(18, 18, 18)
                        .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(rent)
                            .addComponent(gasoline, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(rentinfoLayout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel29)
                    .addGroup(rentinfoLayout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addGap(18, 18, 18)
                        .addComponent(monthlybill, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(rentinfoLayout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel14)
                    .addComponent(jLabel11)
                    .addGroup(rentinfoLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(total, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(522, Short.MAX_VALUE))
        );
        rentinfoLayout.setVerticalGroup(
            rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rentinfoLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel11)
                .addGap(35, 35, 35)
                .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel16)
                    .addComponent(monthlybill, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(rent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(gasoline, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(subtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(15, 15, 15)
                .addComponent(jLabel14)
                .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rentinfoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(60, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rentinfoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                        .addGroup(rentinfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(total, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(79, 79, 79))))
        );

        Parent.add(rentinfo, "card3");

        billings.setBackground(new java.awt.Color(255, 255, 255));

        jTabbedPane1.setBackground(new java.awt.Color(0, 102, 102));

        duedatetab.setBackground(new java.awt.Color(255, 255, 255));

        jCalendar1.setBackground(new java.awt.Color(255, 255, 255));
        jCalendar1.setBorder(new javax.swing.border.MatteBorder(null));
        jCalendar1.setForeground(new java.awt.Color(0, 0, 0));
        jCalendar1.setDecorationBackgroundColor(new java.awt.Color(0, 153, 153));
        jCalendar1.setWeekdayForeground(new java.awt.Color(255, 255, 255));

        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("Due Pay:");

        modeofpayment.setBackground(new java.awt.Color(255, 255, 255));
        modeofpayment.setForeground(new java.awt.Color(0, 0, 0));
        modeofpayment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Mode of Payment", "Cash", "Gcash" }));

        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("Mode of Payment:");

        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setText("Billing Period:");

        billingperiod.setEditable(false);
        billingperiod.setBackground(new java.awt.Color(255, 255, 255));
        billingperiod.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setText("Overdue Pay (15.00 per day):");

        duepay.setBackground(new java.awt.Color(255, 255, 255));
        duepay.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        overduepay.setBackground(new java.awt.Color(255, 255, 255));
        overduepay.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));

        jLabel27.setForeground(new java.awt.Color(0, 0, 0));
        jLabel27.setText("Total to Pay:");

        totaltopay.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        totaltopay.setForeground(new java.awt.Color(0, 0, 0));
        totaltopay.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        paynow.setText("Pay Now!");
        paynow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paynowActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27)
                            .addComponent(totaltopay, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(paynow)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totaltopay, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(paynow)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jLabel30.setForeground(new java.awt.Color(0, 0, 0));
        jLabel30.setText("Additional Fee (Appliances):");

        additionalfee.setBackground(new java.awt.Color(255, 255, 255));
        additionalfee.setForeground(new java.awt.Color(0, 0, 0));
        additionalfee.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout duedatetabLayout = new javax.swing.GroupLayout(duedatetab);
        duedatetab.setLayout(duedatetabLayout);
        duedatetabLayout.setHorizontalGroup(
            duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, duedatetabLayout.createSequentialGroup()
                .addContainerGap(103, Short.MAX_VALUE)
                .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(duedatetabLayout.createSequentialGroup()
                        .addComponent(jCalendar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(91, 91, 91))
                    .addGroup(duedatetabLayout.createSequentialGroup()
                        .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, duedatetabLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, duedatetabLayout.createSequentialGroup()
                                        .addComponent(jLabel24)
                                        .addGap(296, 296, 296))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, duedatetabLayout.createSequentialGroup()
                                        .addComponent(jLabel26)
                                        .addGap(45, 45, 45)
                                        .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(duepay, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(billingperiod, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE))
                                        .addGap(46, 46, 46))))
                            .addGroup(duedatetabLayout.createSequentialGroup()
                                .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(duedatetabLayout.createSequentialGroup()
                                        .addComponent(jLabel30)
                                        .addGap(18, 18, 18)
                                        .addComponent(additionalfee, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(duedatetabLayout.createSequentialGroup()
                                        .addComponent(jLabel28)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(overduepay, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(duedatetabLayout.createSequentialGroup()
                                        .addComponent(jLabel25)
                                        .addGap(18, 18, 18)
                                        .addComponent(modeofpayment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))))
        );
        duedatetabLayout.setVerticalGroup(
            duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(duedatetabLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(duedatetabLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(duedatetabLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel26)
                            .addComponent(billingperiod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(duepay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(overduepay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30)
                            .addComponent(additionalfee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(duedatetabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(modeofpayment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel25))))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Due Date", duedatetab);

        paymenthistorytab.setBackground(new java.awt.Color(255, 255, 255));

        paymenthistorytable.setBackground(new java.awt.Color(255, 255, 255));
        paymenthistorytable.setForeground(new java.awt.Color(0, 0, 0));
        paymenthistorytable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Billing Period", "Amount Paid", "Status", "Due Date", "Payment Date", "Days Overdue"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(paymenthistorytable);
        if (paymenthistorytable.getColumnModel().getColumnCount() > 0) {
            paymenthistorytable.getColumnModel().getColumn(0).setResizable(false);
            paymenthistorytable.getColumnModel().getColumn(1).setResizable(false);
            paymenthistorytable.getColumnModel().getColumn(2).setResizable(false);
            paymenthistorytable.getColumnModel().getColumn(3).setResizable(false);
            paymenthistorytable.getColumnModel().getColumn(4).setResizable(false);
            paymenthistorytable.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout paymenthistorytabLayout = new javax.swing.GroupLayout(paymenthistorytab);
        paymenthistorytab.setLayout(paymenthistorytabLayout);
        paymenthistorytabLayout.setHorizontalGroup(
            paymenthistorytabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, paymenthistorytabLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 576, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        paymenthistorytabLayout.setVerticalGroup(
            paymenthistorytabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymenthistorytabLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Payment History", paymenthistorytab);

        javax.swing.GroupLayout billingsLayout = new javax.swing.GroupLayout(billings);
        billings.setLayout(billingsLayout);
        billingsLayout.setHorizontalGroup(
            billingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billingsLayout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 622, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 488, Short.MAX_VALUE))
        );
        billingsLayout.setVerticalGroup(
            billingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        Parent.add(billings, "card4");

        notif.setBackground(new java.awt.Color(255, 255, 255));

        jSplitPane3.setDividerLocation(270);

        containertonotifpanel.setBackground(new java.awt.Color(255, 255, 255));
        containertonotifpanel.setMaximumSize(new java.awt.Dimension(250, 498));
        containertonotifpanel.setMinimumSize(new java.awt.Dimension(250, 498));

        jScrollPane7.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        notiflistpanel.setLayout(new javax.swing.BoxLayout(notiflistpanel, javax.swing.BoxLayout.LINE_AXIS));
        jScrollPane7.setViewportView(notiflistpanel);

        javax.swing.GroupLayout containertonotifpanelLayout = new javax.swing.GroupLayout(containertonotifpanel);
        containertonotifpanel.setLayout(containertonotifpanelLayout);
        containertonotifpanelLayout.setHorizontalGroup(
            containertonotifpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, containertonotifpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        containertonotifpanelLayout.setVerticalGroup(
            containertonotifpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(containertonotifpanelLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jSplitPane3.setLeftComponent(containertonotifpanel);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setMaximumSize(new java.awt.Dimension(350, 501));
        jPanel3.setMinimumSize(new java.awt.Dimension(350, 501));

        typeLabel.setBackground(new java.awt.Color(204, 204, 204));
        typeLabel.setForeground(new java.awt.Color(0, 0, 0));

        dateLabel.setBackground(new java.awt.Color(204, 204, 204));
        dateLabel.setForeground(new java.awt.Color(0, 0, 0));

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setPreferredSize(new java.awt.Dimension(400, 200));

        messageTextArea.setEditable(false);
        messageTextArea.setColumns(20);
        messageTextArea.setLineWrap(true);
        messageTextArea.setRows(5);
        messageTextArea.setWrapStyleWord(true);
        messageTextArea.setMaximumSize(new java.awt.Dimension(232, 89));
        messageTextArea.setMinimumSize(new java.awt.Dimension(232, 89));
        jScrollPane4.setViewportView(messageTextArea);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE)
                    .addComponent(dateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(typeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(typeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );

        jSplitPane3.setRightComponent(jPanel3);

        javax.swing.GroupLayout notifLayout = new javax.swing.GroupLayout(notif);
        notif.setLayout(notifLayout);
        notifLayout.setHorizontalGroup(
            notifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(notifLayout.createSequentialGroup()
                .addComponent(jSplitPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 625, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 485, Short.MAX_VALUE))
        );
        notifLayout.setVerticalGroup(
            notifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane3)
        );

        Parent.add(notif, "card5");

        reported.setBackground(new java.awt.Color(255, 255, 255));
        reported.setForeground(new java.awt.Color(0, 0, 0));
        reported.setPreferredSize(new java.awt.Dimension(759, 517));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setForeground(new java.awt.Color(0, 0, 0));
        jPanel7.setPreferredSize(new java.awt.Dimension(759, 517));

        jSplitPane1.setDividerLocation(250);
        jSplitPane1.setDividerSize(1);

        rightjScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        rightjScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        commentsection.setEditable(false);
        commentsection.setBackground(new java.awt.Color(255, 255, 255));
        commentsection.setColumns(20);
        commentsection.setForeground(new java.awt.Color(0, 0, 0));
        commentsection.setRows(5);
        jScrollPane3.setViewportView(commentsection);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 234, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 391, Short.MAX_VALUE)
        );

        rightjScrollPane4.setViewportView(jPanel5);

        jSplitPane1.setRightComponent(rightjScrollPane4);

        leftjScrollPane6.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        leftjScrollPane6.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new javax.swing.BoxLayout(jPanel6, javax.swing.BoxLayout.Y_AXIS));
        leftjScrollPane6.setViewportView(jPanel6);

        jSplitPane1.setLeftComponent(leftjScrollPane6);

        jLabel19.setFont(new java.awt.Font("Hiragino Sans", 1, 13)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("This is where you view the updates of your report tickets");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 587, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(502, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        reported.addTab("Report Tickets", jPanel7);

        report.setBackground(new java.awt.Color(255, 255, 255));

        jLabel32.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(0, 0, 0));
        jLabel32.setText("Report Maintenance");

        jLabel33.setForeground(new java.awt.Color(0, 0, 0));
        jLabel33.setText("Area of Concern:");

        jLabel34.setForeground(new java.awt.Color(0, 0, 0));
        jLabel34.setText("Description:");

        description.setBackground(new java.awt.Color(255, 255, 255));
        description.setColumns(20);
        description.setRows(5);
        jScrollPane5.setViewportView(description);

        jLabel35.setForeground(new java.awt.Color(0, 0, 0));
        jLabel35.setText("Upload Photo:");

        jLabel36.setForeground(new java.awt.Color(0, 0, 0));
        jLabel36.setText("Reported by:");

        reportedby.setEditable(false);
        reportedby.setBackground(new java.awt.Color(255, 255, 255));
        reportedby.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        submit.setBackground(new java.awt.Color(153, 153, 153));
        submit.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        submit.setForeground(new java.awt.Color(0, 0, 0));
        submit.setText("Submit");
        submit.setBorderPainted(false);
        submit.setContentAreaFilled(false);
        submit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        submit.setFocusPainted(false);
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        firstpath.setEditable(false);
        firstpath.setBackground(new java.awt.Color(255, 255, 255));
        firstpath.setForeground(new java.awt.Color(0, 0, 0));
        firstpath.setBorder(null);

        secondpath.setEditable(false);
        secondpath.setBackground(new java.awt.Color(255, 255, 255));
        secondpath.setForeground(new java.awt.Color(0, 0, 0));
        secondpath.setBorder(null);

        firstphotoLabel.setForeground(new java.awt.Color(0, 0, 0));
        firstphotoLabel.setText("    + Add Photo");
        firstphotoLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        firstphotoLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                firstphotoLabelMouseClicked(evt);
            }
        });

        secondphotoLabel.setForeground(new java.awt.Color(0, 0, 0));
        secondphotoLabel.setText("    + Add Photo");
        secondphotoLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        secondphotoLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                secondphotoLabelMouseClicked(evt);
            }
        });

        issuetype.setBackground(new java.awt.Color(255, 255, 255));
        issuetype.setForeground(new java.awt.Color(0, 0, 0));
        issuetype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Area", "Room", "Hallway", "Kitchen", "Restroom", "Others" }));

        javax.swing.GroupLayout reportLayout = new javax.swing.GroupLayout(report);
        report.setLayout(reportLayout);
        reportLayout.setHorizontalGroup(
            reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportLayout.createSequentialGroup()
                .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(reportLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(reportLayout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(firstpath, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(reportLayout.createSequentialGroup()
                                .addComponent(jLabel35)
                                .addGap(19, 19, 19)
                                .addComponent(firstphotoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(reportLayout.createSequentialGroup()
                                        .addGap(52, 52, 52)
                                        .addComponent(secondpath, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(reportLayout.createSequentialGroup()
                                        .addGap(66, 66, 66)
                                        .addComponent(secondphotoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(reportLayout.createSequentialGroup()
                                .addComponent(jLabel36)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(reportedby, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel32)
                            .addGroup(reportLayout.createSequentialGroup()
                                .addComponent(jLabel33)
                                .addGap(18, 18, 18)
                                .addComponent(issuetype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(reportLayout.createSequentialGroup()
                                .addComponent(jLabel34)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(reportLayout.createSequentialGroup()
                        .addGap(481, 481, 481)
                        .addComponent(submit, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(532, Short.MAX_VALUE))
        );
        reportLayout.setVerticalGroup(
            reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel32)
                .addGap(31, 31, 31)
                .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel36)
                    .addComponent(reportedby, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel33)
                    .addComponent(issuetype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel34)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel35)
                    .addGroup(reportLayout.createSequentialGroup()
                        .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(firstphotoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(secondphotoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(reportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(firstpath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(secondpath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(14, 14, 14)
                .addComponent(submit, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75))
        );

        reported.addTab("Report Maintenance", report);

        Parent.add(reported, "card7");

        Parent.add(tenantprofile, "tenantprofile");
        Parent.add(rentinfo, "rentinfo");
        Parent.add(billings, "billings");
        Parent.add(reported, "reported");
        Parent.add(notif, "notif");

        getContentPane().add(Parent, new org.netbeans.lib.awtextra.AbsoluteConstraints(143, 0, -1, 498));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rentinformationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rentinformationActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
        cl.show(Parent, "rentinfo");

        //loadRentInfo(tenantId); // Default rent display
        loadBillingPeriods(tenantId); // Populate ComboBox

        if (monthlybill.getItemCount() > 0) {
            String latestPeriod = (String) monthlybill.getItemAt(0); 
            monthlybill.setSelectedItem(latestPeriod);
            loadRentInfoForPeriod(tenantId, latestPeriod); 
        }  

    }//GEN-LAST:event_rentinformationActionPerformed

    private void paymenthistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymenthistoryActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
       loadPendingBilling();
        cl.show(Parent, "billings");
    }//GEN-LAST:event_paymenthistoryActionPerformed

    private void fullnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fullnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fullnameActionPerformed

    private void fbaccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fbaccountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fbaccountActionPerformed

    private void NotificationsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NotificationsActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
        cl.show(Parent, "notif");
        loadNotifications(userId);
    }//GEN-LAST:event_NotificationsActionPerformed

    private void reportmaintenanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportmaintenanceActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
        cl.show(Parent, "reported");
        loadTenantMaintenanceReports(tenantId);
    }//GEN-LAST:event_reportmaintenanceActionPerformed

    private void paynowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paynowActionPerformed
          try {
        // Parse the overdue fee from JTextField
        double overdueFee = Double.parseDouble(overduepay.getText());

        // Get values from UI
        double amountDue = Double.parseDouble(duepay.getText());
        double applianceFee = Double.parseDouble(additionalfee.getText());
        double totalAmountToPay = Double.parseDouble(totaltopay.getText());
        String paymentMethod = modeofpayment.getSelectedItem().toString();
        java.sql.Date today = new java.sql.Date(System.currentTimeMillis());

        String updateSQL = "UPDATE billing_payments SET amount_paid = ?, payment_status = 'Paid', payment_method = ?, payment_date = ? WHERE billing_id = ?";
        PreparedStatement updateStmt = conn.prepareStatement(updateSQL);
        updateStmt.setDouble(1, totalAmountToPay);
        updateStmt.setString(2, paymentMethod);
        updateStmt.setDate(3, today);
        //updateStmt.setDouble(4, overdueFee); 
        updateStmt.setInt(4, currentBillingId); // billing ID from earlier

        int rows = updateStmt.executeUpdate();

        if (rows > 0) {
            JOptionPane.showMessageDialog(this, "Payment successful!");

            SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy");
            Calendar cal = Calendar.getInstance();
            cal.setTime(sdf.parse(currentBillingPeriod)); // Make sure currentBillingPeriod is available
            cal.add(Calendar.MONTH, 1);
            String nextBillingPeriod = sdf.format(cal.getTime());

            generateAndInsertBilling(tenantId, nextBillingPeriod);

            loadPendingBilling();
        } else {
            JOptionPane.showMessageDialog(this, "Payment failed. Please try again.");
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error processing payment.");
    }
    }//GEN-LAST:event_paynowActionPerformed

    private void profileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileActionPerformed
        CardLayout cl = (CardLayout) Parent.getLayout();
        cl.show(Parent, "tenantprofile"); // or "rentinfo", etc.

    }//GEN-LAST:event_profileActionPerformed

    private void btnEditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditMouseClicked
        enableEditing();
    }//GEN-LAST:event_btnEditMouseClicked

    private void btnSaveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSaveMouseClicked
        saveTenantProfile();
    }//GEN-LAST:event_btnSaveMouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        Login login = new Login();
        login.setVisible(true);
        login.pack();
        login.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoutMouseClicked

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
          try {
        String issueType = (String) issuetype.getSelectedItem();
        String Description = description.getText().trim();
        String originalPhoto1Path = firstpath.getText().trim();
        String originalPhoto2Path = secondpath.getText().trim();
        
       if (issueType == null || Description.isEmpty() || originalPhoto1Path.isEmpty() || originalPhoto2Path.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please complete all required fields and attach two photos.");
        return;
        }

        // --- Upload images ---
        String uploadedPhoto1 = null;
        String uploadedPhoto2 = null;
        
        if (!originalPhoto1Path.isEmpty()) {
            uploadedPhoto1 = uploadImage(originalPhoto1Path);
        }
        if (!originalPhoto2Path.isEmpty()) {
            uploadedPhoto2 = uploadImage(originalPhoto2Path);
        }

        // --- Save to database ---
        String sql = "INSERT INTO maintenance_reports (tenant_id, room_id, issue_type, description, photo1_path, photo2_path) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, tenantId);
        pstmt.setInt(2, roomId);
        pstmt.setString(3, issueType);
        pstmt.setString(4, Description);
        pstmt.setString(5, uploadedPhoto1);
        pstmt.setString(6, uploadedPhoto2);

        int rows = pstmt.executeUpdate();

        if (rows > 0) {
            JOptionPane.showMessageDialog(this, "Utility problem reported successfully.");
            issuetype.setSelectedIndex(0); 
            description.setText("");
            firstpath.setText("");
            secondpath.setText("");
            firstphotoLabel.setIcon(null);
            secondphotoLabel.setIcon(null);

        } else {
            JOptionPane.showMessageDialog(this, "Failed to report. Please try again.");
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }

    }//GEN-LAST:event_submitActionPerformed

    private void firstphotoLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_firstphotoLabelMouseClicked
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images", "jpg", "jpeg", "png");
        fileChooser.setFileFilter(filter);

        int returnVal = fileChooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            firstpath.setText(selectedFile.getAbsolutePath()); // Save the path (assuming may firstpath JTextField ka)

            // Load and resize the image
            ImageIcon originalIcon = new ImageIcon(selectedFile.getAbsolutePath());
            Image originalImage = originalIcon.getImage();
            Image resizedImage = originalImage.getScaledInstance(firstphotoLabel.getWidth(), firstphotoLabel.getHeight(), Image.SCALE_SMOOTH);

            firstphotoLabel.setIcon(new ImageIcon(resizedImage));
            firstphotoLabel.setText(""); // Remove the "Click to upload" text pag may image na
        }
    }//GEN-LAST:event_firstphotoLabelMouseClicked

    private void secondphotoLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_secondphotoLabelMouseClicked
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images", "jpg", "jpeg", "png");
        fileChooser.setFileFilter(filter);

        int returnVal = fileChooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            secondpath.setText(selectedFile.getAbsolutePath()); // Save the path (assuming may firstpath JTextField ka)

            // Load and resize the image
            ImageIcon originalIcon = new ImageIcon(selectedFile.getAbsolutePath());
            Image originalImage = originalIcon.getImage();
            Image resizedImage = originalImage.getScaledInstance(secondphotoLabel.getWidth(), secondphotoLabel.getHeight(), Image.SCALE_SMOOTH);

            secondphotoLabel.setIcon(new ImageIcon(resizedImage));
            secondphotoLabel.setText(""); // Remove the "Click to upload" text pag may image na
        }
    }//GEN-LAST:event_secondphotoLabelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tenant_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tenant_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tenant_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tenant_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tenant_dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Notifications;
    private javax.swing.JPanel Parent;
    private javax.swing.JTextField additionalfee;
    private javax.swing.JTextArea additionfee;
    private javax.swing.JTextField bednumber;
    private javax.swing.JTextField billingperiod;
    private javax.swing.JPanel billings;
    private javax.swing.JLabel btnEdit;
    private javax.swing.JLabel btnSave;
    private javax.swing.JTextArea commentsection;
    private javax.swing.JTextField contactnum;
    private javax.swing.JPanel containertonotifpanel;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JTextArea description;
    private javax.swing.JPanel duedatetab;
    private javax.swing.JTextField duepay;
    private javax.swing.JTextField email;
    private javax.swing.JTextField emergencycontactname;
    private javax.swing.JTextField emergencycontactnum;
    private javax.swing.JTextField emergencycontactrel;
    private javax.swing.JTextField fbaccount;
    private javax.swing.JTextField firstpath;
    private javax.swing.JLabel firstphotoLabel;
    private javax.swing.JTextField fullname;
    private javax.swing.JTextField gasoline;
    private javax.swing.JComboBox<String> gender;
    private javax.swing.JComboBox<String> issuetype;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JScrollPane leftjScrollPane6;
    private javax.swing.JLabel logout;
    private javax.swing.JTextArea messageTextArea;
    private javax.swing.JComboBox<String> modeofpayment;
    private javax.swing.JComboBox<String> monthlybill;
    private javax.swing.JPanel notif;
    private javax.swing.JPanel notiflistpanel;
    private javax.swing.JTextField overduepay;
    private javax.swing.JButton paymenthistory;
    private javax.swing.JPanel paymenthistorytab;
    private javax.swing.JTable paymenthistorytable;
    private javax.swing.JButton paynow;
    private javax.swing.JButton profile;
    private javax.swing.JTextField rent;
    private javax.swing.JPanel rentinfo;
    private javax.swing.JButton rentinformation;
    private javax.swing.JPanel report;
    private javax.swing.JTabbedPane reported;
    private javax.swing.JTextField reportedby;
    private javax.swing.JButton reportmaintenance;
    private javax.swing.JScrollPane rightjScrollPane4;
    private javax.swing.JTextField roomnumber;
    private javax.swing.JTextField secondpath;
    private javax.swing.JLabel secondphotoLabel;
    private javax.swing.JButton submit;
    private javax.swing.JTextField subtotal;
    private javax.swing.JTextField tenantcode;
    private javax.swing.JPanel tenantprofile;
    private javax.swing.JTextField total;
    private javax.swing.JLabel totaltopay;
    private javax.swing.JLabel typeLabel;
    // End of variables declaration//GEN-END:variables
}
