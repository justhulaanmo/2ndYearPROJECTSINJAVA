package Tenant;
import Config.DBconnection;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class reservation extends javax.swing.JFrame {

    public reservation() {
        initComponents();
        setLocationRelativeTo(null);
        
        contactnumber.setText("09");
        contactnumber.setForeground(Color.GRAY);
        contactnumber.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (contactnumber.getText().equals("09")) {
                    contactnumber.setText("09");
                    contactnumber.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (contactnumber.getText().isEmpty()) {
                    contactnumber.setText("09");
                    contactnumber.setForeground(Color.GRAY);
                }
            }
        });

        contactnumber.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                // Limit the input to 11 characters
                if (contactnumber.getText().length() >= 11) {
                    evt.consume();
                }
            }
        });
        
         fullname.addKeyListener(new java.awt.event.KeyAdapter() {
        @Override
        public void keyReleased(java.awt.event.KeyEvent evt) {
            String original = fullname.getText();
            int caretPos = fullname.getCaretPosition();

            String updated = capitalizeEachWord(original);
            if (!original.equals(updated)) {
                fullname.setText(updated);
                // Set caret back to original position if possible
                if (caretPos <= updated.length()) {
                    fullname.setCaretPosition(caretPos);
                }
            }
        }
    });

    
    }
    
        private String capitalizeEachWord(String input) {
        if (input == null || input.isEmpty()) return input;

        String[] words = input.toLowerCase().split(" ");
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            String word = words[i];
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1));
            }
            if (i < words.length - 1 || input.endsWith(" ")) {
                result.append(" ");
            }
        }

        return result.toString();
    }

    
    
        public void insertReservation() {
        String fullName = fullname.getText().trim();
        String contactNumber = contactnumber.getText().trim();
        String Email = email.getText().trim();
        String Gender = gender.getSelectedItem().toString();
        String paymentMethod = paymentmethod.getSelectedItem().toString();
        double amountPaid = 0;

        // Reset error messages before validation
        errorfullname.setText("");
        errorcontactnumber.setText("");
        erroremail.setText("");
        errorgender.setText("");
        errorpaymentmethod.setText("");
        erroramountpaid.setText("");

        // StringBuilder to store all error messages
        StringBuilder errorMessage = new StringBuilder();
        boolean hasError = false;

        // Check each field and set error messages
        if (!fullName.matches("^[a-zA-Z\\s]+$")) { 
        errorfullname.setText("*");
        errorfullname.setForeground(Color.RED);
        errorMessage.append("* Full Name should contain only letters and spaces.\n");
        hasError = true;
        }

        if (contactNumber.isEmpty() || !contactNumber.matches("^09[0-9]{9}$")) {
            errorMessage.append("* Invalid contact number. Must start with '09' and have 11 digits.\n");
            errorcontactnumber.setText("*");
            errorcontactnumber.setForeground(Color.RED);
            hasError = true;
        }

        if (!Email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
        erroremail.setText("*");
        erroremail.setForeground(Color.RED);
        errorMessage.append("* Please enter a valid email address.\n");
        hasError = true;
    }

        if (Gender.equals("Select Gender")) {
            errorMessage.append("* Please select a gender.\n");
            errorgender.setText("*");
            errorgender.setForeground(Color.RED);
            hasError = true;
        }

        if (paymentMethod.equals("Select Payment Method")) {
            errorMessage.append("* Please select a payment method.\n");
            errorpaymentmethod.setText("*");
            errorpaymentmethod.setForeground(Color.RED);
            hasError = true;
        }

        // Parse amountPaid safely
        try {
            amountPaid = Double.parseDouble(amountpaid.getText().trim());
            if (amountPaid < 1200) {
                errorMessage.append("* Amount paid must be greater than 1,200.\n");
                erroramountpaid.setText("*");
                erroramountpaid.setForeground(Color.RED);
                hasError = true;
            }
        } catch (NumberFormatException e) {
            errorMessage.append("* Invalid amount format.\n");
            erroramountpaid.setText("*");
            erroramountpaid.setForeground(Color.RED);
            hasError = true;
        }

        // Show the error message only once
        if (hasError) {
            JOptionPane.showMessageDialog(this, "Please fill out the required fields:\n\n" + errorMessage.toString(), "Error", JOptionPane.WARNING_MESSAGE);
            return; // Stop execution if there are errors
        }
        
        
//=========================================================================================================
        // 5. Check if email already exists in tenants table
    try (Connection conn = DBconnection.getConnection()) {
        String emailCheckQuery = "SELECT COUNT(*) FROM tenants WHERE email = ?";
        PreparedStatement emailCheckStmt = conn.prepareStatement(emailCheckQuery);
        emailCheckStmt.setString(1, Email);
        ResultSet rs = emailCheckStmt.executeQuery();

        if (rs.next() && rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(this, "This email is already associated with an existing tenant.", "Duplicate Email", JOptionPane.WARNING_MESSAGE);
            return; // Stop further execution
        }
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error checking email: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
//=========================================================================================================



        // 6. Insert Reservation into Database
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "INSERT INTO reservations (full_name, contact_number, email, gender, amount_paid, payment_method) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, fullName);
            pstmt.setString(2, contactNumber);
            pstmt.setString(3, Email);
            pstmt.setString(4, Gender);
            pstmt.setDouble(5, amountPaid);
            pstmt.setString(6, paymentMethod);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Reservation Submitted Successfully!");

                // Reset fields
                fullname.setText("");
                contactnumber.setText("09");
                contactnumber.setForeground(Color.GRAY);
                email.setText("");
                gender.setSelectedIndex(0); // Resets to "Select Gender"
                amountpaid.setText("");
                paymentmethod.setSelectedIndex(0); // Resets to "Select Payment Method"

            } else {
                JOptionPane.showMessageDialog(null, "Reservation Failed!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        fullname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        contactnumber = new javax.swing.JTextField();
        jlabel4 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        gender = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        reservationfee = new javax.swing.JTextField();
        paymentmethod = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        amountpaid = new javax.swing.JTextField();
        reserve = new javax.swing.JButton();
        errorfullname = new javax.swing.JLabel();
        errorcontactnumber = new javax.swing.JLabel();
        erroremail = new javax.swing.JLabel();
        errorgender = new javax.swing.JLabel();
        errorpaymentmethod = new javax.swing.JLabel();
        erroramountpaid = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));
        setMaximumSize(new java.awt.Dimension(759, 517));
        setMinimumSize(new java.awt.Dimension(759, 517));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(759, 517));
        jPanel1.setMinimumSize(new java.awt.Dimension(759, 517));
        jPanel1.setPreferredSize(new java.awt.Dimension(759, 517));
        jPanel1.setSize(new java.awt.Dimension(759, 517));

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 30)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Reservation for Bed Space");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Full Name:");

        fullname.setBackground(new java.awt.Color(255, 255, 255));
        fullname.setForeground(new java.awt.Color(0, 0, 0));
        fullname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Contact Number:");

        contactnumber.setBackground(new java.awt.Color(255, 255, 255));
        contactnumber.setForeground(new java.awt.Color(0, 0, 0));
        contactnumber.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jlabel4.setForeground(new java.awt.Color(0, 0, 0));
        jlabel4.setText("Email:");

        email.setBackground(new java.awt.Color(255, 255, 255));
        email.setForeground(new java.awt.Color(0, 0, 0));
        email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Gender:");

        gender.setBackground(new java.awt.Color(255, 255, 255));
        gender.setForeground(new java.awt.Color(0, 0, 0));
        gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Gender", "Female", "Male" }));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));

        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Payment Method:");

        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Reservation Fee (Advance Payment:)");

        reservationfee.setEditable(false);
        reservationfee.setBackground(new java.awt.Color(255, 255, 255));
        reservationfee.setForeground(new java.awt.Color(0, 0, 0));
        reservationfee.setText("1,200.00");
        reservationfee.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        paymentmethod.setBackground(new java.awt.Color(255, 255, 255));
        paymentmethod.setForeground(new java.awt.Color(0, 0, 0));
        paymentmethod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Payment Method", "Cash", "Gcash" }));

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Amount Paid:");

        amountpaid.setBackground(new java.awt.Color(255, 255, 255));
        amountpaid.setForeground(new java.awt.Color(0, 0, 0));
        amountpaid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        reserve.setBackground(new java.awt.Color(204, 204, 204));
        reserve.setForeground(new java.awt.Color(0, 0, 0));
        reserve.setText("Reserve");
        reserve.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        reserve.setBorderPainted(false);
        reserve.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reserve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reserveActionPerformed(evt);
            }
        });

        errorfullname.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        errorfullname.setForeground(new java.awt.Color(255, 0, 0));

        errorcontactnumber.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        errorcontactnumber.setForeground(new java.awt.Color(255, 0, 0));

        erroremail.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        erroremail.setForeground(new java.awt.Color(255, 0, 0));

        errorgender.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        errorgender.setForeground(new java.awt.Color(255, 0, 0));

        errorpaymentmethod.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        errorpaymentmethod.setForeground(new java.awt.Color(255, 0, 0));

        erroramountpaid.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        erroramountpaid.setForeground(new java.awt.Color(255, 0, 0));

        jLabel10.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 51, 51));
        jLabel10.setText("* Note: Advance Payment can be refundable but less 500.00 for inconvience");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(contactnumber)
                                    .addComponent(email)
                                    .addComponent(gender, 0, 185, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(errorcontactnumber, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(erroremail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(errorgender, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(amountpaid))
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6)
                                    .addComponent(reservationfee)
                                    .addComponent(paymentmethod, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(errorpaymentmethod, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(erroramountpaid, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(errorfullname, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel10))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(reserve, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(145, 145, 145))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(errorfullname, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(contactnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(errorcontactnumber, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(erroremail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jlabel4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(errorgender, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reservationfee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(paymentmethod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(errorpaymentmethod, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(amountpaid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(erroramountpaid, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(reserve, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(200, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(179, 179, 179))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(12, 12, 12)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void reserveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reserveActionPerformed
        
        insertReservation();
        
        
    }//GEN-LAST:event_reserveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reservation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amountpaid;
    private javax.swing.JTextField contactnumber;
    private javax.swing.JTextField email;
    private javax.swing.JLabel erroramountpaid;
    private javax.swing.JLabel errorcontactnumber;
    private javax.swing.JLabel erroremail;
    private javax.swing.JLabel errorfullname;
    private javax.swing.JLabel errorgender;
    private javax.swing.JLabel errorpaymentmethod;
    private javax.swing.JTextField fullname;
    private javax.swing.JComboBox<String> gender;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel jlabel4;
    private javax.swing.JComboBox<String> paymentmethod;
    private javax.swing.JTextField reservationfee;
    private javax.swing.JButton reserve;
    // End of variables declaration//GEN-END:variables
}
