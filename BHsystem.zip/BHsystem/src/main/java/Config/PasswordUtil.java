package Config;
import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {
    public static void main(String[] args) {
//        String password = "12345"; // Gamitin ang tunay na admin password
//        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
//        System.out.println("New Hash: " + hashedPassword);

    String raw = "12345";
    String hashed = "$2a$10$gBniL9tFd/ys9Sz44zZwYOLwEYmmbM3SQA3ZopO0m73xMG.QZqdcW";

    System.out.println("Match: " + BCrypt.checkpw(raw, hashed)); // Should print true
    }
}
