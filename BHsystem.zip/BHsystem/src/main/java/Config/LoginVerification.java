package Config;
import java.sql.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginVerification {
    // Method to check if the password matches the hashed password in the database
    public static boolean verifyPassword(String enteredPassword, String storedPasswordHash) {
        try {
            // Hash the entered password using the same hashing algorithm as in the database
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(enteredPassword.getBytes());
            byte[] hashedBytes = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            String hashedEnteredPassword = sb.toString();

            // Compare the entered password's hash with the stored password hash
            return storedPasswordHash.equals(hashedEnteredPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to handle the login process
    public static boolean login(String username, String password) {
        Connection conn = DBconnection.getConnection(); // Assuming db_connect provides the connection

        if (conn != null) {
            try {
                // SQL query to fetch the user record based on the entered username
                String query = "SELECT * FROM users WHERE username = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();

                // Check if a record is found for the given username
                if (rs.next()) {
                    String storedPasswordHash = rs.getString("password_hash");
                    // Check if the entered password matches the stored password hash
                    if (verifyPassword(password, storedPasswordHash)) {
                        String role = rs.getString("role");
                        // Only allow login for 'Tenant' and 'Owner'
                        if (role.equals("Tenant") || role.equals("Owner")) {
                            return true;  // Successful login
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return false; // Invalid username or password
    }

    public static void main(String[] args) {
        // Test login process
        String username = "tenant1"; // Example username
        String password = "your_password"; // Example password

        if (login(username, password)) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid username or password.");
        }
    }
}