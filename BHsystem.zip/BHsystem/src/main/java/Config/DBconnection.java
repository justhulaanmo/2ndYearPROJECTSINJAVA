package Config;

import Admin.Tenant;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBconnection {
    private static final String URL = "jdbc:mysql://localhost:3306/bhsystem"; 
    private static final String USER = "root";  // Change if necessary
    private static final String PASSWORD = "";  // Change if necessary

    // Establish connection
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
            return null;
        }
    }

    // Fetch tenant names
    public static List<String> getTenantNames() {
        List<String> tenantNames = new ArrayList<>();
        String query = "SELECT full_name FROM tenants";  // Ensure this matches your database table

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                tenantNames.add(rs.getString("full_name"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching tenant names: " + e.getMessage());
        }
        return tenantNames;
    }
    
    public static Tenant getTenantDetails(String tenantName) {
    String query = "SELECT * FROM tenants WHERE full_name = ?";
    
    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
         
        pstmt.setString(1, tenantName);
        ResultSet rs = pstmt.executeQuery();
        
        if (rs.next()) {
            return new Tenant(
                rs.getString("full_name"),
                rs.getString("email"),
                rs.getString("room_id")
            );
        }
    } catch (SQLException e) {
        System.out.println("Error fetching tenant details: " + e.getMessage());
    }
    return null;
}

}
    