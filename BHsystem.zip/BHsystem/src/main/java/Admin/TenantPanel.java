package Admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TenantPanel extends JPanel {
    private JPanel tenantListPanel;
    private JPanel profilePanel;

    public TenantPanel() {
        setLayout(new BorderLayout());

        // Sidebar Panel (Optional, already implemented)
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(69, 122, 128)); // #457A80
        sidebar.setPreferredSize(new Dimension(263, getHeight()));
        add(sidebar, BorderLayout.WEST);

        // Tenant List Panel
        tenantListPanel = new JPanel();
        tenantListPanel.setLayout(new BoxLayout(tenantListPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(tenantListPanel);
        scrollPane.setPreferredSize(new Dimension(407, 700));
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);

        // Profile Panel (Second Panel)
        profilePanel = new JPanel();
        profilePanel.setLayout(new GridLayout(6, 1));
        profilePanel.setPreferredSize(new Dimension(588, 788));
        profilePanel.setBackground(new Color(69, 122, 128)); // #457A80
        add(profilePanel, BorderLayout.EAST);

        loadTenants(); // Fetch tenants from database
    }

    private void loadTenants() {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/bhsystem", "root", "");
            String query = "SELECT full_name, tenant_code FROM tenants";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String fullName = rs.getString("full_name");
                String tenantCode = rs.getString("tenant_code");

                JButton tenantButton = new JButton(fullName);
                tenantButton.setPreferredSize(new Dimension(353, 51));
                tenantButton.setBackground(new Color(217, 217, 217)); // #D9D9D9
                tenantButton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
                tenantButton.setFocusPainted(false);

                // Click event to show tenant profile
                tenantButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        showTenantProfile(tenantCode);
                    }
                });

                tenantListPanel.add(tenantButton);
                tenantListPanel.revalidate();
                tenantListPanel.repaint();
            }

            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void showTenantProfile(String tenantCode) {
        profilePanel.removeAll(); // Clear previous profile data

        try {
            Connection conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/bhsystem", "root", "");
            String query = "SELECT * FROM tenants WHERE tenant_code = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, tenantCode);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                JLabel nameLabel = new JLabel("Full Name: " + rs.getString("full_name"));
                JLabel contactLabel = new JLabel("Contact: " + rs.getString("contact_number"));
                JLabel emailLabel = new JLabel("Email: " + rs.getString("email"));
                JLabel roomLabel = new JLabel("Room: " + rs.getString("room_id") + " | Bed: " + rs.getString("bed_number"));
                JLabel moveInLabel = new JLabel("Move-in Date: " + rs.getString("move_in_date"));

                nameLabel.setForeground(Color.WHITE);
                contactLabel.setForeground(Color.WHITE);
                emailLabel.setForeground(Color.WHITE);
                roomLabel.setForeground(Color.WHITE);
                moveInLabel.setForeground(Color.WHITE);

                profilePanel.add(nameLabel);
                profilePanel.add(contactLabel);
                profilePanel.add(emailLabel);
                profilePanel.add(roomLabel);
                profilePanel.add(moveInLabel);

                profilePanel.revalidate();
                profilePanel.repaint();
            }

            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Test JFrame
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tenant Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1300, 800);
        frame.add(new TenantPanel());
        frame.setVisible(true);
    }
}
