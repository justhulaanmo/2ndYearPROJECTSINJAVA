
package Admin;
import Config.DBconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Admin.admin_dashboard;

public class MaintenanceCommentsForm extends javax.swing.JFrame {

    private int reportId;
    private admin_dashboard adminDashboard;

    public void setReportId(int reportId) {
        this.reportId = reportId;
        loadComments(); // Tawagin para automatic mag-load pag naset na yung report ID
    }

    public MaintenanceCommentsForm() {
        initComponents();
    }
    
    public MaintenanceCommentsForm(admin_dashboard adminDashboard) {
        initComponents();
        this.adminDashboard = adminDashboard;
       
        loadMaintenanceUpdates();
    }
    
     private void loadMaintenanceUpdates() {
        addcomment.setText(""); // Clear before loading

        try (Connection conn = DBconnection.getConnection()) {
            String query = "SELECT update_message, updated_at FROM maintenance_updates WHERE report_id = ? ORDER BY updated_at ASC";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, reportId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String message = rs.getString("update_message");
                String date = rs.getString("updated_at");
                addcomment.append(date + ": " + message + "\n\n");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading updates: " + e.getMessage());
        }
    }
     
         private void loadComments() {
        commentsection.setText(""); // Clear first
        try (Connection conn = DBconnection.getConnection()) {
            String query = "SELECT update_message, updated_at FROM maintenance_updates WHERE report_id = ? ORDER BY updated_at ASC";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, reportId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String message = rs.getString("update_message");
                String date = rs.getString("updated_at");

                commentsection.append(date + "\n");
                commentsection.append(message + "\n");
                commentsection.append("----------------------------------------------\n\n");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading comments: " + e.getMessage());
        }
    }

     
    private void addComment(String newComment) {
        if (newComment == null || newComment.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a comment before submitting.");
            return;
        }

        try (Connection conn = DBconnection.getConnection()) {
            conn.setAutoCommit(false); // Transaction mode

            // 1. Insert new comment into maintenance_updates
            String insertQuery = "INSERT INTO maintenance_updates (report_id, update_message) VALUES (?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
                ps.setInt(1, reportId);
                ps.setString(2, newComment);
                ps.executeUpdate();
            }

            // 2. Check the current status of the report
            String checkStatusQuery = "SELECT status FROM maintenance_reports WHERE report_id = ?";
            String currentStatus = "";
            try (PreparedStatement ps = conn.prepareStatement(checkStatusQuery)) {
                ps.setInt(1, reportId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    currentStatus = rs.getString("status");
                }
            }

            // 3. If current status is "Pending", update it to "In Progress"
            if ("Pending".equalsIgnoreCase(currentStatus)) {
                String updateStatusQuery = "UPDATE maintenance_reports SET status = 'In Progress', updated_at = CURRENT_TIMESTAMP WHERE report_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(updateStatusQuery)) {
                    ps.setInt(1, reportId);
                    ps.executeUpdate();
                }
            }

            conn.commit(); // Commit both insert and possible update
            JOptionPane.showMessageDialog(this, "Comment added successfully!");

            // 4. Reload comments section
            loadComments();

            // 5. Notify Admin Dashboard to reload maintenance reports
            adminDashboard.loadMaintenanceReports();

            // Close the comment form
            this.dispose();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding comment: " + e.getMessage());
        }
    }



  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        addcomment = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        sendbtn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        commentsection = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        addcomment.setBackground(new java.awt.Color(255, 255, 255));
        addcomment.setColumns(20);
        addcomment.setForeground(new java.awt.Color(0, 0, 0));
        addcomment.setRows(5);
        addcomment.setText("  Add comment");
        addcomment.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jScrollPane2.setViewportView(addcomment);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        sendbtn.setBackground(new java.awt.Color(255, 255, 255));
        sendbtn.setForeground(new java.awt.Color(0, 0, 0));
        sendbtn.setText("Send");
        sendbtn.setBorder(null);
        sendbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(sendbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sendbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        commentsection.setEditable(false);
        commentsection.setBackground(new java.awt.Color(255, 255, 255));
        commentsection.setColumns(20);
        commentsection.setForeground(new java.awt.Color(0, 0, 0));
        commentsection.setRows(5);
        commentsection.setBorder(null);
        jScrollPane1.setViewportView(commentsection);

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Report Updates:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sendbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendbtnActionPerformed
      String newComment = addcomment.getText().trim();

    if (newComment.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a comment first!");
        return;
    }

    try (Connection conn = DBconnection.getConnection()) {
        conn.setAutoCommit(false); // Start transaction

        // 1. Insert the new comment
        String insertQuery = "INSERT INTO maintenance_updates (report_id, update_message, updated_at) VALUES (?, ?, NOW())";
        PreparedStatement ps = conn.prepareStatement(insertQuery);
        ps.setInt(1, reportId);
        ps.setString(2, newComment);
        ps.executeUpdate();

        // 2. Get tenant_id from maintenance_reports
        String tenantQuery = "SELECT tenant_id FROM maintenance_reports WHERE report_id = ?";
        PreparedStatement tenantStmt = conn.prepareStatement(tenantQuery);
        tenantStmt.setInt(1, reportId);
        ResultSet tenantRs = tenantStmt.executeQuery();

        int tenantId = -1;
        if (tenantRs.next()) {
            tenantId = tenantRs.getInt("tenant_id");
        }

        if (tenantId != -1) {
            // 3. Get user_id from tenants table
            String userQuery = "SELECT user_id FROM tenants WHERE tenant_id = ?";
            PreparedStatement userStmt = conn.prepareStatement(userQuery);
            userStmt.setInt(1, tenantId);
            ResultSet userRs = userStmt.executeQuery();

            int userId = -1;
            if (userRs.next()) {
                userId = userRs.getInt("user_id");
            }

            // 4. Insert a new notification
            if (userId != -1) {
                String notifQuery = "INSERT INTO notifications (user_id, message, type, status) VALUES (?, ?, ?, 'Unread')";
                PreparedStatement notifStmt = conn.prepareStatement(notifQuery);
                // Modify the notification message here
                String issueType = ""; // Retrieve the issue_type from maintenance_reports
                String issueQuery = "SELECT issue_type FROM maintenance_reports WHERE report_id = ?";
                PreparedStatement issueStmt = conn.prepareStatement(issueQuery);
                issueStmt.setInt(1, reportId);
                ResultSet issueRs = issueStmt.executeQuery();
                if (issueRs.next()) {
                    issueType = issueRs.getString("issue_type");
                }

                notifStmt.setInt(1, userId);
                notifStmt.setString(2, "Your reported utility issue (" + issueType + ") received a new update.");
                notifStmt.setString(3, "Admin Alert");
                notifStmt.executeUpdate();
            }

        }

        conn.commit(); // Commit all changes

        // UI feedback and refresh
        addcomment.setText("");
        commentsection.setText("");
        loadComments();

        if (adminDashboard != null) {
            adminDashboard.loadMaintenanceReports(); 
            adminDashboard.showMaintenanceReportDetails(reportId);
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error adding comment: " + e.getMessage());
    }
    }//GEN-LAST:event_sendbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MaintenanceCommentsForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MaintenanceCommentsForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MaintenanceCommentsForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MaintenanceCommentsForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MaintenanceCommentsForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea addcomment;
    private javax.swing.JTextArea commentsection;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton sendbtn;
    // End of variables declaration//GEN-END:variables
}
