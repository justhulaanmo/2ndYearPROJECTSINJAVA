package Admin;

import java.sql.Connection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import Config.DBconnection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ManageAppliancesBillings extends javax.swing.JFrame {
    
    private int userId; 
    private String currentBillingPeriod;
    private String nextBillingPeriod;
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public ManageAppliancesBillings() {
        initComponents();
        loadBillingPeriods();
        setCurrentBillingPeriodInComboBox();
        
        appliancesTable.setModel(new EditableTableModel(
        new Object[]{"Appliance", "Quantity", "Fee", "Billing Period"}, 0
        ));
        
        // Hide the billing period column (4th column, index 3)
        appliancesTable.getColumnModel().getColumn(3).setMinWidth(0);
        appliancesTable.getColumnModel().getColumn(3).setMaxWidth(0);
        appliancesTable.getColumnModel().getColumn(3).setPreferredWidth(0);



        
        addappliances.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = JOptionPane.showInputDialog("Enter appliance name:");
                if (name == null || name.trim().isEmpty()) return;

                String qtyStr = JOptionPane.showInputDialog("Enter quantity:");
                String feeStr = JOptionPane.showInputDialog("Enter fee per item:");

                try {
                    int quantity = Integer.parseInt(qtyStr);
                    double fee = Double.parseDouble(feeStr);
                    addAppliance(name, quantity, fee);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter numbers for quantity and fee.");
                }
            }
        });
        
        editappliances.addActionListener(e -> {
    int selectedRow = appliancesTable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an appliance to edit.");
        return;
    }

    String currentName = (String) appliancesTable.getValueAt(selectedRow, 0);
    int currentQty = (int) appliancesTable.getValueAt(selectedRow, 1);
    double currentFee = (double) appliancesTable.getValueAt(selectedRow, 2);

    String newName = JOptionPane.showInputDialog(this, "Appliance name:", currentName);
    if (newName == null || newName.trim().isEmpty()) return;

    String qtyStr = JOptionPane.showInputDialog(this, "Quantity:", currentQty);
    String feeStr = JOptionPane.showInputDialog(this, "Fee:", currentFee);

    try {
        int newQty = Integer.parseInt(qtyStr);
        double newFee = Double.parseDouble(feeStr);

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to update this appliance?", "Confirm Update", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        updateAppliance(currentName, currentBillingPeriod, newName, newQty, newFee);
        loadAppliancesForBillingPeriod();

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Invalid input. Quantity and fee must be numbers.");
    }
});

        
        removeappliances.addActionListener(e -> {
    int selectedRow = appliancesTable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an appliance to remove.");
        return;
    }

    String name = (String) appliancesTable.getValueAt(selectedRow, 0);

    int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this appliance?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    deleteAppliance(name, currentBillingPeriod);
    loadAppliancesForBillingPeriod();
});

        
        
        
        billingperiod.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        currentBillingPeriod = (String) billingperiod.getSelectedItem();
        loadAppliancesForBillingPeriod(); // GOOD
    }
});

    }
    
    public void setTenantId(int userId) {
     this.userId = userId;
     loadBillingPeriods(); // re-load
     setCurrentBillingPeriodInComboBox(); // set again after loading
     loadAppliancesForBillingPeriod();
 }


    private void loadBillingPeriods() {
    billingperiod.removeAllItems(); // Clear existing items first

    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT DISTINCT billing_period FROM appliances WHERE user_id = ? ORDER BY appliance_id DESC";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();

        boolean hasData = false;
        while (rs.next()) {
            String billingPeriod = rs.getString("billing_period");
            billingperiod.addItem(billingPeriod);
            hasData = true;
        }

        if (!hasData) {
            // If walang existing appliances, show default billing periods (optional)
            int currentYear = java.time.Year.now().getValue();
            String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
            
            for (String month : months) {
                String billingPeriod = month + " " + currentYear;
                billingperiod.addItem(billingPeriod);
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to load billing periods: " + e.getMessage());
    }
}

    
    private void setCurrentBillingPeriodInComboBox() {
    if (currentBillingPeriod != null) {
        billingperiod.setSelectedItem(currentBillingPeriod);
    }
}



    private String getNextBillingPeriod(String current) {
        try {
            String[] parts = current.split(" ");
            String month = parts[0];
            int year = Integer.parseInt(parts[1]);
            
            String[] months = {"January", "February", "March", "April", "May", "June",
                               "July", "August", "September", "October", "November", "December"};

            int index = -1;
            for (int i = 0; i < months.length; i++) {
                if (months[i].equalsIgnoreCase(month)) {
                    index = i;
                    break;
                }
            }

            if (index == -1) return current;

            index++;
            if (index >= 12) {
                index = 0;
                year++;
            }

            return months[index] + " " + year;
        } catch (Exception e) {
            return current;
        }
    }
  
    private void loadAppliancesForBillingPeriod() {
    DefaultTableModel model = (DefaultTableModel) appliancesTable.getModel();
    model.setRowCount(0); // Clear previous data

    double totalFee = 0.0;
    currentBillingPeriod = (String) billingperiod.getSelectedItem();

    System.out.println("Loading appliances for tenantId: " + userId + " and billingPeriod: " + currentBillingPeriod);

    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT appliance_name, quantity, fee_per_item, billing_period FROM appliances WHERE user_id = ? AND billing_period = ?";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, userId); // <-- new field name
        ps.setString(2, currentBillingPeriod);
        ResultSet rs = ps.executeQuery();


        boolean found = false;
        while (rs.next()) {
        found = true;
        String name = rs.getString("appliance_name");
        int quantity = rs.getInt("quantity");
        double fee = rs.getDouble("fee_per_item");
        String billingPeriod = rs.getString("billing_period");

            //double subtotal = quantity * fee;
            totalFee += fee;

            model.addRow(new Object[]{name, quantity, fee, billingPeriod});
        }

        if (!found) {
            System.out.println("No appliances found for this tenant and billing period!");
        }

        totalfee.setText("₱ " + String.format("%.2f", totalFee));

    } catch (SQLException e) {
        e.printStackTrace(); // show full error
        JOptionPane.showMessageDialog(this, "Failed to load appliances: " + e.getMessage());
    }
}



    
    public void copyAppliancesToNextBilling() {
    if (currentBillingPeriod == null) return;

    String nextBillingPeriod = getNextBillingPeriod(currentBillingPeriod);

    try (Connection conn = DBconnection.getConnection()) {
        // Check if appliances already exist for the next billing period
        String checkQuery = "SELECT COUNT(*) FROM appliances WHERE user_id = ? AND billing_period = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
        checkStmt.setInt(1, userId);
        checkStmt.setString(2, nextBillingPeriod);
        ResultSet checkResult = checkStmt.executeQuery();

        if (checkResult.next() && checkResult.getInt(1) == 0) {
            // No entries found in next billing, proceed with copy
            String insertQuery = "INSERT INTO appliances (user_id, billing_period, appliance_name, quantity, fee_per_item) " +
                                 "SELECT user_id, ?, appliance_name, quantity, fee_per_item FROM appliances WHERE user_id = ? AND billing_period = ?";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setString(1, nextBillingPeriod);
            insertStmt.setInt(2, userId);
            insertStmt.setString(3, currentBillingPeriod);

            int rowsInserted = insertStmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Appliances copied to " + nextBillingPeriod);
            } else {
                JOptionPane.showMessageDialog(this, "No appliances to copy.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Next billing period already has appliance data.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to copy appliances: " + e.getMessage());
    }
}


    private void updateTotalFee() {
    DefaultTableModel model = (DefaultTableModel) appliancesTable.getModel();
    double total = 0.0;

    for (int i = 0; i < model.getRowCount(); i++) {
        String rowBilling = (String) model.getValueAt(i, 3); // index 3 is billing period

        if (rowBilling.equals(currentBillingPeriod)) {
            Double fee = (Double) model.getValueAt(i, 2); // Only get fee_per_item (no need to use quantity)

            if (fee == null) fee = 0.0; // If fee is null, treat as 0

            total += fee; // Add fee_per_item to total
            System.out.println("Row billing: " + rowBilling + " | current: " + currentBillingPeriod);
        }
    }

    totalfee.setText("₱ " + String.format("%.2f", total)); // Display total
}


    
    public void addAppliance(String name, int quantity, double feePerItem) {
    DefaultTableModel model = (DefaultTableModel) appliancesTable.getModel();
    model.addRow(new Object[]{name, quantity, feePerItem, currentBillingPeriod}); // <- fix here
    updateTotalFee();
    updateApplianceFeeInBillingPayments();

    saveAppliance(name, quantity, feePerItem);
    autoCopyToNextBillingIfNotExists();
}

    private void saveAppliance(String name, int quantity, double feePerItem) {
    try (Connection conn = DBconnection.getConnection()) {
        String query = "INSERT INTO appliances (user_id, billing_period, appliance_name, quantity, fee_per_item) " +
                       "VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, userId);
        ps.setString(2, currentBillingPeriod);
        ps.setString(3, name);
        ps.setInt(4, quantity);
        ps.setDouble(5, feePerItem);
        ps.executeUpdate();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to save appliance: " + e.getMessage());
    }
}

    private void autoCopyToNextBillingIfNotExists() {
    String nextBillingPeriod = getNextBillingPeriod(currentBillingPeriod);

    try (Connection conn = DBconnection.getConnection()) {
        // Check if data for next billing already exists
        String checkQuery = "SELECT COUNT(*) FROM appliances WHERE user_id = ? AND billing_period = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
        checkStmt.setInt(1, userId);
        checkStmt.setString(2, nextBillingPeriod);
        ResultSet rs = checkStmt.executeQuery();
        if (rs.next() && rs.getInt(1) == 0) {
            // Copy current billing to next
            String insertQuery = "INSERT INTO appliances (user_id, billing_period, appliance_name, quantity, fee_per_item) " +
                                 "SELECT user_id, ?, appliance_name, quantity, fee_per_item " +
                                 "FROM appliances WHERE user_id = ? AND billing_period = ?";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setString(1, nextBillingPeriod);
            insertStmt.setInt(2, userId);
            insertStmt.setString(3, currentBillingPeriod);
            insertStmt.executeUpdate();

            System.out.println("Copied appliances to next billing period: " + nextBillingPeriod);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to copy appliances to next billing: " + e.getMessage());
    }
}
    
    private void updateAppliance(String oldName, String billingPeriod, String newName, int qty, double fee) {
    try (Connection conn = DBconnection.getConnection()) {
        String query = "UPDATE appliances SET appliance_name = ?, quantity = ?, fee_per_item = ? WHERE user_id = ? AND appliance_name = ? AND billing_period = ?";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, newName);
        ps.setInt(2, qty);
        ps.setDouble(3, fee);
        ps.setInt(4, userId);
        ps.setString(5, oldName);
        ps.setString(6, billingPeriod);
        ps.executeUpdate();
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to update appliance: " + e.getMessage());
    }
}

private void deleteAppliance(String name, String billingPeriod) {
    try (Connection conn = DBconnection.getConnection()) {
        String query = "DELETE FROM appliances WHERE user_id = ? AND appliance_name = ? AND billing_period = ?";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, userId);
        ps.setString(2, name);
        ps.setString(3, billingPeriod);
        ps.executeUpdate();
        
        updateApplianceFeeInBillingPayments();
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Failed to delete appliance: " + e.getMessage());
    }
}


        private void updateApplianceFeeInBillingPayments() {
    try (Connection conn = DBconnection.getConnection()) {
        // Sum the total appliance fees for the current billing period
        String sumQuery = "SELECT SUM(quantity * fee_per_item) AS total_fee FROM appliances WHERE user_id = ? AND billing_period = ?";
        PreparedStatement sumStmt = conn.prepareStatement(sumQuery);
        sumStmt.setInt(1, userId);
        sumStmt.setString(2, currentBillingPeriod);
        ResultSet rs = sumStmt.executeQuery();

        double totalFee = 0.0;
        if (rs.next()) {
            totalFee = rs.getDouble("total_fee");
        }

        // Update the billing_payments table
        String updateQuery = "UPDATE billing_payments SET appliance_fee = ?, total_payable = amount_due + ? + late_fee WHERE tenant_id = ? AND billing_period = ?";
        PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
        updateStmt.setDouble(1, totalFee);
        updateStmt.setDouble(2, totalFee); // total_payable = amount_due + appliance_fee + late_fee
        updateStmt.setInt(3, userId); // tenant_id here is equivalent to your userId
        updateStmt.setString(4, currentBillingPeriod);

        updateStmt.executeUpdate();

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to update billing payments: " + e.getMessage());
    }
}


    
    
    public class EditableTableModel extends DefaultTableModel {
    private int editableRow = -1;

    public EditableTableModel(Object[] columnNames, int rowCount) {
        super(columnNames, rowCount);
    }

    @Override
    public boolean isCellEditable(int row, int column) {
        return row == editableRow;
    }

    public void setEditableRow(int row) {
        this.editableRow = row;
        fireTableDataChanged();
    }
}



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        billingperiod = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        appliancesTable = new javax.swing.JTable();
        editappliances = new javax.swing.JButton();
        addappliances = new javax.swing.JButton();
        removeappliances = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        totalfee = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(569, 389));
        setMinimumSize(new java.awt.Dimension(569, 389));
        setResizable(false);
        setSize(new java.awt.Dimension(569, 389));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setMaximumSize(new java.awt.Dimension(569, 389));
        jPanel1.setMinimumSize(new java.awt.Dimension(569, 389));

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Billing Period:");

        billingperiod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Billing Period" }));

        appliancesTable.setBackground(new java.awt.Color(255, 255, 255));
        appliancesTable.setForeground(new java.awt.Color(0, 0, 0));
        appliancesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "quantity", "fee"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        appliancesTable.setIgnoreRepaint(true);
        appliancesTable.setOpaque(false);
        jScrollPane1.setViewportView(appliancesTable);

        editappliances.setText("Edit Appliance");
        editappliances.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editappliancesActionPerformed(evt);
            }
        });

        addappliances.setText("Add Appliance");

        removeappliances.setText("Remove Appliance");
        removeappliances.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeappliancesActionPerformed(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Total Appliance Fee:");

        totalfee.setForeground(new java.awt.Color(255, 102, 102));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(totalfee, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(billingperiod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(editappliances)
                            .addComponent(addappliances)
                            .addComponent(removeappliances))))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(billingperiod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(editappliances)
                        .addGap(12, 12, 12)
                        .addComponent(addappliances)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(removeappliances)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(totalfee, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(76, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void removeappliancesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeappliancesActionPerformed

    }//GEN-LAST:event_removeappliancesActionPerformed

    private void editappliancesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editappliancesActionPerformed

    }//GEN-LAST:event_editappliancesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageAppliancesBillings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageAppliancesBillings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageAppliancesBillings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageAppliancesBillings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageAppliancesBillings().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addappliances;
    private javax.swing.JTable appliancesTable;
    private javax.swing.JComboBox<String> billingperiod;
    private javax.swing.JButton editappliances;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton removeappliances;
    private javax.swing.JLabel totalfee;
    // End of variables declaration//GEN-END:variables
}