package Admin;

import Config.DBconnection;
import Tenant.Login;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Random;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import org.mindrot.jbcrypt.BCrypt;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;







public class admin_dashboard extends javax.swing.JFrame {
        
    private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;
    private int reservationId; 
    private int currentReportId;
    private String currentPhoto1Path = null;
    private String currentPhoto2Path = null;
    private int selectedTenantId = -1; // default -1 para walang pinili pa
    private JButton selectedButton = null;
    private JButton selectedMaintenanceButton = null;

    

        public admin_dashboard() {
        initComponents();
        setLocationRelativeTo(null); // Center the frame
        updateDashboardCounts();
    
        
        showTenantProfile.setLayout(new BoxLayout(showTenantProfile, BoxLayout.Y_AXIS));
        listofteportedtenantsnamespanel.setLayout(new BoxLayout(listofteportedtenantsnamespanel, BoxLayout.Y_AXIS));
        
        loadPendingReservations(); // optional if unrelated
        loadTenants("ALL"); // now this won't throw an error
        loadMaintenanceReports();
        
        
        //===========================
                
             
        String[] months = {
            "January 2025", "February 2025", "March 2025", "April 2025",
            "May 2025", "June 2025", "July 2025", "August 2025",
            "September 2025", "October 2025", "November 2025", "December 2025"
        };

        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(months);
        selectMonthCombo.setModel(model);

        // Select current month
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        String currentMonth = today.format(formatter);
        selectMonthCombo.setSelectedItem(currentMonth);

       
        selectMonthCombo.addActionListener(e -> {
            String selectedMonth = (String) selectMonthCombo.getSelectedItem();
            computeMonthlySales(selectedMonth);
        });


        //===========================
        
        
        
        roomnum.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            String selectedRoom = (String) roomnum.getSelectedItem();
            if (selectedRoom != null && selectedRoom.contains(" - ")) {
                try {
                    int roomId = Integer.parseInt(selectedRoom.split(" - ")[0]);
                    populateBedComboBox(roomId);
                } catch (NumberFormatException ex) {
                    System.out.println("Invalid room ID format: " + selectedRoom);
                }
            }
        }
    });

            // Inside AdminDashboard class
    manageappliances.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedTenantId != -1) {
                ManageAppliancesBillings mab = new ManageAppliancesBillings();
                mab.setUserId(selectedTenantId);
                mab.setVisible(true);
                mab.setLocationRelativeTo(null);
                
            } else {
                JOptionPane.showMessageDialog(null, "Please select a tenant first!");
            }
        }
    });

        
        photo1preview.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mouseClicked(java.awt.event.MouseEvent evt) {
            showImageInPopup(currentPhoto1Path);
    }
});
        photo2preview.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mouseClicked(java.awt.event.MouseEvent evt) {
            showImageInPopup(currentPhoto2Path);
    }
});
        
        reservationTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
    public void valueChanged(ListSelectionEvent event) {
        if (!event.getValueIsAdjusting()) {
            int selectedRow = reservationTable.getSelectedRow();
            if (selectedRow != -1) {
                int reservationId = (int) reservationTable.getValueAt(selectedRow, 2); // column 2 is hidden but accessible
                displayReservationDetails(reservationId);
            }
        }
    }
});


       acceptButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        int selectedRow = reservationTable.getSelectedRow();
        if (selectedRow != -1) {
            try {
                int reservationId = (int) reservationTable.getValueAt(selectedRow, 2); // Hidden ID
                String selectedRoom = roomnum.getSelectedItem().toString();
                int roomId = Integer.parseInt(selectedRoom.split(" - ")[0].trim());
                int bedNumber = Integer.parseInt(bednum.getSelectedItem().toString());

                java.util.Date utilDate = moveInDateChooser.getDate(); // ✅ No cast needed
                if (utilDate == null) {
                    JOptionPane.showMessageDialog(null, "Please select a move-in date.");
                    return;
                }
                java.sql.Date sqlMoveInDate = new java.sql.Date(utilDate.getTime());

                acceptReservation(reservationId, roomId, bedNumber, sqlMoveInDate);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a reservation first.");
        }
    }
});
       

    updatestatusbtn.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = roomoverview.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a bed to update.");
            return;
        }

        // Get current status from selected row
        String currentStatus = roomoverview.getValueAt(selectedRow, 3).toString();

        // Status options
        String[] statuses = { "Available", "Occupied", "Under Maintenance" };
        JComboBox<String> statusComboBox = new JComboBox<>(statuses);

        // Set current status as selected item
        statusComboBox.setSelectedItem(currentStatus);

        // Show combo box in dialog
        int result = JOptionPane.showConfirmDialog(
            null,
            statusComboBox,
            "Select Bed Status",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            String selectedStatus = (String) statusComboBox.getSelectedItem();

            // Get identifiers for update
            String roomName = roomoverview.getValueAt(selectedRow, 0).toString();
            int bedNumber = Integer.parseInt(roomoverview.getValueAt(selectedRow, 2).toString());

            // Update DB and refresh table
            updateBedStatus(roomName, bedNumber, selectedStatus);
            loadRoomOverview();
        }
    }
});

        selectMonthCombo.addActionListener(e -> {
        String selectedMonth = (String) selectMonthCombo.getSelectedItem();
        computeMonthlySales(selectedMonth);
    });


        
//======================================TENANTS PROFILE LIST=======================================================//
         
        genderComboBox.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent evt) {
        String selectedGender = genderComboBox.getSelectedItem().toString();
        loadTenants(selectedGender); // this refreshes the buttons
    }
});
//=================================================================================================================//
         

        roomnum.addActionListener(e -> {
    // Clear and reset the bed combo box when room changes
    bednum.removeAllItems();
    bednum.addItem("Select Bed Number");

    // Populate the beds based on selected room number
    if (roomnum.getSelectedIndex() > 0) {
        // Get roomId from selected room item, assuming it's in the format "roomId - roomName"
        String selectedRoom = roomnum.getSelectedItem().toString();
        int roomId = Integer.parseInt(selectedRoom.split(" - ")[0]);
        populateBedComboBox(roomId);  // Populate bed numbers for the selected room
    }
});

        
    }
        
//======================================DISPLAY DASHBOARD==========================================================//        
        
       private void updateDashboardCounts() {
            Connection conn = null;
            try {
                // Establish database connection
                conn = DBconnection.getConnection();

                if (conn == null) {
                    System.out.println("Database connection failed.");
                    return;
                }

                    // 1. Count tenants
        String tenantQuery = "SELECT COUNT(*) FROM tenants";
        PreparedStatement tenantStmt = conn.prepareStatement(tenantQuery);
        ResultSet tenantRs = tenantStmt.executeQuery();
        if (tenantRs.next()) {
            int tenantCount = tenantRs.getInt(1);
            String tenantsText = "Number of Tenants:\n"
                               + "-------------------------\n\n\n"
                               + "                  " + tenantCount;
            num_tenants.setText(tenantsText);
        }
        tenantStmt.close();
        tenantRs.close();

        // 2. Count available beds (overall)
        String bedQuery = "SELECT COUNT(*) FROM rooms WHERE status = 'Available'";
        PreparedStatement bedStmt = conn.prepareStatement(bedQuery);
        ResultSet bedRs = bedStmt.executeQuery();
        if (bedRs.next()) {
            int availableBeds = bedRs.getInt(1);
            num_rooms.setText("Number of Available Rooms: " + availableBeds);
        }
        bedStmt.close();
        bedRs.close();

        // 3. Count available rooms per gender
        String maleRoomQuery = "SELECT COUNT(*) FROM rooms WHERE status = 'Available' AND gender = 'Male'";
        String femaleRoomQuery = "SELECT COUNT(*) FROM rooms WHERE status = 'Available' AND gender = 'Female'";

        PreparedStatement maleStmt = conn.prepareStatement(maleRoomQuery);
        ResultSet maleRs = maleStmt.executeQuery();
        int maleRoomCount = 0;
        if (maleRs.next()) {
            maleRoomCount = maleRs.getInt(1);
        }
        maleStmt.close();
        maleRs.close();

        PreparedStatement femaleStmt = conn.prepareStatement(femaleRoomQuery);
        ResultSet femaleRs = femaleStmt.executeQuery();
        int femaleRoomCount = 0;
        if (femaleRs.next()) {
            femaleRoomCount = femaleRs.getInt(1);
        }
        femaleStmt.close();
        femaleRs.close();

        // Custom design for number of rooms
        String roomsText = "Number of Available Rooms:\n\n"
                         + "---------------------------\n"
                         + "Male Room: " + maleRoomCount + "\n\n"
                         + "Female Room: " + femaleRoomCount;
        num_rooms.setText(roomsText);


                // 4. Available beds per Room (populate JTable)
                String availableBedsPerRoomQuery = "SELECT r.room_name, COUNT(b.bed_id) AS available_beds " +
                                                   "FROM beds b " +
                                                   "JOIN rooms r ON b.room_id = r.room_id " +
                                                   "WHERE b.status = 'Available' " +
                                                   "GROUP BY r.room_id";

                PreparedStatement perRoomStmt = conn.prepareStatement(availableBedsPerRoomQuery);
                ResultSet perRoomRs = perRoomStmt.executeQuery();

                // Prepare data for JTable
                List<Object[]> tableData = new ArrayList<>();

                while (perRoomRs.next()) {
                    String roomName = perRoomRs.getString("room_name");
                    int availableBedsInRoom = perRoomRs.getInt("available_beds");

                    tableData.add(new Object[]{ roomName, availableBedsInRoom });
                }
                perRoomStmt.close();
                perRoomRs.close();

                // Now populate JTable
                String[] columnNames = { "<html>Room<br>Name</html>", "<html>Available<br>Beds</html>" };
                Object[][] data = tableData.toArray(new Object[0][]);

                DefaultTableModel model = new DefaultTableModel(data, columnNames) {

                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false; // make table cells not editable
                    }
                };

                num_beds.setModel(model);
      
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }

        
//======================================TENANTS PROFILE LIST=======================================================//
        
        public void loadTenants(String genderFilter) {
    showTenantProfile.removeAll(); // clear previous buttons

    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT user_id, full_name, gender FROM tenants";
        if (!genderFilter.equals("All")) {
            query += " WHERE gender = ?";
        }

        PreparedStatement stmt = conn.prepareStatement(query);
        if (!genderFilter.equals("All")) {
            stmt.setString(1, genderFilter);
        }

        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            String fullName = rs.getString("full_name");
            int userId = rs.getInt("user_id");

            JButton tenantBtn = new JButton(fullName);
            tenantBtn.setPreferredSize(new Dimension(220, 50)); 
            tenantBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
            tenantBtn.setFocusPainted(false);
            tenantBtn.setContentAreaFilled(false); 
            tenantBtn.setOpaque(true);
            tenantBtn.setBackground(new Color(240, 240, 240));
            tenantBtn.setForeground(new Color(50, 50, 50));
            tenantBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
            ));
            tenantBtn.setFont(new Font("Segoe UI", Font.PLAIN, 14));

            // Add action listener with highlight + profile loading
            tenantBtn.addActionListener(e -> {
                if (selectedButton != null) {
                    selectedButton.setBackground(new Color(240, 240, 240));
                    selectedButton.setForeground(new Color(50, 50, 50));
                }

                tenantBtn.setBackground(new Color(0,153,153));
                tenantBtn.setForeground(Color.WHITE);
                selectedButton = tenantBtn;

                showTenantProfile(userId);
            });

            showTenantProfile.add(tenantBtn); // ✅ Add to correct panel
        }

        showTenantProfile.revalidate();
        showTenantProfile.repaint();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading tenants: " + e.getMessage());
    }
}

        public void showTenantProfile(int userId) {
            selectedTenantId = userId;
        try (Connection conn = DBconnection.getConnection()) {
            String query = "SELECT * FROM tenants WHERE user_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String fullName = rs.getString("full_name"); // still display name
                String email = rs.getString("email");
                String contact = rs.getString("contact_number");
                String gender = rs.getString("gender");
                String room = rs.getString("room_id");
                String bedNumber = rs.getString("bed_number");
                String moveInDate = rs.getString("move_in_date");
                String moveOutDate = rs.getString("move_out_date");
                String tenantCode = rs.getString("tenant_code");
                String emergencyName = rs.getString("emergency_contact_name");
                String emergencyContact = rs.getString("emergency_contact_number");
                String emergencyRelationship = rs.getString("emergency_contact_relationship");
                String Status = rs.getString("status");

                fullname1.setText(fullName);
                email1.setText(email);
                contactnum.setText(contact);
                gender1.setText(gender);
                roomnum1.setText(room);
                bednum1.setText(bedNumber);
                moveindate1.setText(moveInDate);
                tenantcode.setText(tenantCode);
                emergencyname.setText(emergencyName);
                emergencynum.setText(emergencyContact);
                emergencyrelationship.setText(emergencyRelationship);
                registrationstatus.setText(Status);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading profile: " + e.getMessage());
        }
    }

        
        
//========================================FOR ROOM MANAGEMENT============================================================//                

        private void loadRoomOverview() {
        DefaultTableModel model = (DefaultTableModel) roomoverview.getModel();
        model.setRowCount(0);  // Clear existing rows

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBconnection.getConnection();

            String genderFilter = roomoverviewgender.getSelectedItem().toString();
            String statusFilter = roomoverviewstatus.getSelectedItem().toString();

            // Base query
            String query = "SELECT r.room_name, r.gender, b.bed_number, b.status " +
                           "FROM rooms r " +
                           "JOIN beds b ON r.room_id = b.room_id WHERE 1=1";

            // Add filters if not "All"
            if (!genderFilter.equals("All")) {
                query += " AND r.gender = ?";
            }
            if (!statusFilter.equals("All")) {
                query += " AND b.status = ?";
            }

            query += " ORDER BY r.room_name, b.bed_number";

            ps = conn.prepareStatement(query);

            int paramIndex = 1;
            if (!genderFilter.equals("All")) {
                ps.setString(paramIndex++, genderFilter);
            }
            if (!statusFilter.equals("All")) {
                ps.setString(paramIndex++, statusFilter);
            }

            rs = ps.executeQuery();

            while (rs.next()) {
                String roomName = rs.getString("room_name");
                String gender = rs.getString("gender");
                int bedNumber = rs.getInt("bed_number");
                String status = rs.getString("status");

                model.addRow(new Object[]{ roomName, gender, bedNumber, status });
            }

            // Center alignment
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
            for (int i = 0; i < roomoverview.getColumnCount(); i++) {
                roomoverview.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
            ((DefaultTableCellRenderer) roomoverview.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) {}
            try { if (ps != null) ps.close(); } catch (SQLException e) {}
            try { if (conn != null) conn.close(); } catch (SQLException e) {}
        }
    }
        
        private void updateBedStatus(String roomName, int bedNumber, String newStatus) {
    String updateQuery = "UPDATE beds b " +
                         "JOIN rooms r ON b.room_id = r.room_id " +
                         "SET b.status = ? " +
                         "WHERE r.room_name = ? AND b.bed_number = ?";

    try (Connection conn = DBconnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(updateQuery)) {

        stmt.setString(1, newStatus);
        stmt.setString(2, roomName);
        stmt.setInt(3, bedNumber);

        int rowsUpdated = stmt.executeUpdate();
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(null, "Bed status updated successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "No rows were updated. Check data.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error updating bed status: " + e.getMessage());
    }
}


//=======================================PENDING RESERVATION PANEL=================================================//         
        
        private void loadPendingReservations() {
    DefaultTableModel model = (DefaultTableModel) reservationTable.getModel();
    model.setRowCount(0);  // Clear existing rows

    try {
        conn = DBconnection.getConnection();
        String query = "SELECT reservation_id, full_name, reservation_date FROM reservations WHERE status = 'Pending'";
        ps = conn.prepareStatement(query);
        rs = ps.executeQuery();

        while (rs.next()) {
            int reservationId = rs.getInt("reservation_id");
            String fullName = rs.getString("full_name"); 
            Timestamp reservationDate = rs.getTimestamp("reservation_date");

            model.addRow(new Object[]{ fullName, reservationDate, reservationId});
            
            reservationTable.getColumnModel().getColumn(2).setMinWidth(0);
            reservationTable.getColumnModel().getColumn(2).setMaxWidth(0);
            reservationTable.getColumnModel().getColumn(2).setWidth(0);

        }

    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}

 
        public void displayReservationDetails(int reservationId) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                conn = DBconnection.getConnection();

                // Query to get the reservation details by reservation_id
                String sql = "SELECT * FROM reservations WHERE reservation_id = ?";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, reservationId);
                rs = ps.executeQuery();

                if (rs.next()) {
                    // Retrieve reservation data
                    String fullName = rs.getString("full_name");
                    String contactNumber = rs.getString("contact_number");
                    String Email = rs.getString("email");
                    String gender = rs.getString("gender");
                    String amountPaid = rs.getString("amount_paid");
                    String reservationDate = rs.getString("reservation_date");

                    // Display reservation data in the right panel
                    datereserve.setText(reservationDate);
                    fullname.setText(fullName);
                    contactnumber.setText(contactNumber);
                    email.setText(Email);
                    genderr.setText(gender);
                    amountpaid.setText(amountPaid);

                    // Step 1: Populate Room ComboBox based on gender
                    populateRoomComboBox(gender);

                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (SQLException e) {}
                try { if (ps != null) ps.close(); } catch (SQLException e) {}
                try { if (conn != null) conn.close(); } catch (SQLException e) {}
            }
        }

    
        
       private void acceptReservation(int reservationId, int roomId, int bedNumber, Date moveInDate) {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
        conn = DBconnection.getConnection();

        // Step 1: Get reservation details (including amount_paid and payment_method)
        String getReservation = "SELECT full_name, contact_number, email, gender, amount_paid, payment_method FROM reservations WHERE reservation_id = ?";
        ps = conn.prepareStatement(getReservation);
        ps.setInt(1, reservationId);
        rs = ps.executeQuery();

        if (rs.next()) {
            String fullName = rs.getString("full_name");
            String contact = rs.getString("contact_number");
            String email = rs.getString("email");
            String gender = rs.getString("gender");
            BigDecimal amountPaid = rs.getBigDecimal("amount_paid");
            String paymentMethod = rs.getString("payment_method");

            // Step 2: Generate tenant code
            String tenantCode = generateTenantCode();

            // Step 3: Insert into tenants
            String insertTenant = "INSERT INTO tenants (full_name, contact_number, email, gender, room_id, bed_number, move_in_date, tenant_code, status) " +
                                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            ps = conn.prepareStatement(insertTenant, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, fullName);
            ps.setString(2, contact);
            ps.setString(3, email);
            ps.setString(4, gender);
            ps.setInt(5, roomId);
            ps.setInt(6, bedNumber);
            ps.setDate(7, new java.sql.Date(moveInDate.getTime()));
            ps.setString(8, tenantCode);
            ps.setString(9, "Not Registered");
            ps.executeUpdate();

            ResultSet tenantKeys = ps.getGeneratedKeys();
            if (tenantKeys.next()) {
                int tenantId = tenantKeys.getInt(1);

                // Step 4: Insert into payments
                String insertPayment = "INSERT INTO reservation_payments (tenant_id, amount_due, amount_paid, payment_method, payment_status, payment_date) " +
                                       "VALUES (?, ?, ?, ?, ?, ?)";
                ps = conn.prepareStatement(insertPayment);
                ps.setInt(1, tenantId);
                ps.setBigDecimal(2, amountPaid); // assuming amount_due = amount_paid in this case
                ps.setBigDecimal(3, amountPaid);
                ps.setString(4, paymentMethod);
                ps.setString(5, "Paid");
                ps.setDate(6, new java.sql.Date(System.currentTimeMillis()));
                ps.executeUpdate();

                // Step 5: Update bed status
                updateBedStatus(roomId, bedNumber);

                // Step 6: Update reservation status
                String updateStatus = "UPDATE reservations SET status = 'Approved' WHERE reservation_id = ?";
                ps = conn.prepareStatement(updateStatus);
                ps.setInt(1, reservationId);
                ps.executeUpdate();

                // Step 7: Send email with tenant code
                sendTenantCodeEmail(email, fullName, tenantCode);

                JOptionPane.showMessageDialog(null, "Reservation accepted! Tenant code sent to email.");

                // Step 8: Delete reservation after approval
                String deleteReservation = "DELETE FROM reservations WHERE reservation_id = ?";
                ps = conn.prepareStatement(deleteReservation);
                ps.setInt(1, reservationId);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Reservation accepted! Tenant code sent to email.");
                
                // Step 9: Create user account
                String autoPassword = fullName.replaceAll("\\s+", "") + tenantCode;
                String hashedPassword = hashPassword(autoPassword); // now uses BCrypt


                String insertUser = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'Tenant')";
                ps = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, email);
                ps.setString(2, hashedPassword);
                ps.executeUpdate();

                // Get the generated user_id
                ResultSet userKeys = ps.getGeneratedKeys();
                if (userKeys.next()) {
                    int userId = userKeys.getInt(1);

                    // Step 10: Update tenants table with the user_id
                    String updateTenant = "UPDATE tenants SET user_id = ? WHERE tenant_id = ?";
                    ps = conn.prepareStatement(updateTenant);
                    ps.setInt(1, userId);
                    ps.setInt(2, tenantId);
                    ps.executeUpdate();
                    
                    loadPendingReservations();
                }
            }
        }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

        public String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(10));
    }

            public String generateTenantCode() {
        Random random = new Random();
        int code = 10000 + random.nextInt(90000);
        return "TEN-" + code;
    }

        public void sendTenantCodeEmail(String recipientEmail, String fullName, String tenantCode) {
        final String senderEmail = "itsbeasarong@gmail.com"; // Replace with sender email
        final String senderPassword = "sdfu itqy dddw felt"; // Use Gmail app password

        String autoPassword = fullName.replaceAll("\\s+", "") + tenantCode;
        String subject = "Welcome to Bea's Boarding House";
        String messageText = "Hi " + fullName + ",\n\n" +
                            "Here is your Tenant Code: " + tenantCode + "\n" +
                            "Your temporary password is: " + autoPassword + "\n\n" +
                            "Use these credentials to log in to your account.\n\n" +
                            "Thank you!";


        java.util.Properties props = new java.util.Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        javax.mail.Session session = javax.mail.Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            javax.mail.Message message = new javax.mail.internet.MimeMessage(session);
            message.setFrom(new javax.mail.internet.InternetAddress(senderEmail));
            message.setRecipients(javax.mail.Message.RecipientType.TO,
                    javax.mail.internet.InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setText(messageText);

            javax.mail.Transport.send(message);
            System.out.println("Email sent to " + recipientEmail);
        } catch (javax.mail.MessagingException e) {
            e.printStackTrace();
        }
    }

        private void rejectReservation(int reservationId) {
            try {
                conn = DBconnection.getConnection();

                // 1. Delete the reservation
                String deleteQuery = "DELETE FROM reservations WHERE reservation_id = ?";
                ps = conn.prepareStatement(deleteQuery);
                ps.setInt(1, reservationId);
                ps.executeUpdate();

                // 2. Check if reservations table is empty
                String checkQuery = "SELECT COUNT(*) AS total FROM reservations";
                ps = conn.prepareStatement(checkQuery);
                rs = ps.executeQuery();

                if (rs.next() && rs.getInt("total") == 0) {
                    // 3. Reset auto_increment if table is empty
                    String resetQuery = "ALTER TABLE reservations AUTO_INCREMENT = 1";
                    ps = conn.prepareStatement(resetQuery);
                    ps.executeUpdate();
                    System.out.println("Auto-increment reset to 1.");
                }

                JOptionPane.showMessageDialog(this, "Reservation rejected.");
                loadPendingReservations();

            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (ps != null) ps.close();
                    if (conn != null) conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }

    
            // Check if the bed is available in the room
        public boolean isBedAvailable(int roomNumber, int bedNumber) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                conn = DBconnection.getConnection();

                // Query to check if the bed is available
                String sql = "SELECT status FROM beds WHERE room_id = ? AND bed_number = ?";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, roomNumber);  // Use setInt instead of setString for room_id
                ps.setInt(2, bedNumber);    // Use setInt instead of setString for bed_number
                rs = ps.executeQuery();

                if (rs.next()) {
                    String bedStatus = rs.getString("status");
                    return "Available".equals(bedStatus); // Check if bed is available
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (SQLException e) {}
                try { if (ps != null) ps.close(); } catch (SQLException e) {}
                try { if (conn != null) conn.close(); } catch (SQLException e) {}
            }

            return false;
        }

        // Update the status of the bed to "Occupied"
        public void updateBedStatus(int roomNumber, int bedNumber) {
            Connection conn = null;
            PreparedStatement ps = null;

            try {
                conn = DBconnection.getConnection();

                // Update the bed status to "Occupied"
                String sql = "UPDATE beds SET status = 'Occupied' WHERE room_id = ? AND bed_number = ?";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, roomNumber);  // Use setInt instead of setString for room_id
                ps.setInt(2, bedNumber);    // Use setInt instead of setString for bed_number
                ps.executeUpdate();
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                try { if (ps != null) ps.close(); } catch (SQLException e) {}
                try { if (conn != null) conn.close(); } catch (SQLException e) {}
            }
        }

        // Check and update the room status if it's full
        public void updateRoomStatus(int roomNumber) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                conn = DBconnection.getConnection();

                // Query to check how many beds are occupied in the room
                String sql = "SELECT COUNT(*) FROM beds WHERE room_id = ? AND status = 'Occupied'";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, roomNumber);  // Use setInt instead of setString for room_id
                rs = ps.executeQuery();

                if (rs.next()) {
                    int occupiedBeds = rs.getInt(1);

                    // Query to get the room capacity
                    String roomQuery = "SELECT capacity FROM rooms WHERE room_id = ?";
                    ps = conn.prepareStatement(roomQuery);
                    ps.setInt(1, roomNumber);  // Use setInt instead of setString for room_id
                    rs = ps.executeQuery();

                    if (rs.next()) {
                        int roomCapacity = rs.getInt("capacity");

                        // If the number of occupied beds equals room capacity, set room status to "Occupied"
                        if (occupiedBeds == roomCapacity) {
                            String updateRoomStatus = "UPDATE rooms SET status = 'Occupied' WHERE room_id = ?";
                            ps = conn.prepareStatement(updateRoomStatus);
                            ps.setInt(1, roomNumber);  // Use setInt instead of setString for room_id
                            ps.executeUpdate();
                        }
                    }
                } 
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (SQLException e) {}
                try { if (ps != null) ps.close(); } catch (SQLException e) {}
                try { if (conn != null) conn.close(); } catch (SQLException e) {}
            }
        }

                   public void populateRoomComboBox(String gender) {
                    // Clear current items in the ComboBox
                    roomnum.removeAllItems();
                    roomnum.addItem("Select Room Number"); 

                    Connection conn = null;
                    PreparedStatement ps = null;
                    ResultSet rs = null;

                    try {
                        conn = DBconnection.getConnection();

                        // Query to get rooms based on gender (assuming gender is stored in the 'beds' table)
                        String sql = "SELECT room_id, room_name FROM rooms WHERE gender = ?";
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, gender);  // Filter rooms by gender
                        rs = ps.executeQuery();

                        // Add rooms to the ComboBox
                        while (rs.next()) {
                            int roomId = rs.getInt("room_id");
                            String roomName = rs.getString("room_name");
                            roomnum.addItem(roomId + " - " + roomName);  // Display room_id and room_name
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    } finally {
                        try { if (rs != null) rs.close(); } catch (SQLException e) {}
                        try { if (ps != null) ps.close(); } catch (SQLException e) {}
                        try { if (conn != null) conn.close(); } catch (SQLException e) {}
                    }
                }


        public void populateBedComboBox(int roomId) {
    
            bednum.removeAllItems();
            bednum.addItem("Select Bed Number");

            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;

            try {
                conn = DBconnection.getConnection();


                String sql = "SELECT bed_id, bed_number FROM beds WHERE room_id = ? AND status = 'Available'";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, roomId);  // Use the selected room_id
                rs = ps.executeQuery();

                // Add available beds to the ComboBox
                while (rs.next()) {
                    int bedNumber = rs.getInt("bed_number");
                    bednum.addItem(String.valueOf(bedNumber)); 
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                try { if (rs != null) rs.close(); } catch (SQLException e) {}
                try { if (ps != null) ps.close(); } catch (SQLException e) {}
                try { if (conn != null) conn.close(); } catch (SQLException e) {}
            }
        }


//=======================================FOR MONTHLY SALES====================================================//        
        
        public void computeMonthlySales(String selectedMonth) {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    double totalRent = 0;
    double totalReservations = 0;
    double totalAppliances = 0;
    double totalExpenses = 0;

    try {
        conn = DBconnection.getConnection();
        if (conn == null) {
            System.out.println("Database connection failed.");
            return;
        }

        // Total Rent Collected
        String rentQuery = "SELECT SUM(amount_paid) FROM billing_payments WHERE billing_period = ? AND payment_status = 'Paid'";
        ps = conn.prepareStatement(rentQuery);
        ps.setString(1, selectedMonth);
        rs = ps.executeQuery();
        if (rs.next()) totalRent = rs.getDouble(1);
        rs.close();
        ps.close();

        // Total Reservation Payments
        String resQuery = "SELECT SUM(amount_paid) FROM reservation_payments WHERE payment_status = 'Paid' AND DATE_FORMAT(payment_date, '%M %Y') = ?";
        ps = conn.prepareStatement(resQuery);
        ps.setString(1, selectedMonth);
        rs = ps.executeQuery();
        if (rs.next()) totalReservations = rs.getDouble(1);
        rs.close();
        ps.close();

        // Appliance Charges
        String appQuery = "SELECT SUM(total_fee) FROM appliances WHERE billing_period = ?";
        ps = conn.prepareStatement(appQuery);
        ps.setString(1, selectedMonth);
        rs = ps.executeQuery();
        if (rs.next()) totalAppliances = rs.getDouble(1);
        rs.close();
        ps.close();

        // Maintenance Expenses
        String expQuery = "SELECT SUM(total_cost) FROM maintenance_expenses WHERE DATE_FORMAT(added_at, '%M %Y') = ?";
        ps = conn.prepareStatement(expQuery);
        ps.setString(1, selectedMonth);
        rs = ps.executeQuery();
        if (rs.next()) totalExpenses = rs.getDouble(1);
        rs.close();
        ps.close();

        double totalSales = totalRent + totalReservations + totalAppliances;
        double netProfit = totalSales - totalExpenses;

        // Display in TextAreas
        TotalRentCollected.setText("Total Rent Collected\n----------------------------\n₱" + String.format("%.2f", totalRent));
        TotalReservationPayments.setText("Total Reservation \n Payments\n-------------------\n₱" + String.format("%.2f", totalReservations));
        ApplianceCharges.setText("Appliance Charges\n--------------------\n₱" + String.format("%.2f", totalAppliances));
        MaintenanceExpenses.setText("Maintenance Expenses\n--------------------\n₱" + String.format("%.2f", totalExpenses));

        if (totalRent == 0 && totalReservations == 0 && totalAppliances == 0) {
            SummarySales.setText("No billing record found for selected month.");
        } else {
            SummarySales.setText(
                "Summary\n-----------------------\n" +
                "Total Sales: \n₱" + String.format("%.2f", totalSales) + "\n\n" +
                "Maintenance Expenses: \n₱" + String.format("%.2f", totalExpenses) + "\n\n" +
                "Net Profit: \n₱" + String.format("%.2f", netProfit)
            );
        }

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

        
        
//=======================================FOR MAINTENANCE REPORT====================================================//        
            
        public void loadMaintenanceReports() {
    listofteportedtenantsnamespanel.removeAll(); // Clear previous buttons (LEFT PANEL)

    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT maintenance_reports.report_id, maintenance_reports.issue_type, maintenance_reports.tenant_id " +
                       "FROM maintenance_reports " +
                       "INNER JOIN tenants ON maintenance_reports.tenant_id = tenants.tenant_id";

        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int reportId = rs.getInt("report_id");
            String issueType = rs.getString("issue_type");
            int tenantId = rs.getInt("tenant_id");

            JButton tenantBtn = new JButton(issueType);

            // 🔽 Styling
            tenantBtn.setPreferredSize(new Dimension(220, 50));
            tenantBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
            tenantBtn.setFocusPainted(false);
            tenantBtn.setContentAreaFilled(false);
            tenantBtn.setOpaque(true);
            tenantBtn.setBackground(new Color(240, 240, 240));
            tenantBtn.setForeground(new Color(50, 50, 50));
            tenantBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
            ));
            tenantBtn.setFont(new Font("Segoe UI", Font.PLAIN, 14));

            // 🔽 Highlight logic + show details
            tenantBtn.addActionListener(e -> {
                // Reset previous
                if (selectedMaintenanceButton != null) {
                    selectedMaintenanceButton.setBackground(new Color(240, 240, 240));
                    selectedMaintenanceButton.setForeground(new Color(50, 50, 50));
                }

                // Highlight new
                tenantBtn.setBackground(new Color(0,153,153)); // Cornflower Blue
                tenantBtn.setForeground(Color.WHITE);

                // Update selected
                selectedMaintenanceButton = tenantBtn;

                // Load report details
                showMaintenanceReportDetails(reportId);
            });

            listofteportedtenantsnamespanel.add(tenantBtn);
        }

        listofteportedtenantsnamespanel.revalidate();
        listofteportedtenantsnamespanel.repaint();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading maintenance reports: " + e.getMessage());
    }
}
        
       public void showMaintenanceReportDetails(int reportId) {
    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT maintenance_reports.*, tenants.full_name, tenants.room_id " +
                       "FROM maintenance_reports " +
                       "INNER JOIN tenants ON maintenance_reports.tenant_id = tenants.tenant_id " +
                       "WHERE maintenance_reports.report_id = ?";

        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, reportId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            // Your code to display details
            String issueType = rs.getString("issue_type");
            String Description = rs.getString("description");
            String status = rs.getString("status");
            String resolutionNotes = rs.getString("resolution_notes");
            String reportedAt = rs.getString("reported_at");
            String fullName = rs.getString("full_name");
            String roomId = rs.getString("room_id");
            currentPhoto1Path = rs.getString("photo1_path");
            currentPhoto2Path = rs.getString("photo2_path");

            reporteddateandtime.setText(reportedAt);
            tenantname.setText(fullName);
            issuetype.setText(issueType);
            description.setText(Description);

            maintenancestatus.setSelectedItem(status);

            // Photo loading logic (same as yours)
            if (currentPhoto1Path != null && !currentPhoto1Path.isEmpty()) {
                ImageIcon imageIcon1 = new ImageIcon(currentPhoto1Path);
                Image image1 = imageIcon1.getImage().getScaledInstance(93, 69, Image.SCALE_SMOOTH);
                photo1preview.setIcon(new ImageIcon(image1));
            } else {
                photo1preview.setIcon(null);
            }

            if (currentPhoto2Path != null && !currentPhoto2Path.isEmpty()) {
                ImageIcon imageIcon2 = new ImageIcon(currentPhoto2Path);
                Image image2 = imageIcon2.getImage().getScaledInstance(93, 69, Image.SCALE_SMOOTH);
                photo2preview.setIcon(new ImageIcon(image2));
            } else {
                photo2preview.setIcon(null);
            }

            currentReportId = rs.getInt("report_id");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error loading report: " + e.getMessage());
    }
}
       
       public void addExpense(int reportId, String itemName, int qty, double unitCost) {
    try (Connection conn = DBconnection.getConnection()) {
        String query = "INSERT INTO maintenance_expenses (report_id, item_name, quantity, unit_cost) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, reportId);
        stmt.setString(2, itemName);
        stmt.setInt(3, qty);
        stmt.setDouble(4, unitCost);
        stmt.executeUpdate();
        JOptionPane.showMessageDialog(null, "Expense added.");
      //  loadExpensesForReport(reportId); // Refresh expense panel
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error adding expense: " + e.getMessage());
    }
}

       
        
        private void showImageInPopup(String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No image to display.");
            return;
        }

        JFrame popupFrame = new JFrame("Image Viewer");
        popupFrame.setSize(1000, 700); // Frame size
        popupFrame.setLocationRelativeTo(this);
        popupFrame.setLayout(new BorderLayout()); 

        // Load the image
        ImageIcon imageIcon = new ImageIcon(imagePath);
        JLabel imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        imageLabel.setVerticalAlignment(JLabel.CENTER);

        // Compute the correct size (minus decoration insets)
        Insets insets = popupFrame.getInsets();
        int usableWidth = popupFrame.getWidth() - insets.left - insets.right;
        int usableHeight = popupFrame.getHeight() - insets.top - insets.bottom;

        Image image = imageIcon.getImage();
        Image resizedImage = image.getScaledInstance(usableWidth, usableHeight, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(resizedImage));

        popupFrame.add(imageLabel, BorderLayout.CENTER);
        popupFrame.setVisible(true);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane3 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        sidebarbutton = new javax.swing.JPanel();
        tenantprofile = new javax.swing.JButton();
        roommanagement = new javax.swing.JButton();
        dashboard = new javax.swing.JButton();
        reportedmaintenance = new javax.swing.JButton();
        reservation = new javax.swing.JButton();
        bills = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Parent = new javax.swing.JPanel();
        dashboardpanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        num_beds = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        num_tenants = new javax.swing.JTextArea();
        jScrollPane9 = new javax.swing.JScrollPane();
        num_rooms = new javax.swing.JTextArea();
        tenantsprofilepanel = new javax.swing.JPanel();
        jSplitPane2 = new javax.swing.JSplitPane();
        tenantListPanel = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        genderComboBox = new javax.swing.JComboBox<>();
        jScrollPane7 = new javax.swing.JScrollPane();
        showTenantProfile = new javax.swing.JPanel();
        showtenantdetails = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        tenantcode = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        contactnum = new javax.swing.JTextField();
        email1 = new javax.swing.JTextField();
        gender1 = new javax.swing.JTextField();
        moveindate1 = new javax.swing.JTextField();
        label = new javax.swing.JLabel();
        fullname1 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        roomnum1 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        bednum1 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        emergencynum = new javax.swing.JTextField();
        emergencyname = new javax.swing.JTextField();
        emergencyrelationship = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        registrationstatus = new javax.swing.JTextField();
        manageappliances = new javax.swing.JButton();
        pendingreservationpanel = new javax.swing.JPanel();
        jSplitPane3 = new javax.swing.JSplitPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        reservationTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        fullname = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        contactnumber = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        amountpaid = new javax.swing.JTextField();
        genderr = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        datereserve = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        acceptButton = new javax.swing.JButton();
        reject = new javax.swing.JButton();
        roomnum = new javax.swing.JComboBox<>();
        bednum = new javax.swing.JComboBox<>();
        moveInDateChooser = new com.toedter.calendar.JDateChooser();
        roommanagementpanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        roomoverview = new javax.swing.JTable();
        jLabel34 = new javax.swing.JLabel();
        roomoverviewgender = new javax.swing.JComboBox<>();
        jLabel35 = new javax.swing.JLabel();
        roomoverviewstatus = new javax.swing.JComboBox<>();
        updatestatusbtn = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        billspanel = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        selectMonthCombo = new javax.swing.JComboBox<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        TotalRentCollected = new javax.swing.JTextArea();
        jScrollPane10 = new javax.swing.JScrollPane();
        TotalReservationPayments = new javax.swing.JTextArea();
        jScrollPane11 = new javax.swing.JScrollPane();
        ApplianceCharges = new javax.swing.JTextArea();
        jScrollPane12 = new javax.swing.JScrollPane();
        MaintenanceExpenses = new javax.swing.JTextArea();
        jScrollPane13 = new javax.swing.JScrollPane();
        SummarySales = new javax.swing.JTextArea();
        reportedtenantspanel = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        leftpanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        listofteportedtenantsnamescroll = new javax.swing.JScrollPane();
        listofteportedtenantsnamespanel = new javax.swing.JPanel();
        rightpanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        reporteddateandtime = new javax.swing.JTextField();
        tenantname = new javax.swing.JTextField();
        issuetype = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        description = new javax.swing.JTextArea();
        maintenancestatus = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        maintenanceupdatebuttton = new javax.swing.JButton();
        photo1preview = new javax.swing.JLabel();
        photo2preview = new javax.swing.JLabel();
        viewcommentslabel = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        addexpensebtn = new javax.swing.JButton();
        viewexpenses = new javax.swing.JLabel();

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(jList1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(759, 517));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sidebarbutton.setBackground(new java.awt.Color(0, 153, 153));

        tenantprofile.setBackground(new java.awt.Color(0, 153, 153));
        tenantprofile.setForeground(new java.awt.Color(255, 255, 255));
        tenantprofile.setText("  Tenants Profile");
        tenantprofile.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        tenantprofile.setBorderPainted(false);
        tenantprofile.setContentAreaFilled(false);
        tenantprofile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tenantprofile.setFocusPainted(false);
        tenantprofile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tenantprofile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tenantprofileActionPerformed(evt);
            }
        });

        roommanagement.setBackground(new java.awt.Color(0, 153, 153));
        roommanagement.setForeground(new java.awt.Color(255, 255, 255));
        roommanagement.setText("  Room Management");
        roommanagement.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        roommanagement.setBorderPainted(false);
        roommanagement.setContentAreaFilled(false);
        roommanagement.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        roommanagement.setFocusPainted(false);
        roommanagement.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        roommanagement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roommanagementActionPerformed(evt);
            }
        });

        dashboard.setBackground(new java.awt.Color(0, 153, 153));
        dashboard.setForeground(new java.awt.Color(255, 255, 255));
        dashboard.setText("  Dashboard");
        dashboard.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION));
        dashboard.setBorderPainted(false);
        dashboard.setContentAreaFilled(false);
        dashboard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dashboard.setFocusPainted(false);
        dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dashboard.setOpaque(true);
        dashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashboardActionPerformed(evt);
            }
        });

        reportedmaintenance.setBackground(new java.awt.Color(0, 153, 153));
        reportedmaintenance.setForeground(new java.awt.Color(255, 255, 255));
        reportedmaintenance.setText("  Utility Problems");
        reportedmaintenance.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        reportedmaintenance.setBorderPainted(false);
        reportedmaintenance.setContentAreaFilled(false);
        reportedmaintenance.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reportedmaintenance.setFocusPainted(false);
        reportedmaintenance.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        reportedmaintenance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportedmaintenanceActionPerformed(evt);
            }
        });

        reservation.setBackground(new java.awt.Color(0, 153, 153));
        reservation.setForeground(new java.awt.Color(255, 255, 255));
        reservation.setText("  Reservation");
        reservation.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        reservation.setBorderPainted(false);
        reservation.setContentAreaFilled(false);
        reservation.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reservation.setFocusPainted(false);
        reservation.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        reservation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reservationActionPerformed(evt);
            }
        });

        bills.setBackground(new java.awt.Color(0, 153, 153));
        bills.setForeground(new java.awt.Color(255, 255, 255));
        bills.setText("  Bills");
        bills.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        bills.setBorderPainted(false);
        bills.setContentAreaFilled(false);
        bills.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bills.setFocusPainted(false);
        bills.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bills.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                billsActionPerformed(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Logout");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout sidebarbuttonLayout = new javax.swing.GroupLayout(sidebarbutton);
        sidebarbutton.setLayout(sidebarbuttonLayout);
        sidebarbuttonLayout.setHorizontalGroup(
            sidebarbuttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sidebarbuttonLayout.createSequentialGroup()
                .addGroup(sidebarbuttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tenantprofile, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roommanagement, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reportedmaintenance, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reservation, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bills, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(sidebarbuttonLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        sidebarbuttonLayout.setVerticalGroup(
            sidebarbuttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sidebarbuttonLayout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(dashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(tenantprofile, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(reservation, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(roommanagement, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(bills, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(reportedmaintenance, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 152, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(25, 25, 25))
        );

        getContentPane().add(sidebarbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 140, 530));

        Parent.setBackground(new java.awt.Color(255, 255, 255));
        Parent.setPreferredSize(new java.awt.Dimension(650, 570));
        Parent.setLayout(new java.awt.CardLayout());

        dashboardpanel.setBackground(new java.awt.Color(255, 255, 255));
        dashboardpanel.setPreferredSize(new java.awt.Dimension(650, 550));

        jLabel1.setFont(new java.awt.Font("Carla Sans", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Welcome Admin");

        num_beds.setBackground(new java.awt.Color(255, 255, 255));
        num_beds.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        num_beds.setShowGrid(true);
        num_beds.getTableHeader().setReorderingAllowed(false);
        jScrollPane4.setViewportView(num_beds);

        jScrollPane8.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        num_tenants.setEditable(false);
        num_tenants.setBackground(new java.awt.Color(255, 255, 255));
        num_tenants.setColumns(20);
        num_tenants.setRows(5);
        jScrollPane8.setViewportView(num_tenants);

        jScrollPane9.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        num_rooms.setEditable(false);
        num_rooms.setBackground(new java.awt.Color(255, 255, 255));
        num_rooms.setColumns(20);
        num_rooms.setRows(5);
        jScrollPane9.setViewportView(num_rooms);

        javax.swing.GroupLayout dashboardpanelLayout = new javax.swing.GroupLayout(dashboardpanel);
        dashboardpanel.setLayout(dashboardpanelLayout);
        dashboardpanelLayout.setHorizontalGroup(
            dashboardpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardpanelLayout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(dashboardpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboardpanelLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(357, 357, 357))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboardpanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        dashboardpanelLayout.setVerticalGroup(
            dashboardpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardpanelLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addGroup(dashboardpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(300, Short.MAX_VALUE))
        );

        Parent.add(dashboardpanel, "card1");

        tenantsprofilepanel.setLayout(new java.awt.CardLayout());

        jSplitPane2.setDividerLocation(250);

        tenantListPanel.setBackground(new java.awt.Color(255, 255, 255));
        tenantListPanel.setForeground(new java.awt.Color(0, 0, 0));

        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Sort by:");

        genderComboBox.setBackground(new java.awt.Color(255, 255, 255));
        genderComboBox.setForeground(new java.awt.Color(0, 0, 0));
        genderComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Female", "Male" }));
        genderComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderComboBoxActionPerformed(evt);
            }
        });

        jScrollPane7.setViewportView(showTenantProfile);

        showTenantProfile.setBackground(new java.awt.Color(255, 255, 255));
        showTenantProfile.setForeground(new java.awt.Color(0, 0, 0));
        showTenantProfile.setLayout(new javax.swing.BoxLayout(showTenantProfile, javax.swing.BoxLayout.Y_AXIS));
        jScrollPane7.setViewportView(showTenantProfile);

        javax.swing.GroupLayout tenantListPanelLayout = new javax.swing.GroupLayout(tenantListPanel);
        tenantListPanel.setLayout(tenantListPanelLayout);
        tenantListPanelLayout.setHorizontalGroup(
            tenantListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tenantListPanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(genderComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 92, Short.MAX_VALUE))
            .addGroup(tenantListPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7)
                .addContainerGap())
        );
        tenantListPanelLayout.setVerticalGroup(
            tenantListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tenantListPanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(tenantListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(genderComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        jSplitPane2.setLeftComponent(tenantListPanel);

        showtenantdetails.setBackground(new java.awt.Color(255, 255, 255));

        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("Tenant Code:");

        tenantcode.setBackground(new java.awt.Color(255, 255, 255));
        tenantcode.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("Contact number:");

        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setText("Email:");

        jLabel27.setForeground(new java.awt.Color(0, 0, 0));
        jLabel27.setText("Gender:");

        jLabel29.setForeground(new java.awt.Color(0, 0, 0));
        jLabel29.setText("Move-in date:");

        contactnum.setBackground(new java.awt.Color(255, 255, 255));
        contactnum.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        email1.setBackground(new java.awt.Color(255, 255, 255));
        email1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        gender1.setBackground(new java.awt.Color(255, 255, 255));
        gender1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        moveindate1.setBackground(new java.awt.Color(255, 255, 255));
        moveindate1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        label.setForeground(new java.awt.Color(0, 0, 0));
        label.setText("Full name:");

        fullname1.setEditable(false);
        fullname1.setBackground(new java.awt.Color(255, 255, 255));
        fullname1.setForeground(new java.awt.Color(0, 0, 0));
        fullname1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        jLabel30.setForeground(new java.awt.Color(0, 0, 0));
        jLabel30.setText("Room Number:");

        roomnum1.setForeground(new java.awt.Color(0, 0, 0));
        roomnum1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel32.setForeground(new java.awt.Color(0, 0, 0));
        jLabel32.setText("Bed Number:");

        bednum1.setForeground(new java.awt.Color(0, 0, 0));
        bednum1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel28.setBackground(new java.awt.Color(0, 0, 0));
        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setText("Emergency Contact Number:");

        jLabel31.setBackground(new java.awt.Color(0, 0, 0));
        jLabel31.setForeground(new java.awt.Color(0, 0, 0));
        jLabel31.setText("Emergency Contact Name:");

        jLabel33.setBackground(new java.awt.Color(0, 0, 0));
        jLabel33.setForeground(new java.awt.Color(0, 0, 0));
        jLabel33.setText("Emergency Contact Relationship:");

        emergencynum.setBackground(new java.awt.Color(255, 255, 255));
        emergencynum.setForeground(new java.awt.Color(0, 0, 0));
        emergencynum.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        emergencyname.setBackground(new java.awt.Color(255, 255, 255));
        emergencyname.setForeground(new java.awt.Color(0, 0, 0));
        emergencyname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        emergencyrelationship.setBackground(new java.awt.Color(255, 255, 255));
        emergencyrelationship.setForeground(new java.awt.Color(0, 0, 0));
        emergencyrelationship.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        jLabel36.setForeground(new java.awt.Color(0, 0, 0));
        jLabel36.setText("Registration Status:");

        registrationstatus.setBackground(new java.awt.Color(255, 255, 255));
        registrationstatus.setForeground(new java.awt.Color(0, 0, 0));
        registrationstatus.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));

        manageappliances.setBackground(new java.awt.Color(255, 255, 255));
        manageappliances.setForeground(new java.awt.Color(0, 0, 0));
        manageappliances.setText("Manage Appliances and Billings");
        manageappliances.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manageappliancesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout showtenantdetailsLayout = new javax.swing.GroupLayout(showtenantdetails);
        showtenantdetails.setLayout(showtenantdetailsLayout);
        showtenantdetailsLayout.setHorizontalGroup(
            showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(showtenantdetailsLayout.createSequentialGroup()
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(jLabel28)
                                .addGap(38, 38, 38)
                                .addComponent(emergencynum))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(jLabel33)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(emergencyrelationship)))
                        .addGap(33, 33, 33))
                    .addGroup(showtenantdetailsLayout.createSequentialGroup()
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(jLabel36)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(registrationstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(jLabel24)
                                .addGap(18, 18, 18)
                                .addComponent(tenantcode, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                        .addComponent(jLabel27)
                                        .addGap(68, 68, 68))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, showtenantdetailsLayout.createSequentialGroup()
                                        .addComponent(jLabel29)
                                        .addGap(34, 34, 34)))
                                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(gender1, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                                    .addComponent(moveindate1)))
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(jLabel31)
                                .addGap(50, 50, 50)
                                .addComponent(emergencyname, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(label)
                                .addGap(55, 55, 55)
                                .addComponent(fullname1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel26))
                                .addGap(18, 18, 18)
                                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(contactnum, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(email1)))
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(jLabel30)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(roomnum1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                                .addComponent(jLabel32)
                                .addGap(18, 18, 18)
                                .addComponent(bednum1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 33, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, showtenantdetailsLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(manageappliances)
                .addGap(60, 60, 60))
        );
        showtenantdetailsLayout.setVerticalGroup(
            showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(showtenantdetailsLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(registrationstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(tenantcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(roomnum1, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(bednum1, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(showtenantdetailsLayout.createSequentialGroup()
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(label)
                            .addComponent(fullname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(contactnum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(email1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(gender1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29)
                            .addComponent(moveindate1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(emergencynum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel31))
                    .addComponent(emergencyname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(showtenantdetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(emergencyrelationship, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(manageappliances)
                .addGap(34, 34, 34))
        );

        jSplitPane2.setRightComponent(showtenantdetails);

        tenantsprofilepanel.add(jSplitPane2, "card2");

        Parent.add(tenantsprofilepanel, "card2");

        pendingreservationpanel.setLayout(new java.awt.CardLayout());

        jSplitPane3.setDividerLocation(250);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Lao MN", 1, 20)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 0, 0));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Pending Reservation");

        reservationTable.setBackground(new java.awt.Color(255, 255, 255));
        reservationTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        reservationTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Full Name", "Date", "reservationId"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        reservationTable.setBounds(new java.awt.Rectangle(5, 5, 450, 80));
        reservationTable.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reservationTable.setGridColor(new java.awt.Color(0, 102, 102));
        reservationTable.setSelectionBackground(new java.awt.Color(0, 102, 102));
        reservationTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        reservationTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        reservationTable.setShowGrid(false);
        reservationTable.setShowHorizontalLines(true);
        reservationTable.getTableHeader().setResizingAllowed(false);
        reservationTable.getTableHeader().setReorderingAllowed(false);
        reservationTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reservationTableMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(reservationTable);
        if (reservationTable.getColumnModel().getColumnCount() > 0) {
            reservationTable.getColumnModel().getColumn(0).setResizable(false);
            reservationTable.getColumnModel().getColumn(1).setResizable(false);
            reservationTable.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(106, Short.MAX_VALUE))
        );

        jSplitPane3.setLeftComponent(jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("Full Name:");

        fullname.setEditable(false);
        fullname.setBackground(new java.awt.Color(255, 255, 255));
        fullname.setForeground(new java.awt.Color(0, 0, 0));
        fullname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("Contact Number:");

        contactnumber.setEditable(false);
        contactnumber.setBackground(new java.awt.Color(255, 255, 255));
        contactnumber.setForeground(new java.awt.Color(0, 0, 0));
        contactnumber.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("Email:");

        email.setEditable(false);
        email.setBackground(new java.awt.Color(255, 255, 255));
        email.setForeground(new java.awt.Color(0, 0, 0));
        email.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });

        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("Gender:");

        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setText("Amount Paid:");

        amountpaid.setEditable(false);
        amountpaid.setBackground(new java.awt.Color(255, 255, 255));
        amountpaid.setForeground(new java.awt.Color(0, 0, 0));
        amountpaid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        genderr.setEditable(false);
        genderr.setBackground(new java.awt.Color(255, 255, 255));
        genderr.setForeground(new java.awt.Color(0, 0, 0));
        genderr.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        genderr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderrActionPerformed(evt);
            }
        });

        jSeparator1.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N

        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("Date Reservation:");

        datereserve.setEditable(false);
        datereserve.setBackground(new java.awt.Color(255, 255, 255));
        datereserve.setForeground(new java.awt.Color(0, 0, 0));
        datereserve.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel19.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 51, 51));
        jLabel19.setText("* input the room number and bed number");

        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("Room Number:");

        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("Bed Number:");

        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("Move-in Date:");

        acceptButton.setBackground(new java.awt.Color(255, 255, 255));
        acceptButton.setForeground(new java.awt.Color(0, 0, 0));
        acceptButton.setText("accept");
        acceptButton.setBorderPainted(false);
        acceptButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acceptButtonActionPerformed(evt);
            }
        });

        reject.setBackground(new java.awt.Color(255, 255, 255));
        reject.setForeground(new java.awt.Color(0, 0, 0));
        reject.setText("reject");
        reject.setBorderPainted(false);
        reject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rejectActionPerformed(evt);
            }
        });

        roomnum.setBackground(new java.awt.Color(255, 255, 255));
        roomnum.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        roomnum.setForeground(new java.awt.Color(0, 0, 0));
        roomnum.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Room Number" }));
        roomnum.setPreferredSize(new java.awt.Dimension(117, 19));
        roomnum.setSize(new java.awt.Dimension(117, 19));
        roomnum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomnumActionPerformed(evt);
            }
        });

        bednum.setBackground(new java.awt.Color(255, 255, 255));
        bednum.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        bednum.setForeground(new java.awt.Color(0, 0, 0));
        bednum.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Bed Number" }));

        moveInDateChooser.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel18)
                            .addGap(18, 18, 18)
                            .addComponent(datereserve))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel14)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel16)
                                .addComponent(jLabel17)
                                .addComponent(jLabel15)
                                .addComponent(jLabel20))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(amountpaid)
                                .addComponent(contactnumber, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(email, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(genderr, javax.swing.GroupLayout.Alignment.LEADING))))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)
                            .addComponent(jLabel23))
                        .addGap(19, 19, 19)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bednum, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roomnum, 0, 127, Short.MAX_VALUE)
                            .addComponent(moveInDateChooser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel19))
                .addContainerGap(22, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(acceptButton)
                .addGap(61, 61, 61)
                .addComponent(reject)
                .addGap(60, 60, 60))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel18)
                    .addComponent(datereserve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(contactnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(genderr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(amountpaid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(roomnum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(bednum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel23)
                    .addComponent(moveInDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(acceptButton)
                    .addComponent(reject))
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );

        jSplitPane3.setRightComponent(jPanel3);

        pendingreservationpanel.add(jSplitPane3, "card2");

        Parent.add(pendingreservationpanel, "card3");

        roommanagementpanel.setBackground(new java.awt.Color(255, 255, 255));

        roomoverview.setBackground(new java.awt.Color(255, 255, 255));
        roomoverview.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Room Number", "Gender", "Bed Number", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        roomoverview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        roomoverview.setGridColor(new java.awt.Color(0, 153, 153));
        roomoverview.setSelectionBackground(new java.awt.Color(0, 153, 153));
        roomoverview.setShowGrid(true);
        jScrollPane1.setViewportView(roomoverview);

        jLabel34.setForeground(new java.awt.Color(0, 0, 0));
        jLabel34.setText("Sort by Gender:");

        roomoverviewgender.setBackground(new java.awt.Color(255, 255, 255));
        roomoverviewgender.setForeground(new java.awt.Color(0, 0, 0));
        roomoverviewgender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Female", "Male" }));
        roomoverviewgender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomoverviewgenderActionPerformed(evt);
            }
        });

        jLabel35.setForeground(new java.awt.Color(0, 0, 0));
        jLabel35.setText("Status:");

        roomoverviewstatus.setBackground(new java.awt.Color(255, 255, 255));
        roomoverviewstatus.setForeground(new java.awt.Color(0, 0, 0));
        roomoverviewstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Available", "Occupied" }));
        roomoverviewstatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomoverviewstatusActionPerformed(evt);
            }
        });

        updatestatusbtn.setBackground(new java.awt.Color(255, 255, 255));
        updatestatusbtn.setForeground(new java.awt.Color(0, 0, 0));
        updatestatusbtn.setText("Update");
        updatestatusbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatestatusbtnActionPerformed(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 0, 0));
        jLabel37.setText("Select a row to update the status of bed number");

        javax.swing.GroupLayout roommanagementpanelLayout = new javax.swing.GroupLayout(roommanagementpanel);
        roommanagementpanel.setLayout(roommanagementpanelLayout);
        roommanagementpanelLayout.setHorizontalGroup(
            roommanagementpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roommanagementpanelLayout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addGroup(roommanagementpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roommanagementpanelLayout.createSequentialGroup()
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(roomoverviewgender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62)
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(roomoverviewstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roommanagementpanelLayout.createSequentialGroup()
                        .addGroup(roommanagementpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel37)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(updatestatusbtn)))
                .addGap(50, 50, 50))
        );
        roommanagementpanelLayout.setVerticalGroup(
            roommanagementpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roommanagementpanelLayout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(roommanagementpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(roomoverviewgender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35)
                    .addComponent(roomoverviewstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addComponent(jLabel37)
                .addGroup(roommanagementpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roommanagementpanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roommanagementpanelLayout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(updatestatusbtn)))
                .addGap(52, 52, 52))
        );

        Parent.add(roommanagementpanel, "card4");

        billspanel.setBackground(new java.awt.Color(255, 255, 255));
        billspanel.setForeground(new java.awt.Color(0, 0, 0));

        jLabel39.setForeground(new java.awt.Color(0, 0, 0));
        jLabel39.setText("Choose month:");

        selectMonthCombo.setBackground(new java.awt.Color(255, 255, 255));
        selectMonthCombo.setForeground(new java.awt.Color(0, 0, 0));
        selectMonthCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select a month" }));

        jScrollPane5.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane5.setToolTipText("");
        jScrollPane5.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        TotalRentCollected.setEditable(false);
        TotalRentCollected.setBackground(new java.awt.Color(255, 255, 255));
        TotalRentCollected.setColumns(20);
        TotalRentCollected.setRows(5);
        jScrollPane5.setViewportView(TotalRentCollected);

        TotalReservationPayments.setEditable(false);
        TotalReservationPayments.setBackground(new java.awt.Color(255, 255, 255));
        TotalReservationPayments.setColumns(20);
        TotalReservationPayments.setLineWrap(true);
        TotalReservationPayments.setRows(5);
        jScrollPane10.setViewportView(TotalReservationPayments);

        ApplianceCharges.setEditable(false);
        ApplianceCharges.setBackground(new java.awt.Color(255, 255, 255));
        ApplianceCharges.setColumns(20);
        ApplianceCharges.setLineWrap(true);
        ApplianceCharges.setRows(5);
        jScrollPane11.setViewportView(ApplianceCharges);

        MaintenanceExpenses.setEditable(false);
        MaintenanceExpenses.setBackground(new java.awt.Color(255, 255, 255));
        MaintenanceExpenses.setColumns(20);
        MaintenanceExpenses.setLineWrap(true);
        MaintenanceExpenses.setRows(5);
        jScrollPane12.setViewportView(MaintenanceExpenses);

        SummarySales.setEditable(false);
        SummarySales.setColumns(20);
        SummarySales.setLineWrap(true);
        SummarySales.setRows(5);
        jScrollPane13.setViewportView(SummarySales);

        javax.swing.GroupLayout billspanelLayout = new javax.swing.GroupLayout(billspanel);
        billspanel.setLayout(billspanelLayout);
        billspanelLayout.setHorizontalGroup(
            billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billspanelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(billspanelLayout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addGap(18, 18, 18)
                        .addComponent(selectMonthCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(billspanelLayout.createSequentialGroup()
                        .addGroup(billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        billspanelLayout.setVerticalGroup(
            billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billspanelLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(billspanelLayout.createSequentialGroup()
                        .addGroup(billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel39)
                            .addComponent(selectMonthCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(47, 47, 47)
                        .addGroup(billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(billspanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(165, Short.MAX_VALUE))
        );

        Parent.add(billspanel, "card5");

        reportedtenantspanel.setBackground(new java.awt.Color(255, 255, 255));
        reportedtenantspanel.setLayout(new java.awt.BorderLayout());

        jSplitPane1.setDividerLocation(250);
        jSplitPane1.setDividerSize(6);

        leftpanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("List of Tenants Reported");

        jLabel3.setFont(new java.awt.Font("Heiti TC", 2, 10)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("*Select to view the report");

        listofteportedtenantsnamespanel.setBackground(new java.awt.Color(255, 255, 255));
        listofteportedtenantsnamespanel.setLayout(new javax.swing.BoxLayout(listofteportedtenantsnamespanel, javax.swing.BoxLayout.LINE_AXIS));
        listofteportedtenantsnamescroll.setViewportView(listofteportedtenantsnamespanel);

        javax.swing.GroupLayout leftpanelLayout = new javax.swing.GroupLayout(leftpanel);
        leftpanel.setLayout(leftpanelLayout);
        leftpanelLayout.setHorizontalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftpanelLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(listofteportedtenantsnamescroll)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        leftpanelLayout.setVerticalGroup(
            leftpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leftpanelLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(28, 28, 28)
                .addComponent(listofteportedtenantsnamescroll, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jSplitPane1.setLeftComponent(leftpanel);

        rightpanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Tenant Name:");

        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Issue Type:");

        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Description:");

        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Uploaded Photos:");

        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Reported Date and Time:");

        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Write an update:");

        reporteddateandtime.setBackground(new java.awt.Color(255, 255, 255));
        reporteddateandtime.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        tenantname.setEditable(false);
        tenantname.setBackground(new java.awt.Color(255, 255, 255));
        tenantname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        issuetype.setEditable(false);
        issuetype.setBackground(new java.awt.Color(255, 255, 255));
        issuetype.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        description.setEditable(false);
        description.setBackground(new java.awt.Color(255, 255, 255));
        description.setColumns(20);
        description.setRows(5);
        jScrollPane2.setViewportView(description);

        maintenancestatus.setBackground(new java.awt.Color(255, 255, 255));
        maintenancestatus.setForeground(new java.awt.Color(0, 0, 0));
        maintenancestatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "In Progress", "Resolved" }));

        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Status:");

        maintenanceupdatebuttton.setText("Update");
        maintenanceupdatebuttton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maintenanceupdatebutttonActionPerformed(evt);
            }
        });

        photo1preview.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        photo2preview.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        viewcommentslabel.setFont(new java.awt.Font("Helvetica Neue", 0, 12)); // NOI18N
        viewcommentslabel.setForeground(new java.awt.Color(255, 51, 51));
        viewcommentslabel.setText("click to open comments");
        viewcommentslabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        viewcommentslabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewcommentslabelMouseClicked(evt);
            }
        });

        jLabel38.setForeground(new java.awt.Color(0, 0, 0));
        jLabel38.setText("Expenses:");

        addexpensebtn.setBackground(new java.awt.Color(255, 255, 255));
        addexpensebtn.setForeground(new java.awt.Color(0, 0, 0));
        addexpensebtn.setText("add expense");
        addexpensebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addexpensebtnActionPerformed(evt);
            }
        });

        viewexpenses.setFont(new java.awt.Font("Helvetica Neue", 0, 12)); // NOI18N
        viewexpenses.setForeground(new java.awt.Color(255, 0, 51));
        viewexpenses.setText("click to view expenses");
        viewexpenses.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewexpensesMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout rightpanelLayout = new javax.swing.GroupLayout(rightpanel);
        rightpanel.setLayout(rightpanelLayout);
        rightpanelLayout.setHorizontalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rightpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(maintenanceupdatebuttton)
                .addGap(23, 23, 23))
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rightpanelLayout.createSequentialGroup()
                        .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(rightpanelLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(32, 32, 32)
                                .addComponent(issuetype, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(rightpanelLayout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(30, 30, 30)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(rightpanelLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(photo1preview, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(photo2preview, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(rightpanelLayout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(tenantname, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel9)
                            .addComponent(reporteddateandtime, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(rightpanelLayout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(viewcommentslabel)
                                    .addComponent(maintenancestatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(addexpensebtn)
                                    .addComponent(viewexpenses))))
                        .addContainerGap(39, Short.MAX_VALUE))
                    .addGroup(rightpanelLayout.createSequentialGroup()
                        .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel38)
                            .addComponent(jLabel11))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        rightpanelLayout.setVerticalGroup(
            rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reporteddateandtime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tenantname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(issuetype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(photo2preview, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(photo1preview, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(viewcommentslabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(maintenancestatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(rightpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel38)
                    .addComponent(addexpensebtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(viewexpenses)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addComponent(maintenanceupdatebuttton)
                .addGap(19, 19, 19))
        );

        jSplitPane1.setRightComponent(rightpanel);

        reportedtenantspanel.add(jSplitPane1, java.awt.BorderLayout.CENTER);

        Parent.add(reportedtenantspanel, "card6");

        Parent.add(dashboardpanel, "dashboardpanel");
        Parent.add(tenantsprofilepanel,"tenantsprofilepanel");
        Parent.add(roommanagementpanel, "roommanagementpanel");
        Parent.add(pendingreservationpanel, "pendingreservationpanel");
        Parent.add(billspanel, "billspanel");
        Parent.add(reportedtenantspanel, "reportedtenantspanel");

        getContentPane().add(Parent, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 620, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
   cl.show(Parent, "dashboardpanel");
    }//GEN-LAST:event_dashboardActionPerformed

    private void tenantprofileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tenantprofileActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
        cl.show(Parent, "tenantsprofilepanel");
        loadTenants("All");
    }//GEN-LAST:event_tenantprofileActionPerformed

    private void roommanagementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roommanagementActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
       cl.show(Parent, "roommanagementpanel");
       loadRoomOverview();
    }//GEN-LAST:event_roommanagementActionPerformed

    private void reportedmaintenanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportedmaintenanceActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
        cl.show(Parent, "reportedtenantspanel");
        loadMaintenanceReports();
        
            reporteddateandtime.setText("");
            tenantname.setText("");
            issuetype.setText("");
            description.setText("");
            photo1preview.setText(""); 
            photo2preview.setText("");
            photo1preview.setIcon(null);
            photo2preview.setIcon(null);

            maintenancestatus.setSelectedItem(null);
    }//GEN-LAST:event_reportedmaintenanceActionPerformed

    private void reservationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reservationActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
       cl.show(Parent, "pendingreservationpanel");
    }//GEN-LAST:event_reservationActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void genderrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderrActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genderrActionPerformed

    private void acceptButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acceptButtonActionPerformed
         String roomNumberString = (String) roomnum.getSelectedItem();

    if (roomNumberString == null || roomNumberString.equals("Select Room Number")) {
        JOptionPane.showMessageDialog(null, "Please select a room.");
        return;
    }

    int roomNumber = Integer.parseInt(roomNumberString.split(" - ")[0]);

    String selectedBedNumberString = (String) bednum.getSelectedItem();
    if (selectedBedNumberString == null || selectedBedNumberString.equals("Select Bed Number")) {
        JOptionPane.showMessageDialog(null, "Please select a bed.");
        return;
    }

    int bedNumber = Integer.parseInt(selectedBedNumberString);

    java.util.Date moveInDateObj = moveInDateChooser.getDate();
    if (moveInDateObj == null) {
        JOptionPane.showMessageDialog(null, "Please select a move-in date.");
        return;
    }

    java.sql.Date moveInDateSql = new java.sql.Date(moveInDateObj.getTime());

    if (bedNumber == 0 || moveInDateSql == null) {
        JOptionPane.showMessageDialog(null, "Please fill in all fields.");
        return;
    }

    // Make sure the bed is available
    if (isBedAvailable(roomNumber, bedNumber)) {
        acceptReservation(reservationId, roomNumber, bedNumber, moveInDateSql);

    } else {
        JOptionPane.showMessageDialog(null, "The selected bed is not available.");
    }
    
    }//GEN-LAST:event_acceptButtonActionPerformed

    private void rejectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rejectActionPerformed
       int row = reservationTable.getSelectedRow();
        if (row != -1) {
            int reservationId = (int) reservationTable.getValueAt(row, 0);
            rejectReservation(reservationId);
        }
    
    }//GEN-LAST:event_rejectActionPerformed

    private void reservationTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reservationTableMouseClicked
        int selectedRow = reservationTable.getSelectedRow();
        if (selectedRow >= 0) {  // Check if a row is actually selected
        // Get the selected reservation ID
        Object value = reservationTable.getValueAt(selectedRow, 0);  
        if (value instanceof Number) {
            reservationId = ((Number) value).intValue();  // Safely cast to int if the value is a number
        }
        displayReservationDetails(reservationId);  // Display the details of the selected reservation
    }
    }//GEN-LAST:event_reservationTableMouseClicked

    private void roomnumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomnumActionPerformed
       String selectedRoom = (String) roomnum.getSelectedItem();
    if (selectedRoom != null && !selectedRoom.equals("Select Room Number")) {
        int roomId = Integer.parseInt(selectedRoom.split(" - ")[0]);
        populateBedComboBox(roomId);
    }
    }//GEN-LAST:event_roomnumActionPerformed

    private void billsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_billsActionPerformed
       CardLayout cl = (CardLayout) Parent.getLayout();
        cl.show(Parent, "billspanel");
        String selectedMonth = (String) selectMonthCombo.getSelectedItem();
        computeMonthlySales(selectedMonth);
    }//GEN-LAST:event_billsActionPerformed

    private void roomoverviewgenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomoverviewgenderActionPerformed
       loadRoomOverview();
    }//GEN-LAST:event_roomoverviewgenderActionPerformed

    private void roomoverviewstatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomoverviewstatusActionPerformed
        loadRoomOverview();
    }//GEN-LAST:event_roomoverviewstatusActionPerformed

    private void genderComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderComboBoxActionPerformed
        String selectedGender = genderComboBox.getSelectedItem().toString();

        // Call the method to load tenants based on selected gender
        loadTenants(selectedGender);

        // Clear all profile JTextFields
        fullname1.setText("");
        email1.setText("");
        contactnum.setText("");
        gender1.setText("");
        roomnum1.setText("");
        bednum1.setText("");
        moveindate1.setText("");
        tenantcode.setText("");
        emergencyname.setText("");
        emergencynum.setText("");
        emergencyrelationship.setText("");
        registrationstatus.setText("");
    }//GEN-LAST:event_genderComboBoxActionPerformed

    private void maintenanceupdatebutttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maintenanceupdatebutttonActionPerformed
        try (Connection conn = DBconnection.getConnection()) {
        String query = "UPDATE maintenance_reports SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE report_id = ?";

        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, maintenancestatus.getSelectedItem().toString());
  
        ps.setInt(2, currentReportId); // currentReportId should be stored when loading the report

        int rowsUpdated = ps.executeUpdate();

        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(null, "Maintenance report updated successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "No report was updated. Please check the report ID.");
        }

        ps.close();
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error updating report: " + e.getMessage());
    }
    }//GEN-LAST:event_maintenanceupdatebutttonActionPerformed

    private void viewcommentslabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewcommentslabelMouseClicked
        MaintenanceCommentsForm commentsForm = new MaintenanceCommentsForm(this);        
        commentsForm.setReportId(currentReportId); // set the report id here
        commentsForm.setVisible(true);
        commentsForm.setLocationRelativeTo(null);
    }//GEN-LAST:event_viewcommentslabelMouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        Login login = new Login();
        login.setVisible(true);
        login.pack();
        login.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_jLabel5MouseClicked

    private void manageappliancesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageappliancesActionPerformed
//        ManageAppliancesBillings manage = new ManageAppliancesBillings();
//        manage.setVisible(true);
//        manage.pack();
//        manage.setLocationRelativeTo(null);
    }//GEN-LAST:event_manageappliancesActionPerformed

    private void updatestatusbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatestatusbtnActionPerformed
//        int selectedRow = roomoverview.getSelectedRow();
//    if (selectedRow == -1) {
//        JOptionPane.showMessageDialog(null, "Please select a bed to update.");
//        return;
//    }
//
//    String roomName = roomoverview.getValueAt(selectedRow, 0).toString();
//    int bedNumber = (int) roomoverview.getValueAt(selectedRow, 2);
//    String newStatus = statussetter.getSelectedItem().toString();
//
//    Connection conn = null;
//    PreparedStatement ps = null;
//
//    try {
//        conn = DBconnection.getConnection();
//
//        // Get room_id from room name
//        String getRoomIdQuery = "SELECT room_id FROM rooms WHERE room_name = ?";
//        ps = conn.prepareStatement(getRoomIdQuery);
//        ps.setString(1, roomName);
//        ResultSet rs = ps.executeQuery();
//
//        int roomId = -1;
//        if (rs.next()) {
//            roomId = rs.getInt("room_id");
//        }
//        rs.close();
//        ps.close();
//
//        if (roomId != -1) {
//            // Update bed status
//            String updateStatusQuery = "UPDATE beds SET status = ? WHERE room_id = ? AND bed_number = ?";
//            ps = conn.prepareStatement(updateStatusQuery);
//            ps.setString(1, newStatus);
//            ps.setInt(2, roomId);
//            ps.setInt(3, bedNumber);
//
//            int updated = ps.executeUpdate();
//            if (updated > 0) {
//                JOptionPane.showMessageDialog(null, "Bed status updated successfully.");
//                loadRoomOverview(); // Refresh table
//            } else {
//                JOptionPane.showMessageDialog(null, "No changes made.");
//            }
//        }
//
//    } catch (SQLException ex) {
//        ex.printStackTrace();
//    } 
    }//GEN-LAST:event_updatestatusbtnActionPerformed

    private void addexpensebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addexpensebtnActionPerformed
        if (currentReportId == -1) return;

    String itemName = JOptionPane.showInputDialog("Enter item name (e.g. Doorknob):");
    if (itemName == null || itemName.trim().isEmpty()) return;

    String qtyStr = JOptionPane.showInputDialog("Enter quantity:");
    String costStr = JOptionPane.showInputDialog("Enter unit cost:");

    try {
        int qty = Integer.parseInt(qtyStr);
        double cost = Double.parseDouble(costStr);
        addExpense(currentReportId, itemName, qty, cost);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Invalid number format.");
    }
    }//GEN-LAST:event_addexpensebtnActionPerformed

    private void viewexpensesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewexpensesMouseClicked
        if (currentReportId == -1) {
        JOptionPane.showMessageDialog(null, "No report selected.");
        return;
    }

    MaintenanceReportExpense expenseForm = new MaintenanceReportExpense(currentReportId);
    expenseForm.setVisible(true);
    expenseForm.setLocationRelativeTo(null);
    }//GEN-LAST:event_viewexpensesMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_dashboard().setVisible(true);
            }
        });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea ApplianceCharges;
    private javax.swing.JTextArea MaintenanceExpenses;
    private javax.swing.JPanel Parent;
    private javax.swing.JTextArea SummarySales;
    private javax.swing.JTextArea TotalRentCollected;
    private javax.swing.JTextArea TotalReservationPayments;
    private javax.swing.JButton acceptButton;
    private javax.swing.JButton addexpensebtn;
    private javax.swing.JTextField amountpaid;
    private javax.swing.JComboBox<String> bednum;
    private javax.swing.JLabel bednum1;
    private javax.swing.JButton bills;
    private javax.swing.JPanel billspanel;
    private javax.swing.JTextField contactnum;
    private javax.swing.JTextField contactnumber;
    private javax.swing.JButton dashboard;
    private javax.swing.JPanel dashboardpanel;
    private javax.swing.JTextField datereserve;
    private javax.swing.JTextArea description;
    private javax.swing.JTextField email;
    private javax.swing.JTextField email1;
    private javax.swing.JTextField emergencyname;
    private javax.swing.JTextField emergencynum;
    private javax.swing.JTextField emergencyrelationship;
    private javax.swing.JTextField fullname;
    private javax.swing.JTextField fullname1;
    private javax.swing.JTextField gender1;
    private javax.swing.JComboBox<String> genderComboBox;
    private javax.swing.JTextField genderr;
    private javax.swing.JTextField issuetype;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JSplitPane jSplitPane3;
    private javax.swing.JLabel label;
    private javax.swing.JPanel leftpanel;
    private javax.swing.JScrollPane listofteportedtenantsnamescroll;
    private javax.swing.JPanel listofteportedtenantsnamespanel;
    private javax.swing.JComboBox<String> maintenancestatus;
    private javax.swing.JButton maintenanceupdatebuttton;
    private javax.swing.JButton manageappliances;
    private com.toedter.calendar.JDateChooser moveInDateChooser;
    private javax.swing.JTextField moveindate1;
    private javax.swing.JTable num_beds;
    private javax.swing.JTextArea num_rooms;
    private javax.swing.JTextArea num_tenants;
    private javax.swing.JPanel pendingreservationpanel;
    private javax.swing.JLabel photo1preview;
    private javax.swing.JLabel photo2preview;
    private javax.swing.JTextField registrationstatus;
    private javax.swing.JButton reject;
    private javax.swing.JTextField reporteddateandtime;
    private javax.swing.JButton reportedmaintenance;
    private javax.swing.JPanel reportedtenantspanel;
    private javax.swing.JButton reservation;
    private javax.swing.JTable reservationTable;
    private javax.swing.JPanel rightpanel;
    private javax.swing.JButton roommanagement;
    private javax.swing.JPanel roommanagementpanel;
    private javax.swing.JComboBox<String> roomnum;
    private javax.swing.JLabel roomnum1;
    private javax.swing.JTable roomoverview;
    private javax.swing.JComboBox<String> roomoverviewgender;
    private javax.swing.JComboBox<String> roomoverviewstatus;
    private javax.swing.JComboBox<String> selectMonthCombo;
    private javax.swing.JPanel showTenantProfile;
    private javax.swing.JPanel showtenantdetails;
    private javax.swing.JPanel sidebarbutton;
    private javax.swing.JPanel tenantListPanel;
    private javax.swing.JTextField tenantcode;
    private javax.swing.JTextField tenantname;
    private javax.swing.JButton tenantprofile;
    private javax.swing.JPanel tenantsprofilepanel;
    private javax.swing.JButton updatestatusbtn;
    private javax.swing.JLabel viewcommentslabel;
    private javax.swing.JLabel viewexpenses;
    // End of variables declaration//GEN-END:variables
}

