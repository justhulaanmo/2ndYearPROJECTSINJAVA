package Admin;
import Config.DBconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class MaintenanceReportExpense extends javax.swing.JFrame {

    private int reportId;
    
    public MaintenanceReportExpense(){
       
        
    }
    
    public MaintenanceReportExpense(int reportId) {
        this.reportId = reportId;
        initComponents();
        loadExpenses(reportId);
        
        edit.addActionListener(e -> {
    int selectedRow = listofexpense.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an expense to edit.");
        return;
    }

    String currentItem = (String) listofexpense.getValueAt(selectedRow, 0);
    int currentQty = (int) listofexpense.getValueAt(selectedRow, 1);
    double currentCost = (double) listofexpense.getValueAt(selectedRow, 2);

    String itemName = JOptionPane.showInputDialog(this, "Item name:", currentItem);
    if (itemName == null || itemName.trim().isEmpty()) return;

    String qtyStr = JOptionPane.showInputDialog(this, "Quantity:", currentQty);
    String costStr = JOptionPane.showInputDialog(this, "Unit cost:", currentCost);

    try {
        int qty = Integer.parseInt(qtyStr);
        double unitCost = Double.parseDouble(costStr);

        int expenseId = getExpenseIdFromRow(selectedRow, this.reportId, currentItem, currentQty, currentCost);
        updateExpense(expenseId, itemName, qty, unitCost);
        loadExpenses(this.reportId);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Invalid input. Quantity and cost must be numbers.");
    }
});

        
        remove.addActionListener(e -> {
    int selectedRow = listofexpense.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an expense to remove.");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this expense?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    String item = (String) listofexpense.getValueAt(selectedRow, 0);
    int qty = (int) listofexpense.getValueAt(selectedRow, 1);
    double cost = (double) listofexpense.getValueAt(selectedRow, 2);

    int expenseId = getExpenseIdFromRow(selectedRow, this.reportId, item, qty, cost);
    deleteExpense(expenseId);
    loadExpenses(this.reportId);
});
        
    }

    public void loadExpenses(int reportId) {
    DefaultTableModel model = (DefaultTableModel) listofexpense.getModel();
    model.setRowCount(0); // clear existing rows

    double totalSum = 0.0;

    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT expense_id, item_name, quantity, unit_cost, total_cost FROM maintenance_expenses WHERE report_id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, reportId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int expenseId = rs.getInt("expense_id"); // optional if used for edit/remove
            String item = rs.getString("item_name");
            int qty = rs.getInt("quantity");
            double unitCost = rs.getDouble("unit_cost");
            double totalCost = rs.getDouble("total_cost");
            
            totalSum += totalCost;

            model.addRow(new Object[] { item, qty, unitCost, totalCost });
        }

        // Show total in your JLabel
        totalcost.setText("₱ "+ String.format("%.2f", totalSum));

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading expenses: " + e.getMessage());
    }
}
    
    public void updateExpense(int expenseId, String itemName, int qty, double cost) {
    try (Connection conn = DBconnection.getConnection()) {
        String sql = "UPDATE maintenance_expenses SET item_name = ?, quantity = ?, unit_cost = ? WHERE expense_id = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, itemName);
        stmt.setInt(2, qty);
        stmt.setDouble(3, cost);
        stmt.setInt(4, expenseId);
        stmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Expense updated.");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Failed to update: " + ex.getMessage());
    }
}

public void deleteExpense(int expenseId) {
    try (Connection conn = DBconnection.getConnection()) {
        String sql = "DELETE FROM maintenance_expenses WHERE expense_id = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, expenseId);
        stmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Expense deleted.");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Failed to delete: " + ex.getMessage());
    }
}

private int getExpenseIdFromRow(int selectedRow, int reportId, String itemName, int qty, double unitCost) {
    int expenseId = -1;
    try (Connection conn = DBconnection.getConnection()) {
        String query = "SELECT expense_id FROM maintenance_expenses WHERE report_id = ? AND item_name = ? AND quantity = ? AND unit_cost = ? LIMIT 1";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, reportId);
        stmt.setString(2, itemName);
        stmt.setInt(3, qty);
        stmt.setDouble(4, unitCost);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            expenseId = rs.getInt("expense_id");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error retrieving expense ID: " + e.getMessage());
    }
    return expenseId;
}



    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listofexpense = new javax.swing.JTable();
        edit = new javax.swing.JButton();
        remove = new javax.swing.JButton();
        totalcost = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(474, 344));
        setMinimumSize(new java.awt.Dimension(474, 344));
        setSize(new java.awt.Dimension(474, 344));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        listofexpense.setBackground(new java.awt.Color(255, 255, 255));
        listofexpense.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Item", "Quantity", "Unit Cost", "Total Cost"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(listofexpense);

        edit.setText("Edit");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        remove.setText("Remove");
        remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeActionPerformed(evt);
            }
        });

        totalcost.setEditable(false);
        totalcost.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        totalcost.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Total Cost Expense:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(totalcost, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(remove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(edit, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalcost, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(edit)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(remove)
                        .addGap(160, 160, 160))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editActionPerformed

    private void removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_removeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MaintenanceReportExpense.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MaintenanceReportExpense.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MaintenanceReportExpense.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MaintenanceReportExpense.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MaintenanceReportExpense().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton edit;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable listofexpense;
    private javax.swing.JButton remove;
    private javax.swing.JTextField totalcost;
    // End of variables declaration//GEN-END:variables
}
