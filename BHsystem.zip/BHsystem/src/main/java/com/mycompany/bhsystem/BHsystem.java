/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bhsystem;

/**
 *
 * @author beasarong
 */
public class BHsystem {

    public static void main(String[] args) {
        //DBconnection.connection();
    }
}
